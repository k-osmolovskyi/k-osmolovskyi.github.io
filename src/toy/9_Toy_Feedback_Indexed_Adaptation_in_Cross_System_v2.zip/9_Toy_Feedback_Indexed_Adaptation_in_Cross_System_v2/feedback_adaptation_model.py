"""Minimal feedback-indexed adaptation layer used by the toy realization.

The module represents only the higher-order adaptation state and application
transition. The inherited partial mapping, mapping domain, and quality
construction are external inputs to this layer.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple
import math

APPLICATION_THRESHOLD = 0.40
GAIN_XI = 0.50
GAIN_LATENT = 0.50

@dataclass(frozen=True)
class AdaptationState:
    version: int
    xi: Tuple[float, float, float]
    latent: float

@dataclass(frozen=True)
class FeedbackRecord:
    admission_signal: float
    proposal_xi: Tuple[float, float, float]
    proposal_latent: float


def _finite(x: float) -> bool:
    return isinstance(x, (int, float)) and math.isfinite(float(x))


def valid_feedback(record: FeedbackRecord) -> bool:
    return (
        _finite(record.admission_signal)
        and 0.0 <= float(record.admission_signal) <= 1.0
        and len(record.proposal_xi) == 3
        and all(_finite(x) for x in record.proposal_xi)
        and _finite(record.proposal_latent)
    )


def assess_application(record: Optional[FeedbackRecord]) -> Optional[int]:
    """Return None for undefined assessment, 0 for assessed-not-applied, 1 for applied."""
    if record is None or not valid_feedback(record):
        return None
    return int(float(record.admission_signal) >= APPLICATION_THRESHOLD)


def transition(state: AdaptationState, record: FeedbackRecord) -> Optional[AdaptationState]:
    """Create a successor only for a positively applied feedback record."""
    status = assess_application(record)
    if status != 1:
        return None
    xi = tuple(float(state.xi[i]) + GAIN_XI * float(record.proposal_xi[i]) for i in range(3))
    latent = float(state.latent) + GAIN_LATENT * float(record.proposal_latent)
    return AdaptationState(state.version + 1, xi, latent)


def state_value_changed(a: AdaptationState, b: AdaptationState) -> bool:
    return a.xi != b.xi or float(a.latent) != float(b.latent)


def projected_mapping_coordinates(state: AdaptationState) -> Tuple[float, float, float]:
    """The latent coordinate is deliberately excluded from the mapping-context projection."""
    return tuple(float(x) for x in state.xi)
