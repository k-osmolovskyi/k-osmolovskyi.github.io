from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from feedback_adaptation_model import AdaptationState, FeedbackRecord, assess_application, transition, state_value_changed, projected_mapping_coordinates

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; FIG=ROOT/'figures'; TAB=ROOT/'tables'
FIG.mkdir(exist_ok=True); TAB.mkdir(exist_ok=True)

checks=[]
def check(name, cond):
    checks.append((name,bool(cond)))

def fmt(x,n=4):
    return '--' if pd.isna(x) else f'{float(x):.{n}f}'

D=pd.read_csv(DATA/'deterministic_summary.csv')
A=pd.read_csv(DATA/'deterministic_attempts.csv')
S=pd.read_csv(DATA/'source_family_summary.csv')
MC=pd.read_csv(DATA/'monte_carlo_summary.csv')
SURF=pd.read_csv(DATA/'surface_summary.csv')
DEN=pd.read_csv(DATA/'definedness_summary.csv')
R=np.load(DATA/'final_record_readouts.npz')
G1=np.load(DATA/'G1_surface.npz'); G2=np.load(DATA/'G2_surface.npz')

# Core transition semantics
s0=AdaptationState(0,(0.0,0.0,0.0),0.0)
fb_low=FeedbackRecord(0.39,(0.1,0.0,0.0),0.2)
fb_zero=FeedbackRecord(0.40,(0.0,0.0,0.0),0.0)
fb_lat=FeedbackRecord(0.80,(0.0,0.0,0.0),0.2)
fb_xi=FeedbackRecord(0.80,(0.1,-0.2,0.3),0.2)
check('undefined application remains distinct', assess_application(None) is None)
check('subthreshold feedback is assessed-not-applied', assess_application(fb_low)==0)
check('threshold feedback is positively applied', assess_application(fb_zero)==1)
check('assessed-not-applied creates no successor', transition(s0,fb_low) is None)
s1=transition(s0,fb_zero); check('applied no-op creates a successor version', s1 is not None and s1.version==1 and not state_value_changed(s0,s1))
s2=transition(s0,fb_lat); check('latent-only proposal changes higher-order state', s2 is not None and state_value_changed(s0,s2))
check('latent coordinate does not alter mapping projection', projected_mapping_coordinates(s0)==projected_mapping_coordinates(s2))
s3=transition(s0,fb_xi); check('mapping-active proposal changes projection', projected_mapping_coordinates(s0)!=projected_mapping_coordinates(s3))
check('transition gain for xi is 0.5', np.allclose(s3.xi,(0.05,-0.10,0.15)))
check('transition gain for latent coordinate is 0.5', abs(s3.latent-0.1)<1e-15)

# Deterministic cases
check('six deterministic cases', len(D)==6 and set(D.scenario_id)=={'D0_assessed_not_applied','D1_applied_noop','D2_latent_only','D3_mapping_shift','D4_alternating_mapping','D5_unmapped_active'})
check('120 deterministic attempts', len(A)==120)
for sid in D.scenario_id:
    check(f'{sid}: 20 attempts', len(A[A.scenario_id==sid])==20)
row={r.scenario_id:r for _,r in D.iterrows()}
check('D0 has no positive applications', int(row['D0_assessed_not_applied'].D_applied)==0)
check('D0 remains state-constant', int(row['D0_assessed_not_applied'].state_eventual_constancy)==1)
check('D1 has 20 applied no-ops', int(row['D1_applied_noop'].D_applied_noop)==20)
check('D1 has no numerical state change', int(row['D1_applied_noop'].D_state_changed)==0)
check('D2 changes state on every application', int(row['D2_latent_only'].D_state_changed)==20)
check('D2 leaves projected context unchanged', int(row['D2_latent_only'].D_context_changed)==0)
check('D3 changes projected context on every application', int(row['D3_mapping_shift'].D_context_changed)==20)
check('D3 has 20 selected-source assignment-change witnesses', int(row['D3_mapping_shift'].D_map_change_witness)==20)
check('D4 has equal initial and final local loss', abs(row['D4_alternating_mapping'].initial_ell-row['D4_alternating_mapping'].final_ell)<1e-15)
check('D4 still contains intervening map-change witnesses', int(row['D4_alternating_mapping'].D_map_change_witness)==20)
check('D5 remains unmapped', int(row['D5_unmapped_active'].initial_mapped)==0 and int(row['D5_unmapped_active'].final_mapped)==0)
check('D5 map relation remains unresolved under changed context', int(row['D5_unmapped_active'].D_map_change_unresolved)==20)
check('D5 quality remains undefined', pd.isna(row['D5_unmapped_active'].initial_ell) and pd.isna(row['D5_unmapped_active'].final_ell))

# Surfaces
check('two pre-specified surfaces', set(SURF.surface)=={'G1','G2'})
check('G1 has 14641 cells', len(G1['x'])==14641)
check('G2 has 14641 cells', len(G2['x'])==14641)
check('G1 mapped in every cell', int(G1['final_mapped'].sum())==14641)
check('G2 mapped in every cell', int(G2['final_mapped'].sum())==14641)
check('G1 state-change cells match summary', int((G1['state_change_count']>0).sum())==8760)
check('G1 context-change cells match summary', int((G1['context_change_count']>0).sum())==8760)
check('G2 state-change cells match summary', int((G2['state_change_count']>0).sum())==14640)
check('G2 context-change cells match summary', int((G2['context_change_count']>0).sum())==14520)
check('G2 contains latent-only state-change region', int(((G2['state_change_count']>0)&(G2['context_change_count']==0)).sum())==120)
check('surface loss minimum preserved', abs(float(np.nanmin(G1['final_ell']))-0.01087074829931974)<1e-15)
check('surface loss maximum preserved', abs(float(np.nanmax(G1['final_ell']))-0.28424489795918373)<1e-15)

# Complete source families
check('four source families', set(S.family)=={'S1','S2','S3','S4'})
for fam in ['S1','S2','S3','S4']:
    r=S[S.family==fam].iloc[0]
    check(f'{fam}: N=40401', int(r.N)==40401)
    check(f'{fam}: mapping domain invariant', int(r.D_domain_change)==0 and int(r.domain_eventual_constancy_rows)==40401)
    check(f'{fam}: all final records mapped', int(r.final_mapped)==40401)
    key=fam+'_final_ell'; vals=R[key]
    check(f'{fam}: distribution count preserved', len(vals)==40401)
    check(f'{fam}: mean final loss preserved', abs(float(np.nanmean(vals))-float(r.mean_final_ell))<1e-14)
check('S1 mean loss increases', float(S[S.family=='S1'].mean_final_ell.iloc[0])>float(S[S.family=='S1'].mean_initial_ell.iloc[0]))
check('S2 mean loss increases', float(S[S.family=='S2'].mean_final_ell.iloc[0])>float(S[S.family=='S2'].mean_initial_ell.iloc[0]))
check('S3 mean loss increases', float(S[S.family=='S3'].mean_final_ell.iloc[0])>float(S[S.family=='S3'].mean_initial_ell.iloc[0]))
check('S4 mean loss increases', float(S[S.family=='S4'].mean_final_ell.iloc[0])>float(S[S.family=='S4'].mean_initial_ell.iloc[0]))

# Monte Carlo strata
expected={'MC-M1':(9584,2051,7782,1802),'MC-M2':(14416,2052,11752,2664),'MC-M3':(16948,2053,13972,2976)}
check('three Monte Carlo strata', set(MC.family)==set(expected))
for fam,(N,seed,mapped,unmapped) in expected.items():
    r=MC[MC.family==fam].iloc[0]
    check(f'{fam}: sample size preserved', int(r.N)==N)
    check(f'{fam}: seed preserved', int(r.seed)==seed)
    check(f'{fam}: mapped count preserved', int(r.final_mapped)==mapped)
    check(f'{fam}: unmapped count preserved', N-int(r.final_mapped)==unmapped)
    key=fam.replace('-','_')+'_final_ell'; vals=R[key]
    check(f'{fam}: record count preserved', len(vals)==N)
    check(f'{fam}: mapped quality count preserved', int(np.isfinite(vals).sum())==mapped)
    check(f'{fam}: mean mapped final loss preserved', abs(float(np.nanmean(vals))-float(r.mean_final_ell))<1e-14)
    check(f'{fam}: domain constancy preserved', int(r.domain_eventual_constancy_rows)==N)
check('Monte Carlo strata remain unpooled', len(MC)==3)
check('unmapped rows have undefined scalar quality', all(np.isnan(R[k+'_final_ell'][R[k+'_final_mapped']==0]).all() for k in ['MC_M1','MC_M2','MC_M3']))

# Definedness partitions
check('definedness summary includes 13 scopes', len(DEN)==13)
check('standard runs contain no undefined application assessments', int(DEN.D_AdApply_undefined.sum())==0)
check('full-image status is not inferred for positive applications', int(DEN.D_image_not_evaluated.sum())==int(DEN.D_applied.sum()))
check('mapping-domain change remains zero throughout reported runs', int(DEN.D_domain_change.sum())==0)

# Generate figures
# F1
fig,ax=plt.subplots(figsize=(10,5));ax.axis('off')
labels=['Inherited source/receiver\nmapping record','Higher-order\nadaptation state','Feedback candidate\n+ typed record','Application assessment\nundefined / 0 / 1','Positive transition\n(if status = 1)','Fixed context projection\n($\\xi$ only)','Inherited mapping\ndomain + quality']
pos=[(.12,.70),(.38,.70),(.64,.70),(.88,.70),(.88,.32),(.58,.32),(.28,.32)]
for (x,y),lab in zip(pos,labels):
    ax.text(x,y,lab,ha='center',va='center',bbox=dict(boxstyle='round,pad=.45',fc='white',ec='black'),fontsize=8.5)
for (x1,y1),(x2,y2) in zip(pos[:-1],pos[1:]):
    ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='->',shrinkA=48,shrinkB=48))
ax.text(.5,.08,'State change != context change != established map change; the mapping domain is $\\xi$-invariant in this realization; full image status is not evaluated.',ha='center',fontsize=8.6,style='italic')
fig.tight_layout();fig.savefig(FIG/'adaptation_architecture.png',dpi=200);plt.close(fig)
# F2
fig,ax=plt.subplots(figsize=(10,5))
for sid,g in A.groupby('scenario_id',sort=False): ax.plot(g.attempt_index,g.state_version_post,marker='o',ms=2,label=sid)
ax.set_xlabel('feedback attempt');ax.set_ylabel('positive-transition state version');ax.set_title('Deterministic application/state-version timelines');ax.legend(fontsize=7,ncol=2);fig.tight_layout();fig.savefig(FIG/'deterministic_application_timelines.png',dpi=200);plt.close(fig)
# F3
fig,ax=plt.subplots(figsize=(10,5))
for sid,g in A.groupby('scenario_id',sort=False): ax.plot(g.attempt_index,g.ell_post.to_numpy(float),marker='o',ms=2,label=sid)
ax.set_xlabel('feedback attempt');ax.set_ylabel('post-step local $\\ell_{AB}^{coord}$ (undefined if unmapped)');ax.set_title('Deterministic fixed-profile local-quality trajectories');ax.legend(fontsize=7,ncol=2);fig.tight_layout();fig.savefig(FIG/'deterministic_local_quality.png',dpi=200);plt.close(fig)
# F4
n=121;X=G1['x'].reshape(n,n);Y=G1['y'].reshape(n,n);AA=G1['applied_count'].reshape(n,n);E=G1['final_ell'].reshape(n,n)
fig,axs=plt.subplots(1,2,figsize=(10,4));im=axs[0].imshow(AA.T,origin='lower',aspect='auto',extent=[X.min(),X.max(),Y.min(),Y.max()]);fig.colorbar(im,ax=axs[0]);axs[0].set_xlabel('admission signal');axs[0].set_ylabel('proposal $\\Delta\\xi_0$');axs[0].set_title('Applied count');im=axs[1].imshow(E.T,origin='lower',aspect='auto',extent=[X.min(),X.max(),Y.min(),Y.max()]);fig.colorbar(im,ax=axs[1]);axs[1].set_xlabel('admission signal');axs[1].set_ylabel('proposal $\\Delta\\xi_0$');axs[1].set_title('Final local loss');fig.tight_layout();fig.savefig(FIG/'feedback_surface.png',dpi=200);plt.close(fig)
# F5
X=G2['x'].reshape(n,n);Y=G2['y'].reshape(n,n);SS=G2['state_change_count'].reshape(n,n);CC=G2['context_change_count'].reshape(n,n);E=G2['final_ell'].reshape(n,n)
fig,axs=plt.subplots(1,3,figsize=(12,4))
for ax,Z,title in zip(axs,[SS,CC,E],['State-change count','Context-change count','Final local loss']):
    im=ax.imshow(Z.T,origin='lower',aspect='auto',extent=[X.min(),X.max(),Y.min(),Y.max()]);fig.colorbar(im,ax=ax);ax.set_xlabel('proposal $\\Delta\\xi_0$');ax.set_ylabel('proposal latent');ax.set_title(title)
fig.tight_layout();fig.savefig(FIG/'state_context_quality_surface.png',dpi=200);plt.close(fig)
# F6
fig,axs=plt.subplots(1,2,figsize=(10,4))
for fam in ['S1','S2','S3','S4']:
    vals=R[fam+'_final_ell']; axs[0].hist(vals[np.isfinite(vals)],bins=40,histtype='step',density=True,label=fam)
axs[0].set_xlabel('final local loss');axs[0].set_ylabel('density');axs[0].set_title('S1-S4 final local-loss distributions');axs[0].legend()
x=np.arange(4);axs[1].bar(x-.2,S.state_eventual_constancy_rows/S.N,width=.2,label='state');axs[1].bar(x,S.context_eventual_constancy_rows/S.N,width=.2,label='context');axs[1].bar(x+.2,S.domain_eventual_constancy_rows/S.N,width=.2,label='domain');axs[1].set_xticks(x);axs[1].set_xticklabels(S.family);axs[1].set_ylim(0,1.05);axs[1].set_ylabel('row share');axs[1].set_title('Exact finite-horizon constancy diagnostics');axs[1].legend();fig.tight_layout();fig.savefig(FIG/'source_family_quality_stabilization.png',dpi=200);plt.close(fig)
# F7
fig,axs=plt.subplots(1,2,figsize=(10,4));x=np.arange(3);N=MC.N.to_numpy(float);axs[0].bar(x-.2,MC.final_mapped/N,width=.4,label='mapped');axs[0].bar(x+.2,(N-MC.final_mapped)/N,width=.4,label='unmapped');axs[0].set_xticks(x);axs[0].set_xticklabels(MC.family);axs[0].set_ylim(0,1);axs[0].set_ylabel('share');axs[0].set_title('Final mapping-domain status');axs[0].legend()
for fam in ['MC-M1','MC-M2','MC-M3']:
    vals=R[fam.replace('-','_')+'_final_ell'];axs[1].hist(vals[np.isfinite(vals)],bins=40,histtype='step',density=True,label=fam)
axs[1].set_xlabel('final local loss');axs[1].set_ylabel('density');axs[1].set_title('Monte Carlo fixed-profile local loss');axs[1].legend();fig.tight_layout();fig.savefig(FIG/'monte_carlo_domain_quality.png',dpi=200);plt.close(fig)

# Generate tables
lines=['\\begin{table}[H]','\\centering','\\scriptsize','\\caption{Deterministic feedback-adaptation schedules and realized status counts.}','\\resizebox{\\textwidth}{!}{%','\\begin{tabular}{l l r r r r r r r r r}','\\toprule','Scenario & base & app & no-app & no-op & state $\\Delta$ & context $\\Delta$ & map wit. & map unres. & final map & final $\\ell$ \\\\','\\midrule']
for _,r in D.iterrows():
    sid=str(r.scenario_id).replace('_','\\_'); base=str(r.base_condition).replace('_','\\_')
    lines.append(f"{sid} & {base} & {int(r.D_applied)} & {int(r.D_assessed_not_applied)} & {int(r.D_applied_noop)} & {int(r.D_state_changed)} & {int(r.D_context_changed)} & {int(r.D_map_change_witness)} & {int(r.D_map_change_unresolved)} & {int(r.final_mapped)} & {fmt(r.final_ell,4)} \\\\")
lines += ['\\bottomrule','\\end{tabular}}','\\end{table}']; (TAB/'deterministic_summary_table.tex').write_text('\n'.join(lines))
lines=['\\begin{table}[H]','\\centering','\\scriptsize','\\caption{Complete S1--S4 source families under the common feedback schedule.}','\\resizebox{\\textwidth}{!}{%','\\begin{tabular}{l r r r r r r r r}','\\toprule','Fam. & $N$ & applied & map wit. & map unres. & final map & mean init. $\\ell$ & mean final $\\ell$ & state const. \\\\','\\midrule']
for _,r in S.iterrows(): lines.append(f"{r.family} & {int(r.N)} & {int(r.D_applied)} & {int(r.D_map_change_witness)} & {int(r.D_map_change_unresolved)} & {int(r.final_mapped)} & {fmt(r.mean_initial_ell,4)} & {fmt(r.mean_final_ell,4)} & {int(r.state_eventual_constancy_rows)} \\\\")
lines += ['\\bottomrule','\\end{tabular}}','\\end{table}']; (TAB/'source_family_summary_table.tex').write_text('\n'.join(lines))
lines=['\\begin{table}[H]','\\centering','\\scriptsize','\\caption{Monte Carlo strata. Strata are reported separately; counts characterize the declared sampling design only.}','\\resizebox{\\textwidth}{!}{%','\\begin{tabular}{l r r r r r r r r r}','\\toprule','Fam. & $N$ & applied & no-app & map wit. & map unres. & final map & mean final $\\ell$ & 1/map & 1/unmap \\\\','\\midrule']
for _,r in MC.iterrows(): lines.append(f"{r.family} & {int(r.N)} & {int(r.D_applied)} & {int(r.D_assessed_not_applied)} & {int(r.D_map_change_witness)} & {int(r.D_map_change_unresolved)} & {int(r.final_mapped)} & {fmt(r.mean_final_ell,4)} & {int(r.PreRead1_mapped)} & {int(r.PreRead1_unmapped)} \\\\")
lines += ['\\bottomrule','\\end{tabular}}','\\end{table}']; (TAB/'monte_carlo_summary_table.tex').write_text('\n'.join(lines))

failed=[n for n,p in checks if not p]
print(f'{sum(p for _,p in checks)}/{len(checks)} structural consistency checks PASS')
if failed:
    for n in failed: print('FAIL:',n)
    raise SystemExit(1)
