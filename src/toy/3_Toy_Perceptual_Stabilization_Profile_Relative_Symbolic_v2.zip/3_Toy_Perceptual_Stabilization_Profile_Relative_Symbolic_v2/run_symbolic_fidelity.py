"""Run the symbolic-fidelity toy model, structural consistency tests, analyses, and figures."""
from __future__ import annotations

from pathlib import Path
import json
import math
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import perceptual_stabilization_model as perceptual
from symbolic_fidelity_model import (
    OMISSION, evaluate_case, compact_record, candidate_from_symbolic_values,
)

ROOT = Path(__file__).resolve().parent
DESIGN = json.loads((ROOT / "simulation_design.json").read_text(encoding="utf-8"))
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
TABLES = ROOT / "tables"
for p in (RESULTS, FIGURES, TABLES):
    p.mkdir(exist_ok=True)


def base_formed_spec() -> Dict[str, Any]:
    return dict(perceptual.STRUCTURAL_TESTS["ST4_full_stabilization_positive_support"])


def test_case(test_id: str) -> Dict[str, Any]:
    base = base_formed_spec()
    if test_id == "CT1":
        return evaluate_case("CT1", dict(perceptual.STRUCTURAL_TESTS["ST1_no_route_downstream_undefined"]), source=(0.2, 0.8, 0.5))
    if test_id == "CT2":
        return evaluate_case("CT2", base, man_gate=0, source=(0.2, 0.8, 0.5))
    if test_id == "CT3":
        return evaluate_case("CT3", base, source=(0.2, 0.8, 0.5), candidate_mode="absent")
    if test_id == "CT4":
        cand = candidate_from_symbolic_values("CT4", (0.2, 0.8, 0.5)); cand["header"] = "BAD1"
        return evaluate_case("CT4", base, source=(0.2, 0.8, 0.5), candidate_mode="supplied", supplied_candidate=cand)
    if test_id == "CT5":
        cand = candidate_from_symbolic_values("CT5", (0.2, 0.8, 0.5))
        return evaluate_case("CT5", base, source=(0.2, 0.8, 0.5), candidate_mode="supplied", supplied_candidate=cand, encoder_provenance_mode="mismatch")
    if test_id == "CT6":
        cand = candidate_from_symbolic_values("CT6", (0.2, 0.8, 0.5))
        return evaluate_case("CT6", base, source=(0.2, 0.8, 0.5), candidate_mode="supplied", supplied_candidate=cand, encoder_provenance_mode="missing")
    if test_id == "CT7":
        cand = candidate_from_symbolic_values("CT7", (0.2, 0.8, 0.5))
        return evaluate_case("CT7", base, source=(0.2, 0.8, 0.5), candidate_mode="supplied", supplied_candidate=cand, profile_applicable=False)
    direct = {
        "CT8": ((0.2, 0.8, 0.5), (0.2, 0.8, 0.5)),
        "CT9": ((0.2, 0.8, 0.5), (0.2, 0.8, OMISSION)),
        "CT10": ((0.2, 0.8, 0.5), (0.8, 0.2, 0.5)),
        "CT11": ((0.2, 0.8, 0.5), (0.35, 0.65, 0.5)),
    }
    if test_id in direct:
        source, symbolic = direct[test_id]
        cand = candidate_from_symbolic_values(test_id, symbolic)
        return evaluate_case(test_id, base, source=source, candidate_mode="supplied", supplied_candidate=cand)
    if test_id == "CT12":
        return evaluate_case("CT12", dict(perceptual.STRUCTURAL_TESTS["ST3_support_discordant_full_stabilization"]), source=(0.1, 0.9, 0.5))
    if test_id == "CT13":
        return evaluate_case("CT13", dict(perceptual.STRUCTURAL_TESTS["ST5_explicit_selection_tie"]), source=(0.2, 0.8, 0.5))
    raise KeyError(test_id)


def _eq(a, b, tol=1e-12):
    return a is not None and math.isclose(float(a), float(b), abs_tol=tol, rel_tol=tol)


def check_test(test_id: str, r: Dict[str, Any]) -> Tuple[bool, List[str]]:
    issues: List[str] = []
    def need(condition, message):
        if not condition:
            issues.append(message)
    if test_id == "CT1":
        need(r["perceptual_formed"] is False, "perceptual route unexpectedly formed")
        need(r["candidate_form"] is None and r["symform"] is None and r["symcap"] is None, "symbolic branch should be undefined")
        need(r["sym_pres"] is None and r["sym_red"] is None and r["sym_dist"] is None and r["D_sym_toy_p"] is None, "fidelity should be undefined")
    elif test_id == "CT2":
        need(r["perceptual_formed"] is True, "perceptual route should be formed")
        need(r["manifestation_status"] == "source_not_instantiated", "manifestation source status mismatch")
        need(r["candidate_form"] is None and r["symform"] is None, "symbolic branch should not instantiate")
    elif test_id == "CT3":
        need(r["alignment_status"] == 1 and r["symform"] is None and r["symcap"] is None and r["sym_pres"] is None, "candidate absence not preserved")
    elif test_id == "CT4":
        need(r["symform"] == 0 and r["symcap"] is None and r["sym_pres"] is None, "negative form handling mismatch")
    elif test_id == "CT5":
        need(r["symform"] == 1 and r["symcap"] == 0 and r["sym_pres"] is None, "capture mismatch handling mismatch")
    elif test_id == "CT6":
        need(r["symform"] == 1 and r["symcap"] is None and r["sym_pres"] is None, "undefined capture handling mismatch")
    elif test_id == "CT7":
        need(r["symcap"] == 1 and r["fidelity_application_id"] is None and r["sym_pres"] is None, "profile inapplicability handling mismatch")
    elif test_id in ("CT8", "CT9", "CT10", "CT11"):
        expected = {
            "CT8": (1, 0, 0, 0.0), "CT9": (1, 1, 0, 0.0),
            "CT10": (0, 0, 1, 0.6), "CT11": (0, 0, 0, 0.15),
        }[test_id]
        need((r["sym_pres"], r["sym_red"], r["sym_dist"]) == expected[:3], "fidelity status mismatch")
        need(_eq(r["D_sym_toy_p"], expected[3]), "scalar fidelity mismatch")
    elif test_id == "CT12":
        need(r["perceptual_false_completion"] == 1 and r["sym_dist"] == 0, "false completion non-entailment witness failed")
    elif test_id == "CT13":
        need(r["perceptual_formed"] is True and r["perceptual_sig_sup"] is None, "support definedness mismatch")
        need(r["conditioning_status"] == "conditioning_unresolved" and r["u_dist"] is None and r["u_red"] is None and r["candidate_form"] is None, "conditioning definedness mismatch")
    return not issues, issues


def run_structural_consistency_tests() -> pd.DataFrame:
    rows = []
    for tid in [f"CT{i}" for i in range(1, 14)]:
        r = test_case(tid); ok, issues = check_test(tid, r)
        rows.append({"test": tid, "pass": ok, "issues": " | ".join(issues)})
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS / "structural_consistency_tests.csv", index=False)
    if not bool(df["pass"].all()):
        raise RuntimeError(df.loc[~df["pass"]].to_dict("records"))
    return df


def family_inputs(family: str):
    n = DESIGN["deterministic_surfaces"]["resolution_2d"]
    if family == "S1":
        s = DESIGN["deterministic_surfaces"]["S1"]
        xv = np.linspace(*s["axes"]["ell"], n); yv = np.linspace(*s["axes"]["r"], n)
        for r in yv:
            for ell in xv:
                yield {"ell": float(ell), "r": float(r), "M": s["fixed"]["M"], "P": s["fixed"]["P"], "Sup": s["fixed"]["Sup"]}, tuple(s["fixed"]["source"]), float(ell), float(r)
    elif family == "S2":
        s = DESIGN["deterministic_surfaces"]["S2"]
        xv = np.linspace(*s["axes"]["source_gap"], n); yv = np.linspace(*s["axes"]["Sup_1"], n)
        for sup in yv:
            for gap in xv:
                source = (s["fixed"]["a"], s["fixed"]["a"] + float(gap), s["fixed"]["c"])
                spec = {"ell": s["fixed"]["ell"], "r": s["fixed"]["r"], "M": s["fixed"]["M"], "P": s["fixed"]["P"], "Sup": [float(sup)]}
                yield spec, source, float(gap), float(sup)
    elif family == "S3":
        s = DESIGN["deterministic_surfaces"]["S3"]
        xv = np.linspace(*s["axes"]["M_1"], n); yv = np.linspace(*s["axes"]["Sup_1"], n)
        for sup in yv:
            for match in xv:
                spec = {"ell": s["fixed"]["ell"], "r": s["fixed"]["r"], "M": [float(match)], "P": s["fixed"]["P"], "Sup": [float(sup)]}
                yield spec, tuple(s["fixed"]["source"]), float(match), float(sup)
    elif family == "S4":
        s = DESIGN["deterministic_surfaces"]["S4"]
        xv = np.linspace(*s["axes"]["delta_M"], n); yv = np.linspace(*s["axes"]["delta_P"], n)
        for dp in yv:
            for dm in xv:
                spec = {"ell": s["fixed"]["ell"], "r": s["fixed"]["r"], "M": [0.75 + float(dm)/2, 0.75 - float(dm)/2], "P": [0.80 + float(dp)/2, 0.80 - float(dp)/2], "Sup": s["fixed"]["Sup"]}
                yield spec, tuple(s["fixed"]["source"]), float(dm), float(dp)
    else:
        stratum = next(x for x in DESIGN["monte_carlo"]["strata"] if x["id"] == family)
        rng = np.random.default_rng(stratum["seed"]); blocks = stratum["blocks"]
        for _ in range(stratum["N"]):
            ell = float(rng.uniform()); r = float(rng.uniform())
            M = rng.uniform(size=blocks).tolist(); P = rng.uniform(size=blocks).tolist(); Sup = rng.uniform(size=blocks).tolist()
            a = float(rng.uniform(0.10, 0.25)); gap = float(rng.uniform(0.35, 0.65)); c = float(rng.uniform(0.10, 0.90))
            yield {"ell": ell, "r": r, "M": M, "P": P, "Sup": Sup}, (a, a + gap, c), None, None


def evaluate_family(family: str) -> pd.DataFrame:
    rows = []
    for i, (spec, source, axis1, axis2) in enumerate(family_inputs(family)):
        r = evaluate_case(f"{family}_{i:05d}", spec, source=source)
        rec = compact_record(r); rec.update({"family": family, "axis1": axis1, "axis2": axis2})
        rows.append(rec)
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS / f"{family}_results.csv", index=False)
    return df


def summarize(df: pd.DataFrame, family: str) -> Dict[str, Any]:
    defined = df.sym_pres.notna() & df.sym_red.notna() & df.sym_dist.notna()
    out: Dict[str, Any] = {"family": family, "D_all": len(df), "D_fid": int(defined.sum())}
    for col in ("sym_pres", "sym_red", "sym_dist"):
        d = df.loc[defined, col]
        out[f"{col}_pos"] = int((d == 1).sum())
        out[f"{col}_prop"] = None if len(d) == 0 else float((d == 1).mean())
    vals = df.loc[df.D_sym_toy_p.notna(), "D_sym_toy_p"].astype(float)
    out["D_mean"] = None if vals.empty else float(vals.mean())
    return out


def build_all_results():
    families = ["S1", "S2", "S3", "S4", "MC-E1", "MC-E2", "MC-E3"]
    data = {fam: evaluate_family(fam) for fam in families}
    summary = pd.DataFrame([summarize(data[f], f) for f in families])
    summary.to_csv(RESULTS / "family_summary.csv", index=False)
    return data, summary


def grid(df: pd.DataFrame, col: str, n=201):
    return df[col].to_numpy(dtype=float).reshape(n, n)


def draw_status(ax, arr, extent, title, xlabel, ylabel, vmin=-1, vmax=1, cbar_label="display: -1 undefined, 0 negative, 1 positive"):
    im = ax.imshow(arr, origin="lower", extent=extent, aspect="auto", vmin=vmin, vmax=vmax)
    ax.set_title(title); ax.set_xlabel(xlabel); ax.set_ylabel(ylabel)
    plt.colorbar(im, ax=ax, label=cbar_label)


def make_figures(data, summary):
    n = DESIGN["deterministic_surfaces"]["resolution_2d"]
    # S2
    d = data["S2"]; extent = [0.2, 0.8, 0, 1]
    fig, axs = plt.subplots(1, 3, figsize=(15.5, 4.8))
    draw_status(axs[0], grid(d, "D_sym_toy_p", n), extent, r"S2: Profile-specific $D^{sym,toy,p}$", "Source gap g", r"$S^{sup,toy}_1$", 0, 1, "D")
    draw_status(axs[1], np.where(np.isfinite(grid(d, "sym_pres", n)), grid(d, "sym_pres", n), -1), extent, "S2: SymPres", "Source gap g", r"$S^{sup,toy}_1$")
    draw_status(axs[2], np.where(np.isfinite(grid(d, "sym_dist", n)), grid(d, "sym_dist", n), -1), extent, "S2: SymDist", "Source gap g", r"$S^{sup,toy}_1$")
    for label, ax in zip("ABC", axs): ax.text(-0.08, 1.02, label, transform=ax.transAxes)
    fig.tight_layout(); fig.savefig(FIGURES / "source_gap_analysis.png", dpi=200, bbox_inches="tight"); plt.close(fig)
    # S3
    d = data["S3"]; extent = [0, 1, 0, 1]
    fig, axs = plt.subplots(2, 2, figsize=(12.5, 9.0)); axs = axs.ravel()
    context = np.full(len(d), -1.0); context[d.perceptual_formed == True] = 0; context[d.perceptual_support_discordant == 1] = 1; context[d.perceptual_false_completion == 1] = 2
    draw_status(axs[0], context.reshape(n, n), extent, "S3: Perceptual conditioning context", r"$M^{toy}_1$", r"$S^{sup,toy}_1$", -1, 2, "-1 no route, 0 formed, 1 discordant, 2 FalseComp")
    for ax, col, title in zip(axs[1:], ("sym_pres", "sym_red", "sym_dist"), ("S3: SymPres", "S3: SymRed", "S3: SymDist")):
        arr = grid(d, col, n); draw_status(ax, np.where(np.isfinite(arr), arr, -1), extent, title, r"$M^{toy}_1$", r"$S^{sup,toy}_1$")
    for label, ax in zip("ABCD", axs): ax.text(-0.08, 1.02, label, transform=ax.transAxes)
    fig.tight_layout(); fig.savefig(FIGURES / "multi_coordinate_analysis.png", dpi=200, bbox_inches="tight"); plt.close(fig)
    # S4
    d = data["S4"]; extent = [-0.2, 0.2, -0.2, 0.2]
    fig, axs = plt.subplots(1, 3, figsize=(15.5, 4.8))
    context = np.full(len(d), -1.0); context[d.perceptual_formed == True] = 0; context[d.perceptual_support_discordant == 1] = 1; context[d.perceptual_false_completion == 1] = 2
    draw_status(axs[0], context.reshape(n, n), extent, "S4: Perceptual conditioning context", r"$\delta_M$", r"$\delta_P$", -1, 2, "-1 no route, 0 formed, 1 discordant, 2 FalseComp")
    draw_status(axs[1], grid(d, "D_sym_toy_p", n), extent, r"S4: Profile-specific $D^{sym,toy,p}$", r"$\delta_M$", r"$\delta_P$", 0, 1, "D")
    arr = grid(d, "sym_dist", n); draw_status(axs[2], np.where(np.isfinite(arr), arr, -1), extent, "S4: SymDist", r"$\delta_M$", r"$\delta_P$")
    for label, ax in zip("ABC", axs): ax.text(-0.08, 1.02, label, transform=ax.transAxes)
    fig.tight_layout(); fig.savefig(FIGURES / "false_completion_non_entailment.png", dpi=200, bbox_inches="tight"); plt.close(fig)
    # Monte Carlo
    mc = summary[summary.family.str.startswith("MC")].copy(); x = np.arange(len(mc)); width = 0.22
    fig, axs = plt.subplots(1, 2, figsize=(13.5, 4.8))
    axs[0].bar(x-width, mc.sym_pres_prop, width, label="SymPres+"); axs[0].bar(x, mc.sym_red_prop, width, label="SymRed+"); axs[0].bar(x+width, mc.sym_dist_prop, width, label="SymDist+")
    axs[0].set_xticks(x, mc.family); axs[0].set_ylabel("Conditional proportion on defined fidelity domain"); axs[0].set_title("Profile-relative fidelity frequencies under declared sampling laws"); axs[0].legend()
    vals = [data[f].loc[data[f].D_sym_toy_p.notna(), "D_sym_toy_p"].to_numpy() for f in ("MC-E1", "MC-E2", "MC-E3")]
    axs[1].boxplot(vals, tick_labels=["MC-E1", "MC-E2", "MC-E3"], showfliers=False); axs[1].set_ylabel(r"$D^{sym,toy,p}$"); axs[1].set_title("Profile-specific protected-pair divergence")
    axs[0].text(-0.08, 1.02, "A", transform=axs[0].transAxes); axs[1].text(-0.08, 1.02, "B", transform=axs[1].transAxes)
    fig.tight_layout(); fig.savefig(FIGURES / "monte_carlo_summary.png", dpi=200, bbox_inches="tight"); plt.close(fig)


def consistency_checks(data):
    issues = []
    for family, d in data.items():
        bad = d[(d.fidelity_application_id.notna() | d.sym_pres.notna() | d.sym_red.notna() | d.sym_dist.notna() | d.D_sym_toy_p.notna()) & (d.symcap != 1)]
        if len(bad): issues.append(f"{family}: fidelity without positive capture")
        bad = d[(d.symcap == 1) & (d.symform != 1)]
        if len(bad): issues.append(f"{family}: positive capture without positive symbolic form")
        bad = d[(d.perceptual_formed != True) & (d.symform.notna() | d.symcap.notna() | d.D_sym_toy_p.notna())]
        if len(bad): issues.append(f"{family}: symbolic output without formed perceptual route")
        vals = d.D_sym_toy_p.dropna()
        if len(vals) and ((vals < -1e-12) | (vals > 1 + 1e-12)).any(): issues.append(f"{family}: scalar outside [0,1]")
    if issues: raise RuntimeError(issues)
    return issues


def main():
    tests = run_structural_consistency_tests()
    data, summary = build_all_results()
    consistency_checks(data)
    make_figures(data, summary)
    print(tests.to_string(index=False))
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
