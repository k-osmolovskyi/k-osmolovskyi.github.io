"""Toy computational model of perceptual stabilization under historical compression and overload.

The model is a direct formal realization of selected perceptual-stabilization
relations. It is illustrative and does not provide empirical validation of
perception or a measurement model for latent theoretical constructs.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple
import math
import numpy as np

MODEL_VERSION = "2.0"
TOY_COORDINATE_BRIDGES = {
    "ell_toy": "declared_monotone_normalization_of_selected_retained_overload_instance",
    "r_toy": "declared_scalarization_and_normalization_of_selected_processing_resource_state",
}

PARAMS = {
    "tau_match": 0.60,
    "lambda_L_rec": 0.30,
    "tau_partial": 0.45,
    "tau_full": 0.60,
    "tau_sup": 0.70,
    "mu_L_sup": 0.25,
    "mu_R_sup": 0.20,
    "tau_P": 0.80,
    "w_M_stab": 0.45,
    "w_P_stab": 0.45,
    "w_r_stab": 0.15,
    "w_ell_stab": 0.10,
    "w_M_select": 0.50,
    "w_P_select": 0.50,
}

SCENARIOS = {
    "A_clear_stabilization": {
        "ell": 0.10, "r": 0.80,
        "M": [0.85, 0.30, 0.20],
        "Sup": [0.85, 0.20, 0.10],
        "P": [0.50, 0.40, 0.30],
    },
    "B_ambiguous_signal": {
        "ell": 0.20, "r": 0.50,
        "M": [0.65, 0.62, 0.60],
        "Sup": [0.40, 0.38, 0.35],
        "P": [0.40, 0.45, 0.42],
    },
    "C_high_overload_dominant_block": {
        "ell": 0.85, "r": 0.30,
        "M": [0.48, 0.35, 0.25],
        "Sup": [0.35, 0.25, 0.20],
        "P": [0.95, 0.40, 0.30],
    },
    "D_novel_signal": {
        "ell": 0.20, "r": 0.60,
        "M": [0.20, 0.25, 0.18],
        "Sup": [0.10, 0.12, 0.09],
        "P": [0.30, 0.40, 0.35],
    },
    "E_resource_recovery": {
        "ell": 0.85, "r": 0.90,
        "M": [0.48, 0.35, 0.25],
        "Sup": [0.76, 0.25, 0.20],
        "P": [0.95, 0.40, 0.30],
    },
}

# Structural tests cover route definedness, support/stabilization separation, tie handling, and missing inputs.
STRUCTURAL_TESTS = {
    "ST1_no_route_downstream_undefined": {
        "ell": 0.20, "r": 0.50, "M": [0.20], "P": [0.30], "Sup": [0.80]
    },
    "ST2_support_positive_without_full_stabilization": {
        "ell": 0.10, "r": 0.90, "M": [0.62], "P": [0.30], "Sup": [0.80]
    },
    "ST3_support_discordant_full_stabilization": {
        "ell": 0.70, "r": 0.40, "M": [0.50], "P": [0.90], "Sup": [0.30]
    },
    "ST4_full_stabilization_positive_support": {
        "ell": 0.20, "r": 0.80, "M": [0.75], "P": [0.60], "Sup": [0.80]
    },
    "ST5_explicit_selection_tie": {
        "ell": 0.10, "r": 0.60, "M": [0.70, 0.60], "P": [0.50, 0.60], "Sup": None
    },
    "ST6_missing_recruitment_input": {
        "ell": 0.20, "r": 0.50, "M": [None], "P": [0.50], "Sup": [0.80]
    },
}

EXPECTED_TESTS = {
    "ST1_no_route_downstream_undefined": {
        "route_status": "no_positive_compressed_route", "formed": False,
        "perc_stab": None, "sig_sup": None,
    },
    "ST2_support_positive_without_full_stabilization": {
        "route_status": "formed", "stab_lvl": 1, "perc_stab": 0, "sig_sup": 1,
    },
    "ST3_support_discordant_full_stabilization": {
        "route_status": "formed", "stab_lvl": 2, "perc_stab": 1, "sig_sup": 0,
        "dominance_condition": True,
    },
    "ST4_full_stabilization_positive_support": {
        "route_status": "formed", "stab_lvl": 2, "perc_stab": 1, "sig_sup": 1,
    },
    "ST5_explicit_selection_tie": {
        "route_status": "formed", "selected_index": 0, "dominant_index": 1,
    },
    "ST6_missing_recruitment_input": {
        "route_status": "route_unresolved", "formed": False,
        "perc_stab": None, "sig_sup": None,
    },
}


def clip01(x):
    return np.clip(x, 0.0, 1.0)


def is_defined_number(x: Any) -> bool:
    if x is None:
        return False
    try:
        return bool(np.isfinite(float(x)))
    except (TypeError, ValueError):
        return False


def validate_normalized_coordinate(name: str, x: Any) -> None:
    """Reject defined toy normalization inputs outside the declared [0,1] domain."""
    if x is None:
        return
    if not is_defined_number(x):
        raise ValueError(f"{name} must be finite or None")
    if not 0.0 <= float(x) <= 1.0:
        raise ValueError(f"{name}={x!r} lies outside the declared toy domain [0,1]")


def build_synthetic_compression_provenance(n_blocks: int, episode_id: str) -> List[Dict[str, Any]]:
    """Construct synthetic positive provenance premises for each toy block."""
    records = []
    for k in range(n_blocks):
        tau = -(k + 1)
        candidate_result = f"A_delta::{episode_id}::{tau+1}"
        current_h = f"B_toy::{episode_id}::B{k+1}"
        records.append({
            "episode_id": episode_id,
            "block_index": k,
            "tau_index": tau,
            "delta_toy": f"delta::{episode_id}::B{k+1}::{tau}",
            "compressed_output": f"C_cmp::{episode_id}::B{k+1}::{tau}",
            "architecture_before": f"A::{episode_id}::{tau}",
            "candidate_result_architecture": candidate_result,
            "architecture_after": candidate_result,
            "cmp_valid_premise": 1,
            "real_premise": 1,
            "successor_equals_candidate_result_premise": True,
            "cmp_trace_premise": 1,
            "current_historical_organization": current_h,
            "trace_context": f"c_cmp_trace::{episode_id}",
            "provenance_mode": "synthetic_positive_construction_premise",
        })
    return records


def effective_match_threshold(ell: float, P: Sequence[Optional[float]], params=PARAMS) -> List[Optional[float]]:
    out: List[Optional[float]] = []
    for p in P:
        if not (is_defined_number(ell) and is_defined_number(p)):
            out.append(None)
        else:
            out.append(float(clip01(params["tau_match"] - params["lambda_L_rec"] * float(ell) * float(p))))
    return out


def recruit_blocks(M: Sequence[Optional[float]], thresholds: Sequence[Optional[float]]) -> Tuple[List[Optional[int]], List[int]]:
    """Return per-block partial Boolean statuses and the positive recruited field."""
    if len(M) != len(thresholds):
        raise ValueError("M and thresholds must have equal length")
    status: List[Optional[int]] = []
    positive: List[int] = []
    for k, (m, th) in enumerate(zip(M, thresholds)):
        if not (is_defined_number(m) and is_defined_number(th)):
            status.append(None)
            continue
        s = int(float(m) >= float(th))
        status.append(s)
        if s == 1:
            positive.append(k)
    return status, positive


def _first_by_fixed_order(indices: Sequence[int]) -> Optional[int]:
    return min(indices) if indices else None


def select_formation_block(recruited: Sequence[int], M: Sequence[Optional[float]], P: Sequence[Optional[float]], params=PARAMS):
    if not recruited:
        return None, None, None
    scores: Dict[int, float] = {}
    for k in recruited:
        if not (is_defined_number(M[k]) and is_defined_number(P[k])):
            return None, None, None
        scores[k] = params["w_M_select"] * float(M[k]) + params["w_P_select"] * float(P[k])
    max_score = max(scores.values())
    maximizers = [k for k in recruited if math.isclose(scores[k], max_score, rel_tol=1e-12, abs_tol=1e-12)]
    selected = _first_by_fixed_order(maximizers)

    pvals = {k: float(P[k]) for k in recruited if is_defined_number(P[k])}
    if len(pvals) != len(recruited):
        dominant = None
    else:
        max_p = max(pvals.values())
        pmax = [k for k in recruited if math.isclose(pvals[k], max_p, rel_tol=1e-12, abs_tol=1e-12)]
        dominant = _first_by_fixed_order(pmax)
    return selected, dominant, scores


def form_perceptual_application(episode_id: str, recruited: Sequence[int], selected_index: Optional[int], provenance: Sequence[Dict[str, Any]]):
    if not recruited:
        return None
    if selected_index is None:
        return None
    by_index = {int(rec["block_index"]): rec for rec in provenance}
    if any(int(k) not in by_index for k in recruited):
        return None
    recruited_records = [by_index[int(k)] for k in recruited]
    recruited_tokens = [rec["current_historical_organization"] for rec in recruited_records]
    return {
        "episode_id": episode_id,
        "lambda_perc": f"lambda_perc::{episode_id}",
        "recruitment_context": f"c_rec::{episode_id}",
        "recruited_indices": [int(k) for k in recruited],
        "recruited_field": recruited_tokens,
        "formation_context": f"c_form::{episode_id}",
        "formed_token": f"y::{episode_id}::B{selected_index+1}",
        "selected_index": int(selected_index),
        "recruited_synthetic_compression_provenance": recruited_records,
    }


def stabilization_score(M_selected, P_selected, r: float, ell: float, params=PARAMS) -> Optional[float]:
    vals = [M_selected, P_selected, r, ell]
    if not all(is_defined_number(v) for v in vals):
        return None
    j = (
        params["w_M_stab"] * float(M_selected)
        + params["w_P_stab"] * float(P_selected)
        + params["w_r_stab"] * float(r)
        - params["w_ell_stab"] * float(ell)
    )
    return float(clip01(j))


def stabilization_level(J: Optional[float], params=PARAMS) -> Optional[int]:
    if not is_defined_number(J):
        return None
    j = float(J)
    if j < params["tau_partial"]:
        return 0
    if j < params["tau_full"]:
        return 1
    return 2


def perc_stab_status(stab_lvl: Optional[int]) -> Optional[int]:
    if stab_lvl is None:
        return None
    return int(stab_lvl == 2)


def signal_support_threshold(ell: float, r: float, params=PARAMS) -> Optional[float]:
    if not (is_defined_number(ell) and is_defined_number(r)):
        return None
    return float(clip01(params["tau_sup"] + params["mu_L_sup"] * float(ell) - params["mu_R_sup"] * float(r)))


def signal_support_status(Sup_selected, tau_sup_eff: Optional[float]) -> Optional[int]:
    if not (is_defined_number(Sup_selected) and is_defined_number(tau_sup_eff)):
        return None
    return int(float(Sup_selected) >= float(tau_sup_eff))


def false_completion_status(formed: bool, stab_lvl: Optional[int], perc_stab: Optional[int], sig_sup: Optional[int], selected_index: Optional[int], dominant_index: Optional[int], P: Sequence[Optional[float]], params=PARAMS) -> Optional[int]:
    if not formed:
        return None
    if stab_lvl is None or perc_stab is None:
        return None
    # Completion-semantics gate: level-2 single-selected-block output.
    comp_sem = int(stab_lvl == 2)
    if sig_sup is None:
        return None
    if selected_index is None or dominant_index is None or not is_defined_number(P[selected_index]):
        return None
    dominance_condition = selected_index == dominant_index and float(P[selected_index]) >= params["tau_P"]
    return int(perc_stab == 1 and sig_sup == 0 and comp_sem == 1 and dominance_condition)


def update_dominance(P: float, event: str, eta=0.10, delta=0.05, eta_f=0.08) -> float:
    """Optional simulation-only update of the historical-dominance coordinate P."""
    if event == "full":
        return (1 - eta) * P + eta
    if event == "none":
        return (1 - delta) * P
    if event == "false":
        return (1 - eta_f) * P + eta_f
    return P


def evaluate_episode(name: str, spec: Dict[str, Any], params=PARAMS) -> Dict[str, Any]:
    episode_id = name
    z_toy = spec.get("z_toy", f"z_toy::{episode_id}")
    lambda_perc = f"lambda_perc::{episode_id}"
    ell, r = spec.get("ell"), spec.get("r")
    validate_normalized_coordinate("ell_toy", ell)
    validate_normalized_coordinate("r_toy", r)
    M, P, Sup = spec.get("M"), spec.get("P"), spec.get("Sup")
    if M is None or P is None:
        raise ValueError("Episode requires M and P sequences; individual entries may be undefined")
    if len(M) != len(P):
        raise ValueError("M and P must have equal length")
    if Sup is not None and len(Sup) != len(M):
        raise ValueError("Sup must be None or have the same length as M")

    provenance = build_synthetic_compression_provenance(len(M), episode_id)
    episode_record = {
        "episode_id": episode_id,
        "z_toy": z_toy,
        "lambda_perc": lambda_perc,
        "rho_lambda_bridge": "fixed_token_map_z_toy_to_lambda_perc",
        "ell_toy": ell,
        "r_toy": r,
        "coordinate_bridges": TOY_COORDINATE_BRIDGES,
        "M": list(M),
        "Sup": None if Sup is None else list(Sup),
        "P": list(P),
    }
    tau_match_eff = effective_match_threshold(ell, P, params)
    recruit_status, recruited = recruit_blocks(M, tau_match_eff)

    if recruited:
        route_status = "formed"  # becomes formation_undefined if selector/formation fails
    elif any(s is None for s in recruit_status):
        route_status = "route_unresolved"
    else:
        route_status = "no_positive_compressed_route"

    selected = dominant = None
    selection_scores = None
    formed_application = None
    if recruited:
        selected, dominant, selection_scores = select_formation_block(recruited, M, P, params)
        formed_application = form_perceptual_application(episode_id, recruited, selected, provenance)
        if formed_application is None:
            route_status = "formation_undefined"

    formed = formed_application is not None
    J = stab_lvl = perc_stab = tau_sup_eff = sig_sup = support_discordant = false_comp = None
    comp_sem = None
    dominance_condition = None
    selected_sup = None

    if formed:
        J = stabilization_score(M[selected], P[selected], r, ell, params)
        stab_lvl = stabilization_level(J, params)
        perc_stab = perc_stab_status(stab_lvl)
        comp_sem = None if stab_lvl is None else int(stab_lvl == 2)
        tau_sup_eff = signal_support_threshold(ell, r, params)
        if Sup is not None:
            selected_sup = Sup[selected]
        sig_sup = signal_support_status(selected_sup, tau_sup_eff)
        if perc_stab is not None and sig_sup is not None:
            support_discordant = int(perc_stab == 1 and sig_sup == 0)
        if selected is not None and dominant is not None and is_defined_number(P[selected]):
            dominance_condition = bool(selected == dominant and float(P[selected]) >= params["tau_P"])
        false_comp = false_completion_status(formed, stab_lvl, perc_stab, sig_sup, selected, dominant, P, params)

    result = {
        "episode": name,
        "episode_record": episode_record,
        "ell_toy": ell,
        "r_toy": r,
        "M": list(M),
        "Sup": None if Sup is None else list(Sup),
        "P": list(P),
        "tau_match_eff": tau_match_eff,
        "recruit_status": recruit_status,
        "recruited_indices": list(recruited),
        "route_status": route_status,
        "formed": formed,
        "selected_index": selected,
        "dominant_index": dominant,
        "selection_scores": selection_scores,
        "formed_application": formed_application,
        "J_stab_toy": J,
        "stab_lvl": stab_lvl,
        "perc_stab": perc_stab,
        "tau_sup_eff": tau_sup_eff,
        "selected_support": selected_sup,
        "sig_sup": sig_sup,
        "support_discordant": support_discordant,
        "completion_semantics": comp_sem,
        "dominance_condition": dominance_condition,
        "false_completion": false_comp,
    }
    return result


def check_expected(result: Dict[str, Any], expected: Dict[str, Any]) -> Tuple[bool, List[str]]:
    mismatches = []
    for key, exp in expected.items():
        got = result.get(key)
        if isinstance(exp, float):
            ok = is_defined_number(got) and math.isclose(float(got), exp, rel_tol=1e-9, abs_tol=1e-9)
        else:
            ok = got == exp
        if not ok:
            mismatches.append(f"{key}: expected {exp!r}, got {got!r}")
    return (len(mismatches) == 0, mismatches)


def run_structural_tests() -> List[Dict[str, Any]]:
    rows = []
    for name, spec in STRUCTURAL_TESTS.items():
        result = evaluate_episode(name, spec)
        passed, mismatches = check_expected(result, EXPECTED_TESTS[name])
        rows.append({"test": name, "pass": passed, "mismatches": mismatches, "result": result})
    return rows
