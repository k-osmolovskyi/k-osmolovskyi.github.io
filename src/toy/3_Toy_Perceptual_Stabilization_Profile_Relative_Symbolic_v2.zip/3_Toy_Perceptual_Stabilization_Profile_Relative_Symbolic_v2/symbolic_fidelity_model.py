"""Toy computational model linking perceptual stabilization to profile-relative symbolic fidelity.

The model preserves separate perceptual, manifestation, symbolic-form, symbolic-capture,
and profile-relative fidelity stages. It is illustrative and does not provide empirical
validation, semantic truth assessment, or a universal measure of symbolic fidelity.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence, Tuple
import json
import math

import numpy as np

from perceptual_stabilization_model import (
    evaluate_episode as evaluate_perceptual_episode,
    is_defined_number,
)

MODEL_VERSION = "2.0"

CODEBOOK_ID = "Q21-v1"
FORM_HEADER = "SYM1"
OMISSION = "Ø"
FORM_CONTEXT_ID = "SYMFORM-Q21-v1"
ENCODER_ID = "ENC-REL3-v1"
CAPTURE_CONTEXT_ID = "CAP-SOURCE-PROVENANCE-v1"
FIDELITY_PROFILE_ID = "FID-REL3-v1"
ALIGNMENT_CONTEXT_ID = "ALIGN-PERC-MAN-v1"
MANIFESTATION_CONTEXT_ID = "MAN-SYNTH-v1"

PARAMS = {
    "dist_d0": 0.05,
    "dist_gamma_one_minus_J": 0.25,
    "dist_gamma_sig_sup_negative": 0.15,
    "dist_gamma_support_discordant": 0.10,
    "dist_gamma_false_completion": 0.15,
    "dist_beta_ell": 0.15,
    "dist_beta_r": -0.10,
    "red_r0": 0.05,
    "red_eta_one_minus_J": 0.35,
    "red_eta_sig_sup_negative": 0.10,
    "red_eta_ell": 0.10,
    "red_eta_r": -0.10,
    "theta_red": 0.27,
    "kappa_dist": 0.50,
    "epsilon_gap_pres": 0.20,
}

INTERPRETIVE_LIMITS = [
    "toy_realization_only",
    "not_empirical_validation",
    "not_semantic_truth",
    "not_profile_independent_fidelity",
    "not_prevalence",
]


def clip01(x: float) -> float:
    return float(np.clip(float(x), 0.0, 1.0))



def _finite01(x: Any) -> bool:
    return is_defined_number(x) and 0.0 <= float(x) <= 1.0


def validate_source_descriptors(source: Optional[Sequence[Any]]) -> bool:
    if source is None or len(source) != 3:
        return False
    a, b, c = source
    return all(_finite01(x) for x in (a, b, c)) and float(a) < float(b)


def construct_manifestation_application(
    case_id: str,
    man_gate: Optional[int],
    source: Optional[Sequence[Any]],
    z_toy: Optional[str] = None,
    context_id: Optional[str] = MANIFESTATION_CONTEXT_ID,
) -> Dict[str, Any]:
    """Synthetic positive manifestation-application bookkeeping without a negative Boolean status."""
    if man_gate is None:
        return {
            "status": "source_unresolved",
            "application": None,
            "source_record": None,
            "context_id": context_id,
        }
    if man_gate not in (0, 1):
        raise ValueError("man_gate must be 0, 1, or None")
    if man_gate == 0:
        return {
            "status": "source_not_instantiated",
            "application": None,
            "source_record": None if source is None else list(source),
            "context_id": context_id,
        }
    if context_id is None or not validate_source_descriptors(source):
        return {
            "status": "source_unresolved",
            "application": None,
            "source_record": None if source is None else list(source),
            "context_id": context_id,
        }
    a, b, c = map(float, source)
    app_id = f"e_man::{case_id}"
    source_signal_token = z_toy if z_toy is not None else f"z_toy::{case_id}"
    return {
        "status": "application_established",
        "application": {
            "application_id": app_id,
            "episode_id": case_id,
            "source_signal_token": source_signal_token,
            "lambda_man": f"lambda_man::{case_id}",
            "z_to_lambda_man_bridge": "fixed_token_map_z_toy_to_lambda_man",
            "manifestation_context": context_id,
            "manifestation_output": f"m_toy::{case_id}",
            "construction_role": "synthetic_positive_manifestation_application_premise",
        },
        "source_record": {
            "record_id": f"q_src::{case_id}",
            "application_id": app_id,
            "a": a,
            "b": b,
            "c": c,
            "role": "model_local_descriptor_registry_not_intrinsic_manifestation_output_structure",
        },
        "context_id": context_id,
    }


def construct_alignment(
    case_id: str,
    perceptual_result: Dict[str, Any],
    man: Dict[str, Any],
    context_id: Optional[str] = ALIGNMENT_CONTEXT_ID,
    force_mismatch: bool = False,
) -> Dict[str, Any]:
    if context_id is None:
        return {"status": None, "context_id": None, "record": None}
    if not perceptual_result.get("formed"):
        return {"status": None, "context_id": context_id, "record": None}
    if man.get("application") is None:
        return {"status": None, "context_id": context_id, "record": None}
    same_episode = perceptual_result.get("episode") == case_id and man["application"].get("episode_id") == case_id
    perceptual_ep = perceptual_result.get("episode_record") or {}
    same_signal_token = perceptual_ep.get("z_toy") == man["application"].get("source_signal_token")
    perceptual_bridge = perceptual_ep.get("rho_lambda_bridge") == "fixed_token_map_z_toy_to_lambda_perc"
    man_bridge = man["application"].get("z_to_lambda_man_bridge") == "fixed_token_map_z_toy_to_lambda_man"
    status = int(bool(same_episode and same_signal_token and perceptual_bridge and man_bridge) and not force_mismatch)
    rec = {
        "record_id": f"align::{case_id}",
        "context_id": context_id,
        "perceptual_episode": perceptual_result.get("episode"),
        "source_signal_token": perceptual_ep.get("z_toy"),
        "perceptual_lambda_perc": perceptual_ep.get("lambda_perc"),
        "perceptual_z_bridge": perceptual_ep.get("rho_lambda_bridge"),
        "perceptual_formed_token": None if perceptual_result.get("formed_application") is None else perceptual_result["formed_application"].get("formed_token"),
        "manifestation_application_id": man["application"]["application_id"],
        "manifestation_lambda": man["application"].get("lambda_man"),
        "manifestation_z_bridge": man["application"].get("z_to_lambda_man_bridge"),
        "same_episode_provenance": bool(same_episode),
        "same_signal_token": bool(same_signal_token),
        "status": status,
        
    }
    return {"status": status, "context_id": context_id, "record": rec}


def conditioning_record(case_id: str, perceptual_result: Dict[str, Any], alignment: Dict[str, Any]) -> Dict[str, Any]:
    if alignment.get("status") != 1:
        return {"status": "not_available", "record": None, "u_dist": None, "u_red": None, "red_apply": None}

    required = {
        "J_stab_toy": perceptual_result.get("J_stab_toy"),
        "sig_sup": perceptual_result.get("sig_sup"),
        "support_discordant": perceptual_result.get("support_discordant"),
        "false_completion": perceptual_result.get("false_completion"),
        "ell_toy": perceptual_result.get("ell_toy"),
        "r_toy": perceptual_result.get("r_toy"),
    }
    if not all(is_defined_number(v) for v in required.values()):
        return {
            "status": "conditioning_unresolved",
            "record": {
                "record_id": f"cond::{case_id}",
                "alignment_record_id": alignment["record"]["record_id"],
                **{k: v for k, v in required.items()},
                "selected_index": perceptual_result.get("selected_index"),
                "dominant_index": perceptual_result.get("dominant_index"),
            },
            "u_dist": None,
            "u_red": None,
            "red_apply": None,
        }

    J = float(required["J_stab_toy"])
    sig = int(required["sig_sup"])
    disc = int(required["support_discordant"])
    fc = int(required["false_completion"])
    ell = float(required["ell_toy"])
    r = float(required["r_toy"])

    u_dist = clip01(
        PARAMS["dist_d0"]
        + PARAMS["dist_gamma_one_minus_J"] * (1.0 - J)
        + PARAMS["dist_gamma_sig_sup_negative"] * int(sig == 0)
        + PARAMS["dist_gamma_support_discordant"] * int(disc == 1)
        + PARAMS["dist_gamma_false_completion"] * int(fc == 1)
        + PARAMS["dist_beta_ell"] * ell
        + PARAMS["dist_beta_r"] * r
    )
    u_red = clip01(
        PARAMS["red_r0"]
        + PARAMS["red_eta_one_minus_J"] * (1.0 - J)
        + PARAMS["red_eta_sig_sup_negative"] * int(sig == 0)
        + PARAMS["red_eta_ell"] * ell
        + PARAMS["red_eta_r"] * r
    )
    red_apply = int(u_red >= PARAMS["theta_red"])
    rec = {
        "record_id": f"cond::{case_id}",
        "alignment_record_id": alignment["record"]["record_id"],
        "J_stab_toy": J,
        "stab_lvl": perceptual_result.get("stab_lvl"),
        "perc_stab": perceptual_result.get("perc_stab"),
        "sig_sup": sig,
        "support_discordant": disc,
        "false_completion": fc,
        "ell_toy": ell,
        "r_toy": r,
        "selected_index": perceptual_result.get("selected_index"),
        "dominant_index": perceptual_result.get("dominant_index"),
        "u_dist": u_dist,
        "u_red": u_red,
        "red_apply": red_apply,
        "role": "model_local_pre_capture_conditioning_not_fidelity_measure",
    }
    return {"status": "defined", "record": rec, "u_dist": u_dist, "u_red": u_red, "red_apply": red_apply}


def quantize_q21(x: float) -> str:
    if not _finite01(x):
        raise ValueError("Q21 quantization requires x in [0,1]")
    idx = min(20, max(0, int(math.floor(20.0 * float(x) + 0.5))))
    return f"q{idx:02d}"


def decode_q21(token: str) -> float:
    if not isinstance(token, str) or len(token) != 3 or not token.startswith("q") or not token[1:].isdigit():
        raise ValueError(f"invalid Q21 token: {token!r}")
    idx = int(token[1:])
    if not 0 <= idx <= 20:
        raise ValueError(f"invalid Q21 index: {idx}")
    return 0.05 * idx


def make_candidate_form(
    case_id: str,
    payload: Sequence[str],
    header: str = FORM_HEADER,
    alphabet: str = CODEBOOK_ID,
) -> Dict[str, Any]:
    return {
        "candidate_form_id": f"symcand::{case_id}",
        "header": header,
        "alphabet": alphabet,
        "payload": list(payload),
        "form_context_id": FORM_CONTEXT_ID,
    }


def generate_standard_candidate(
    case_id: str,
    man: Dict[str, Any],
    cond: Dict[str, Any],
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
    if man.get("application") is None or man.get("source_record") is None:
        return None, None
    if cond.get("status") != "defined":
        return None, None
    src = man["source_record"]
    a, b, c = float(src["a"]), float(src["b"]), float(src["c"])
    u_dist = float(cond["u_dist"])
    a_star = clip01(a + PARAMS["kappa_dist"] * u_dist)
    b_star = clip01(b - PARAMS["kappa_dist"] * u_dist)
    red_apply = int(cond["red_apply"])
    payload = [quantize_q21(a_star), quantize_q21(b_star), OMISSION if red_apply else quantize_q21(c)]
    candidate = make_candidate_form(case_id, payload)
    enc = {
        "encoder_record_id": f"enc::{case_id}",
        "encoder_id": ENCODER_ID,
        "source_application_id": man["application"]["application_id"],
        "candidate_form_id": candidate["candidate_form_id"],
        "conditioning_record_id": cond["record"]["record_id"],
        "u_dist": u_dist,
        "u_red": float(cond["u_red"]),
        "red_apply": red_apply,
        "prequantized": {"a_star": a_star, "b_star": b_star, "c_star": None if red_apply else c},
        "role": "model_local_encoder_provenance_not_capture_status",
    }
    return candidate, enc


def candidate_from_symbolic_values(case_id: str, symbolic: Sequence[Any]) -> Dict[str, Any]:
    if len(symbolic) != 3:
        raise ValueError("symbolic override must have exactly three positions")
    payload: List[str] = []
    for i, x in enumerate(symbolic):
        if i == 2 and x == OMISSION:
            payload.append(OMISSION)
        else:
            payload.append(quantize_q21(float(x)))
    return make_candidate_form(case_id, payload)


def symform_status(candidate: Optional[Dict[str, Any]], form_context_present: bool = True) -> Optional[int]:
    if candidate is None or not form_context_present:
        return None
    payload = candidate.get("payload")
    if candidate.get("form_context_id") != FORM_CONTEXT_ID:
        return 0
    if candidate.get("header") != FORM_HEADER or candidate.get("alphabet") != CODEBOOK_ID:
        return 0
    if not isinstance(payload, list) or len(payload) != 3:
        return 0
    try:
        decode_q21(payload[0]); decode_q21(payload[1])
    except Exception:
        return 0
    if payload[2] != OMISSION:
        try:
            decode_q21(payload[2])
        except Exception:
            return 0
    return 1


def symcap_status(
    man: Dict[str, Any],
    positive_form_application: Optional[Dict[str, Any]],
    encoder_record: Optional[Dict[str, Any]],
    capture_context_present: bool = True,
) -> Optional[int]:
    """Evaluate capture only on an explicit positive symbolic-form application."""
    if positive_form_application is None:
        return None
    if not capture_context_present or encoder_record is None or man.get("application") is None:
        return None
    required_fields = ("encoder_id", "source_application_id", "candidate_form_id")
    if any(encoder_record.get(k) is None for k in required_fields):
        return None
    correct = (
        positive_form_application.get("symform") == 1
        and positive_form_application.get("form_context_id") == FORM_CONTEXT_ID
        and encoder_record.get("encoder_id") == ENCODER_ID
        and encoder_record.get("source_application_id") == man["application"]["application_id"]
        and encoder_record.get("candidate_form_id") == positive_form_application.get("candidate_form_id")
    )
    return int(correct)


def build_positive_capture_application(
    case_id: str,
    man: Dict[str, Any],
    positive_form_application: Optional[Dict[str, Any]],
    symcap: Optional[int],
) -> Optional[Dict[str, Any]]:
    if symcap != 1 or positive_form_application is None or man.get("application") is None:
        return None
    return {
        "capture_application_id": f"e_symcap::{case_id}",
        "source_application_id": man["application"]["application_id"],
        "positive_form_application_id": positive_form_application.get("form_application_id"),
        "positive_form_application": positive_form_application,
        "capture_context_id": CAPTURE_CONTEXT_ID,
        "symcap": 1,
    }

def decode_candidate(candidate: Dict[str, Any]) -> Tuple[float, float, Optional[float]]:
    payload = candidate["payload"]
    a_p = decode_q21(payload[0])
    b_p = decode_q21(payload[1])
    c_p = None if payload[2] == OMISSION else decode_q21(payload[2])
    return a_p, b_p, c_p


def evaluate_fidelity(
    man: Dict[str, Any],
    candidate: Optional[Dict[str, Any]],
    positive_capture_application: Optional[Dict[str, Any]],
    profile_applicable: bool = True,
) -> Dict[str, Any]:
    """Evaluate the fixed profile only on an explicit positive capture application."""
    if positive_capture_application is None or not profile_applicable or candidate is None or man.get("source_record") is None:
        return {
            "profile_id": None,
            "fidelity_application": None,
            "fidelity_application_id": None,
            "sym_pres": None,
            "sym_red": None,
            "sym_dist": None,
            "D_sym_toy_p": None,
            "source_descriptors": None,
            "symbolic_descriptors": None,
        }
    captured_form = positive_capture_application.get("positive_form_application") or {}
    capture_matches = (
        positive_capture_application.get("symcap") == 1
        and positive_capture_application.get("capture_context_id") == CAPTURE_CONTEXT_ID
        and positive_capture_application.get("source_application_id") == man.get("application", {}).get("application_id")
        and positive_capture_application.get("positive_form_application_id") == captured_form.get("form_application_id")
        and captured_form.get("form_context_id") == FORM_CONTEXT_ID
        and captured_form.get("candidate_form_id") == candidate.get("candidate_form_id")
    )
    if not capture_matches:
        return {
            "profile_id": None,
            "fidelity_application": None,
            "fidelity_application_id": None,
            "sym_pres": None,
            "sym_red": None,
            "sym_dist": None,
            "D_sym_toy_p": None,
            "source_descriptors": None,
            "symbolic_descriptors": None,
        }
    src = man["source_record"]
    a, b, c = float(src["a"]), float(src["b"]), float(src["c"])
    a_p, b_p, c_p = decode_candidate(candidate)
    gap_delta = abs((b_p - a_p) - (b - a))
    sym_pres = int(b_p > a_p and gap_delta <= PARAMS["epsilon_gap_pres"] + 1e-12)
    sym_red = int(c_p is None)
    sym_dist = int(b_p <= a_p)
    D = 0.5 * (abs(a_p - a) + abs(b_p - b))
    fid_id = f"e_fid::{positive_capture_application['capture_application_id']}::{FIDELITY_PROFILE_ID}"
    fid_app = {
        "fidelity_application_id": fid_id,
        "positive_capture_application_id": positive_capture_application["capture_application_id"],
        "source_application_id": positive_capture_application["source_application_id"],
        "positive_form_application_id": positive_capture_application["positive_form_application_id"],
        "profile_id": FIDELITY_PROFILE_ID,
        "source_descriptor_record_id": src["record_id"],
        "candidate_form_id": candidate["candidate_form_id"],
    }
    return {
        "profile_id": FIDELITY_PROFILE_ID,
        "fidelity_application": fid_app,
        "fidelity_application_id": fid_id,
        "sym_pres": sym_pres,
        "sym_red": sym_red,
        "sym_dist": sym_dist,
        "D_sym_toy_p": float(D),
        "source_descriptors": [a, b, c],
        "symbolic_descriptors": [a_p, b_p, c_p],
        "gap_delta": float(gap_delta),
        "D_zero_semantics": "protected_pair_exact_equality_only",
    }

def evaluate_case(
    case_id: str,
    perceptual_spec: Dict[str, Any],
    *,
    man_gate: Optional[int] = 1,
    source: Optional[Sequence[Any]] = (0.20, 0.80, 0.50),
    alignment_context_present: bool = True,
    force_alignment_mismatch: bool = False,
    candidate_mode: str = "standard",  # standard | absent | supplied
    supplied_candidate: Optional[Dict[str, Any]] = None,
    form_context_present: bool = True,
    encoder_provenance_mode: str = "standard",  # standard | correct | mismatch | missing
    capture_context_present: bool = True,
    profile_applicable: bool = True,
) -> Dict[str, Any]:
    source_z_toy = perceptual_spec.get("z_toy", f"z_toy::{case_id}")
    perceptual_result = evaluate_perceptual_episode(case_id, perceptual_spec)
    man = construct_manifestation_application(case_id, man_gate, source, z_toy=source_z_toy)
    alignment = construct_alignment(
        case_id,
        perceptual_result,
        man,
        context_id=ALIGNMENT_CONTEXT_ID if alignment_context_present else None,
        force_mismatch=force_alignment_mismatch,
    )
    cond = conditioning_record(case_id, perceptual_result, alignment)

    candidate: Optional[Dict[str, Any]] = None
    encoder_record: Optional[Dict[str, Any]] = None
    if candidate_mode == "standard":
        candidate, encoder_record = generate_standard_candidate(case_id, man, cond)
    elif candidate_mode == "absent":
        candidate, encoder_record = None, None
    elif candidate_mode == "supplied":
        candidate = supplied_candidate
        if candidate is not None and man.get("application") is not None:
            encoder_record = {
                "encoder_record_id": f"enc::{case_id}",
                "encoder_id": ENCODER_ID,
                "source_application_id": man["application"]["application_id"],
                "candidate_form_id": candidate.get("candidate_form_id"),
                "conditioning_record_id": None if cond.get("record") is None else cond["record"].get("record_id"),
                "role": "supplied_test_candidate_provenance",
            }
    else:
        raise ValueError(f"unknown candidate_mode {candidate_mode!r}")

    if encoder_provenance_mode == "missing":
        encoder_record = None
    elif encoder_provenance_mode == "mismatch" and encoder_record is not None:
        encoder_record = dict(encoder_record)
        encoder_record["source_application_id"] = f"e_man::different_source::{case_id}"
    elif encoder_provenance_mode not in ("standard", "correct", "mismatch", "missing"):
        raise ValueError(f"unknown encoder_provenance_mode {encoder_provenance_mode!r}")

    symform = symform_status(candidate, form_context_present=form_context_present)
    positive_form_app = None
    if symform == 1 and candidate is not None:
        positive_form_app = {
            "form_application_id": f"e_symform::{case_id}",
            "candidate_form_id": candidate["candidate_form_id"],
            "form_context_id": candidate.get("form_context_id"),
            "symform": 1,
        }
    symcap = symcap_status(man, positive_form_app, encoder_record, capture_context_present=capture_context_present)
    positive_capture_app = build_positive_capture_application(case_id, man, positive_form_app, symcap)
    fid = evaluate_fidelity(man, candidate, positive_capture_app, profile_applicable=profile_applicable)

    return {
        "model_version": MODEL_VERSION,
        "case_id": case_id,
        "perceptual_result": perceptual_result,
        "perceptual_formed": perceptual_result.get("formed"),
        "perceptual_route_status": perceptual_result.get("route_status"),
        "perceptual_J_stab_toy": perceptual_result.get("J_stab_toy"),
        "perceptual_stab_lvl": perceptual_result.get("stab_lvl"),
        "perceptual_perc_stab": perceptual_result.get("perc_stab"),
        "perceptual_sig_sup": perceptual_result.get("sig_sup"),
        "perceptual_support_discordant": perceptual_result.get("support_discordant"),
        "perceptual_false_completion": perceptual_result.get("false_completion"),
        "perceptual_selected_index": perceptual_result.get("selected_index"),
        "perceptual_dominant_index": perceptual_result.get("dominant_index"),
        "manifestation_status": man.get("status"),
        "manifestation_application": man.get("application"),
        "source_record": man.get("source_record"),
        "alignment_status": alignment.get("status"),
        "alignment_record": alignment.get("record"),
        "conditioning_status": cond.get("status"),
        "conditioning_record": cond.get("record"),
        "u_dist": cond.get("u_dist"),
        "u_red": cond.get("u_red"),
        "red_apply": cond.get("red_apply"),
        "candidate_form": candidate,
        "encoder_record": encoder_record,
        "symform": symform,
        "positive_form_application": positive_form_app,
        "symcap": symcap,
        "positive_capture_application": positive_capture_app,
        "fidelity_profile_id": fid.get("profile_id"),
        "fidelity_application": fid.get("fidelity_application"),
        "fidelity_application_id": fid.get("fidelity_application_id"),
        "sym_pres": fid.get("sym_pres"),
        "sym_red": fid.get("sym_red"),
        "sym_dist": fid.get("sym_dist"),
        "D_sym_toy_p": fid.get("D_sym_toy_p"),
        "fidelity_source_descriptors": fid.get("source_descriptors"),
        "fidelity_symbolic_descriptors": fid.get("symbolic_descriptors"),
        "fidelity_gap_delta": fid.get("gap_delta"),
        "interpretive_limits": INTERPRETIVE_LIMITS,
    }


def compact_record(result: Dict[str, Any]) -> Dict[str, Any]:
    """Compact result record for deterministic and Monte Carlo analyses."""
    src_raw = result.get("source_record")
    if isinstance(src_raw, dict):
        src = src_raw
    elif isinstance(src_raw, (list, tuple)) and len(src_raw) == 3:
        src = {"a": src_raw[0], "b": src_raw[1], "c": src_raw[2]}
    else:
        src = {}
    man_app = result.get("manifestation_application") or {}
    align = result.get("alignment_record") or {}
    cond = result.get("conditioning_record") or {}
    cand = result.get("candidate_form") or {}
    enc = result.get("encoder_record") or {}
    pos_form = result.get("positive_form_application") or {}
    pos_cap = result.get("positive_capture_application") or {}
    payload = cand.get("payload")
    return {
        "case_id": result.get("case_id"),
        "model_version": result.get("model_version"),
        "perceptual_route_status": result.get("perceptual_route_status"),
        "perceptual_formed": result.get("perceptual_formed"),
        "perceptual_J_stab_toy": result.get("perceptual_J_stab_toy"),
        "perceptual_stab_lvl": result.get("perceptual_stab_lvl"),
        "perceptual_perc_stab": result.get("perceptual_perc_stab"),
        "perceptual_sig_sup": result.get("perceptual_sig_sup"),
        "perceptual_support_discordant": result.get("perceptual_support_discordant"),
        "perceptual_false_completion": result.get("perceptual_false_completion"),
        "perceptual_selected_index": result.get("perceptual_selected_index"),
        "perceptual_dominant_index": result.get("perceptual_dominant_index"),
        "manifestation_status": result.get("manifestation_status"),
        "manifestation_application_id": man_app.get("application_id"),
        "manifestation_context_id": man_app.get("manifestation_context"),
        "source_signal_token": man_app.get("source_signal_token"),
        "source_descriptor_record_id": src.get("record_id"),
        "source_a": src.get("a"),
        "source_b": src.get("b"),
        "source_c": src.get("c"),
        "alignment_status": result.get("alignment_status"),
        "alignment_record_id": align.get("record_id"),
        "alignment_context_id": align.get("context_id"),
        "conditioning_status": result.get("conditioning_status"),
        "conditioning_record_id": cond.get("record_id"),
        "u_dist": result.get("u_dist"),
        "u_red": result.get("u_red"),
        "red_apply": result.get("red_apply"),
        "candidate_form_id": cand.get("candidate_form_id"),
        "candidate_form_context_id": cand.get("form_context_id"),
        "candidate_payload": None if payload is None else json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
        "encoder_record_id": enc.get("encoder_record_id"),
        "encoder_id": enc.get("encoder_id"),
        "symform": result.get("symform"),
        "positive_form_application_id": pos_form.get("form_application_id"),
        "symcap": result.get("symcap"),
        "capture_application_id": pos_cap.get("capture_application_id"),
        "capture_source_application_id": pos_cap.get("source_application_id"),
        "capture_positive_form_application_id": pos_cap.get("positive_form_application_id"),
        "capture_context_id": pos_cap.get("capture_context_id"),
        "fidelity_profile_id": result.get("fidelity_profile_id"),
        "fidelity_application_id": result.get("fidelity_application_id"),
        "fidelity_positive_capture_application_id": (result.get("fidelity_application") or {}).get("positive_capture_application_id"),
        "fidelity_source_application_id": (result.get("fidelity_application") or {}).get("source_application_id"),
        "fidelity_positive_form_application_id": (result.get("fidelity_application") or {}).get("positive_form_application_id"),
        "fidelity_source_descriptor_record_id": (result.get("fidelity_application") or {}).get("source_descriptor_record_id"),
        "fidelity_candidate_form_id": (result.get("fidelity_application") or {}).get("candidate_form_id"),
        "sym_pres": result.get("sym_pres"),
        "sym_red": result.get("sym_red"),
        "sym_dist": result.get("sym_dist"),
        "D_sym_toy_p": result.get("D_sym_toy_p"),
        "interpretive_limits": json.dumps(result.get("interpretive_limits"), separators=(",", ":")),
    }
