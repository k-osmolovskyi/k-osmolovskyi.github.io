"""Finite-coordinate toy realization of a partial cross-system qualitative mapping.

This module implements the local numerical assumptions used in the accompanying
article. Mapping definedness, target construction, profile-relative quality, and
quality classification are kept separate.
"""
from __future__ import annotations
import numpy as np

DOMAIN_THRESHOLD = 0.50
PRESERVED_THRESHOLD = 0.10
PARTIAL_THRESHOLD = 0.30
C_B = np.array([
    [0.80, 0.20, 0.00],
    [0.20, 0.60, 0.20],
    [0.00, 0.20, 0.80],
], dtype=float)

def clip01(x):
    return np.clip(np.asarray(x,dtype=float),0.0,1.0)

def source_projection(q_A, B_A_plus, B_A_minus, B_A_undef):
    vals=np.asarray([q_A,B_A_plus,B_A_minus],dtype=float)
    if not np.isfinite(vals).all() or np.any(vals<0) or np.any(vals>1):
        return None
    if not np.isfinite(float(B_A_undef)) or float(B_A_undef)!=0.0:
        return None
    return vals

def domain_support(H,C,L,P,B_A_plus):
    return float(clip01(0.20+0.25*H+0.20*C+0.15*(1-L)+0.10*(1-P)+0.10*B_A_plus))

def self_retention(H,C,L,P):
    return float(clip01(0.40+0.30*H+0.30*C-0.20*L-0.25*P*(1-H)))

def map_point(z_A,H,C,L,P,xi=(0.0,0.0,0.0)):
    z_A=np.asarray(z_A,dtype=float)
    xi=np.asarray(xi,dtype=float)
    if z_A.shape!=(3,) or xi.shape!=(3,) or not np.isfinite(z_A).all() or not np.isfinite(xi).all():
        return None
    rho=self_retention(H,C,L,P)
    M=rho*np.eye(3)+(1-rho)*C_B
    return clip01(M@z_A+xi)

def component_loss(z_A,z_B):
    return np.abs(np.asarray(z_A,dtype=float)-np.asarray(z_B,dtype=float))

def scalar_loss(loss_vector):
    return float(np.mean(np.asarray(loss_vector,dtype=float)))

def quality_class(ell):
    if ell<=PRESERVED_THRESHOLD: return 'preserved'
    if ell<=PARTIAL_THRESHOLD: return 'partial'
    return 'distorted'

def evaluate(q_A,B_A_plus,B_A_minus,B_A_undef,H,C,L,P,xi=(0.0,0.0,0.0)):
    z_A=source_projection(q_A,B_A_plus,B_A_minus,B_A_undef)
    if z_A is None:
        return {'projection_defined':False,'mapped':None,'S_dom_AB':None,'rho_AB':None,'z_A':None,'z_B':None,'loss':None,'ell_coord':None,'quality_class':None}
    S=domain_support(H,C,L,P,B_A_plus)
    mapped=S>=DOMAIN_THRESHOLD
    if not mapped:
        return {'projection_defined':True,'mapped':False,'S_dom_AB':S,'rho_AB':None,'z_A':z_A,'z_B':None,'loss':None,'ell_coord':None,'quality_class':'unmapped'}
    rho=self_retention(H,C,L,P)
    z_B=map_point(z_A,H,C,L,P,xi)
    loss=component_loss(z_A,z_B)
    ell=scalar_loss(loss)
    return {'projection_defined':True,'mapped':True,'S_dom_AB':S,'rho_AB':rho,'z_A':z_A,'z_B':z_B,'loss':loss,'ell_coord':ell,'quality_class':quality_class(ell)}
