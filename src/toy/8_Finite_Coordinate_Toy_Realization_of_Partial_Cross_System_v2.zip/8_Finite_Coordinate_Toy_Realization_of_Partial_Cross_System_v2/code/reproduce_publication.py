from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; FIG=ROOT/'figures'; TAB=ROOT/'tables'
sys.path.insert(0,str(Path(__file__).resolve().parent))
from finite_coordinate_mapping_model import *

checks=[]
def check(name,cond):
    checks.append((name,bool(cond)))
    if not cond: raise AssertionError(name)

def close(a,b,tol=1e-12): return abs(float(a)-float(b))<=tol

fix=pd.read_csv(DATA/'fixture_summary.csv')
for _,r in fix.iterrows():
    ev=evaluate(r.q_A,r.B_A_plus,r.B_A_minus,r.B_A_undef,r.HistAlignCtx_AB,r.CueAccess_B,r.RecvLoad_B,r.PriorDom_B,(r.xi_0,r.xi_1,r.xi_2))
    check(f"{r.fixture_id}: domain support",close(ev['S_dom_AB'],r.S_dom_AB))
    check(f"{r.fixture_id}: mapped",int(ev['mapped'])==int(r.mapped))
    if int(r.mapped):
        check(f"{r.fixture_id}: rho",close(ev['rho_AB'],r.rho_AB))
        check(f"{r.fixture_id}: scalar loss",close(ev['ell_coord'],r.ell_coord))
        check(f"{r.fixture_id}: class",ev['quality_class']==r.quality_class)
    else:
        check(f"{r.fixture_id}: no fabricated loss",ev['ell_coord'] is None)

# Core boundary checks
check('undefined projection remains undefined', source_projection(0.2,0.4,0.4,0.1) is None)
check('unmapped is not maximal loss', evaluate(0.0,0.5918367346938775,0.40816326530612246,0.0,0.25,0.30,0.80,0.80)['ell_coord'] is None)
check('quality thresholds ordered', PRESERVED_THRESHOLD < PARTIAL_THRESHOLD)

# Article-level summaries
sf=pd.read_csv(DATA/'deterministic_final_summary.csv')
check('deterministic families all mapped', np.allclose(sf.mapped_share,1.0))
check('deterministic families no distorted cases', int(sf.D_distorted.sum())==0)
mc=pd.read_csv(DATA/'monte_carlo_summary.csv')
check('Monte Carlo mapped shares between zero and one', bool(((mc.mapped_share>0)&(mc.mapped_share<1)).all()))
check('positive pre-readout occurs among unmapped cases', int(mc.D_PreRead1_map0.sum())>0)
check('no zero-pre-readout mapped case in declared strata', int(mc.D_PreRead0_map1.sum())==0)

# Figure 1: architecture
fig,ax=plt.subplots(figsize=(16,4.8)); ax.axis('off')
labels=[
    'Source qualitative-\napplication record',
    '$Q_A$ point +\nreduced $z_A$',
    'Receiver context +\nlocal $\\xi_{AB}$',
    'Partial $\\phi_{AB}^{\\chi}$\n$Q_{read}/Q_{unmap}$',
    'Target qualitative token\n/ $Q_B$ point',
    'Profile-relative\n$MapQual$',
    'Frame-relative class\n$\\ell_{coord}$',
]
xs=np.linspace(0.06,0.94,len(labels)); y=.62
for i,(x,lbl) in enumerate(zip(xs,labels)):
    w=.12 if i not in [3,4] else .135
    box=FancyBboxPatch((x-w/2,y-.105),w,.21,boxstyle='round,pad=0.012',fill=False,linewidth=1.5)
    ax.add_patch(box); ax.text(x,y,lbl,ha='center',va='center',fontsize=10)
    if i<len(labels)-1:
        ax.annotate('',xy=(xs[i+1]-.07,y),xytext=(x+w/2+.008,y),arrowprops=dict(arrowstyle='->',lw=1.4))
ax.text(.5,.18,'PreRead is retained as an adjacent source status; target alignment, mapping grounding, bidirectional asymmetry, and feedback adaptation are not constructed.',ha='center',va='center',fontsize=10,style='italic')
fig.tight_layout(); fig.savefig(FIG/'architecture.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# Figure 2
mapped=fix[fix.mapped==1].copy(); x=np.arange(len(fix)); width=.24
fig,ax=plt.subplots(figsize=(10.5,5.2))
for j,col in enumerate(['e_0','e_1','e_2']): ax.bar(x+(j-1)*width,fix[col].fillna(0),width,label=col)
ax.axhline(PRESERVED_THRESHOLD,linestyle='--',linewidth=1); ax.axhline(PARTIAL_THRESHOLD,linestyle=':',linewidth=1)
ax.set_xticks(x); ax.set_xticklabels(fix.fixture_id,rotation=25,ha='right'); ax.set_ylabel('coordinate loss'); ax.set_title('M0-M4 fixture coordinate-loss profiles'); ax.legend()
fig.tight_layout(); fig.savefig(FIG/'fixture_coordinate_losses.png',dpi=180); plt.close(fig)

# Context surfaces from the fixed final source anchor
anchor=fix.iloc[0]; zA=np.array([anchor.q_A,anchor.B_A_plus,anchor.B_A_minus])
grid=np.linspace(0,1,201)

def surface(which):
    dom=np.empty((201,201)); ell=np.full((201,201),np.nan)
    for iy,a in enumerate(grid):
        for ix,b in enumerate(grid):
            if which=='G1': H,C,L,P=b,a,0.40,0.50
            else: H,C,L,P=0.25,0.30,b,a
            S=domain_support(H,C,L,P,anchor.B_A_plus); dom[iy,ix]=S
            if S>=DOMAIN_THRESHOLD:
                zb=map_point(zA,H,C,L,P,(0,0,0)); ell[iy,ix]=scalar_loss(component_loss(zA,zb))
    return dom,ell
for which,name,xlab,ylab in [
    ('G1','context_surface_history_cue.png','HistAlignCtx_AB','CueAccess_B'),
    ('G2','context_surface_load_prior.png','RecvLoad_B','PriorDom_B')]:
    dom,ell=surface(which)
    fig,axs=plt.subplots(1,2,figsize=(12.5,5))
    im=axs[0].imshow(dom,origin='lower',extent=[0,1,0,1],aspect='auto'); axs[0].contour(grid,grid,dom,levels=[DOMAIN_THRESHOLD],colors='k',linewidths=1); fig.colorbar(im,ax=axs[0]); axs[0].set_title(f'{which}: domain support $S_{{dom}}$')
    im2=axs[1].imshow(ell,origin='lower',extent=[0,1,0,1],aspect='auto'); fig.colorbar(im2,ax=axs[1]); axs[1].set_title(f'{which}: $\\ell_{{coord}}$ on mapped cells')
    for a in axs: a.set_xlabel(xlab); a.set_ylabel(ylab)
    fig.tight_layout(); fig.savefig(FIG/name,dpi=180); plt.close(fig)
    check(f'{which}: contains mapped and unmapped cells', np.isfinite(ell).any() and np.isnan(ell).any())

# Deterministic domain share
step=pd.read_csv(DATA/'deterministic_step_summary.csv')
fig,ax=plt.subplots(figsize=(9.5,5))
for fam,g in step.groupby('family'): ax.plot(g.t,g.mapped_share,marker='o',markersize=2,label=fam)
ax.set_ylim(0,1.03); ax.set_xlabel('t'); ax.set_ylabel('$|Q_{read}|$ / source rows'); ax.set_title('S1-S4 mapping-domain share over evaluation time'); ax.legend(ncol=4)
fig.tight_layout(); fig.savefig(FIG/'deterministic_mapping_domain_share.png',dpi=180); plt.close(fig)

# Deterministic final loss distributions
ell=pd.read_csv(DATA/'deterministic_final_loss_distribution.csv.gz')
fig,ax=plt.subplots(figsize=(9.5,5))
series=[ell.loc[ell.family==f,'ell_coord'].values for f in ['S1','S2','S3','S4']]
ax.boxplot(series,labels=['S1','S2','S3','S4'],showfliers=False); ax.axhline(PRESERVED_THRESHOLD,linestyle='--',linewidth=1); ax.axhline(PARTIAL_THRESHOLD,linestyle=':',linewidth=1); ax.set_ylabel('$\\ell_{coord}$ on $Q_{qe}$'); ax.set_title('S1-S4 final coordinate-loss distributions')
fig.tight_layout(); fig.savefig(FIG/'deterministic_final_loss_distributions.png',dpi=180); plt.close(fig)

# Monte Carlo result figure
m=mc.copy(); x=np.arange(len(m));
fig,axs=plt.subplots(1,2,figsize=(12,5))
axs[0].bar(x,m.mapped_share,label='mapped'); axs[0].bar(x,1-m.mapped_share,bottom=m.mapped_share,label='unmapped'); axs[0].set_xticks(x); axs[0].set_xticklabels(m.family); axs[0].set_ylim(0,1); axs[0].set_ylabel('share of stratum'); axs[0].set_title('Mapping-domain outcome'); axs[0].legend()
vals=[m.D_PreRead1_map1/m.N,m.D_PreRead1_map0/m.N,m.D_PreRead0_map1/m.N,m.D_PreRead0_map0/m.N]
width=.18
for j,(v,lbl) in enumerate(zip(vals,['1/map','1/unmap','0/map','0/unmap'])): axs[1].bar(x+(j-1.5)*width,v,width,label=lbl)
axs[1].set_xticks(x); axs[1].set_xticklabels(m.family); axs[1].set_ylabel('share of stratum'); axs[1].set_title('$PreRead \\times$ mappedness'); axs[1].legend()
fig.tight_layout(); fig.savefig(FIG/'monte_carlo_domain_quality_preread.png',dpi=180); plt.close(fig)

# Tables and macros
macros=[]
for _,r in sf.iterrows():
    word={'S1':'One','S2':'Two','S3':'Three','S4':'Four'}[r.family]
    macros += [f'\\newcommand{{\\S{word}MapShare}}{{{r.mapped_share:.4f}}}',f'\\newcommand{{\\S{word}MeanEll}}{{{r.mean_ell_coord:.4f}}}',f'\\newcommand{{\\S{word}MedianEll}}{{{r.median_ell_coord:.4f}}}']
for idx,r in mc.iterrows():
    word=['One','Two','Three'][idx]
    macros += [f'\\newcommand{{\\MC{word}MapPct}}{{{100*r.mapped_share:.2f}\\%}}',f'\\newcommand{{\\MC{word}MeanEll}}{{{r.mean_ell_coord:.4f}}}',f'\\newcommand{{\\MC{word}PreZeroMap}}{{{int(r.D_PreRead0_map1)}}}',f'\\newcommand{{\\MC{word}PreZeroUnmap}}{{{int(r.D_PreRead0_map0)}}}']
(TAB/'results_macros.tex').write_text('\n'.join(macros)+'\n')

rows=[]
for _,r in fix.iterrows():
    ell='--' if pd.isna(r.ell_coord) else f'{r.ell_coord:.4f}'
    rho='--' if pd.isna(r.rho_AB) else f'{r.rho_AB:.4f}'
    fid=str(r.fixture_id).replace('_',r'\_')
    ctx=str(r.source_context).replace('_',r'\_')
    rows.append(f"{fid} & {ctx} & {int(r.PreRead)} & {r.S_dom_AB:.4f} & {int(r.mapped)} & {rho} & {ell} & {r.quality_class} " + r"\\")
fixture_lines=[
    r'\begin{table}[H]', r'\centering', r'\small',
    r'\caption{M0--M4 fixtures. Quality fields are shown only for mapped points.}',
    r'\resizebox{\textwidth}{!}{%',
    r'\begin{tabular}{l l c r c r r l}', r'\toprule',
    r'Fixture & source context & PreRead & $S_{dom}$ & map & $\rho$ & $\ell_{coord}$ & class \\',
    r'\midrule', *rows, r'\bottomrule', r'\end{tabular}%', r'}', r'\end{table}'
]
(TAB/'fixture_summary_table.tex').write_text('\n'.join(fixture_lines)+'\n')

srows=[]
for _,r in sf.iterrows():
    srows.append(f"{r.family} & {int(r.D_source_total)} & {int(r.D_map_defined_Qread)} & {int(r.D_map_unmapped_Qunmap)} & {int(r.D_loss_defined)} & {int(r.D_preserved)} & {int(r.D_partial)} & {int(r.D_distorted)} & {r.mean_ell_coord:.4f} & {r.median_ell_coord:.4f} " + r"\\")
s_lines=[
    r'\begin{table}[H]', r'\centering', r'\scriptsize',
    r'\caption{S1--S4 final mapping-domain and quality denominators.}',
    r'\begin{tabular}{l r r r r r r r r r}', r'\toprule',
    r'Fam. & total & mapped & unmap & $Q_{qe}$ & pres. & partial & dist. & mean $\ell$ & median $\ell$ \\',
    r'\midrule', *srows, r'\bottomrule', r'\end{tabular}', r'\end{table}'
]
(TAB/'deterministic_summary_table.tex').write_text('\n'.join(s_lines)+'\n')

mrows=[]
for _,r in mc.iterrows():
    mrows.append(f"{r.family} & {int(r.N)} & {int(r.D_map_defined_Qread)} & {int(r.D_map_unmapped_Qunmap)} & {int(r.D_preserved)} & {int(r.D_partial)} & {int(r.D_distorted)} & {int(r.D_PreRead1_map1)} & {int(r.D_PreRead1_map0)} & {int(r.D_PreRead0_map1)} & {int(r.D_PreRead0_map0)} & {r.mean_ell_coord:.4f} & {r.median_ell_coord:.4f} " + r"\\")
m_lines=[
    r'\begin{table}[H]', r'\centering', r'\scriptsize',
    r'\caption{Monte Carlo strata: mapping/quality denominators and PreRead $\times$ mappedness. Strata are not pooled.}',
    r'\resizebox{\textwidth}{!}{%',
    r'\begin{tabular}{l r r r r r r r r r r r r}', r'\toprule',
    r'Fam. & $N$ & map & unmap & pres. & partial & dist. & 1/map & 1/unmap & 0/map & 0/unmap & mean $\ell$ & median $\ell$ \\',
    r'\midrule', *mrows, r'\bottomrule', r'\end{tabular}%', r'}', r'\end{table}'
]
(TAB/'monte_carlo_summary_table.tex').write_text('\n'.join(m_lines)+'\n')

print(f'Structural consistency checks: {sum(v for _,v in checks)}/{len(checks)} PASS')
