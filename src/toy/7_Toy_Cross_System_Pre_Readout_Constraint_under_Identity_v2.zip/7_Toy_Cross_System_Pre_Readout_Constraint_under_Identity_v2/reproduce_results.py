"""Reproduce article figures/tables from the archived scientific result summaries.

The deterministic and Monte Carlo score distributions are included as data files.
This script checks their internal consistency, reproduces all publication figures,
and writes the LaTeX tables/macros used by the article.
"""
from pathlib import Path
import csv
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pre_readout_constraint_model import (
    SourceRecord, ReceiverContext, evaluate, expression_support,
    PRE_READ_THRESHOLD, LOW_THRESHOLD, HIGH_THRESHOLD, clip01
)

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
FIG = ROOT / "figures"
TAB = ROOT / "tables"
FIG.mkdir(exist_ok=True)
TAB.mkdir(exist_ok=True)

ANCHOR = SourceRecord(
    family="S1", trajectory_index=0, case_id="S1_00000_00000", t=20,
    q_A=0.0, N_pos=29, N_neg=20, N_undef=0,
    B_A_plus=29/49, B_A_minus=20/49, B_A_undef=0.0,
)

FIXTURES = [
    ReceiverContext("C0_supportive", 0.80, 0.80, 0.20, 0.20),
    ReceiverContext("C1_low_hist_align", 0.20, 0.80, 0.20, 0.20),
    ReceiverContext("C2_low_cue_access", 0.80, 0.20, 0.20, 0.20),
    ReceiverContext("C3_receiver_pressure", 0.25, 0.30, 0.80, 0.80),
    ReceiverContext("C4_mid_support", 0.60, 0.60, 0.50, 0.50),
]


def load_data():
    return {
        "step": pd.read_csv(DATA / "deterministic_family_step_summary.csv"),
        "sfinal": pd.read_csv(DATA / "deterministic_family_final_summary.csv"),
        "sdist": pd.read_csv(DATA / "deterministic_final_score_distribution.csv"),
        "mcfinal": pd.read_csv(DATA / "monte_carlo_final_summary.csv"),
        "mcdist": pd.read_csv(DATA / "monte_carlo_final_score_distribution.csv"),
        "denom": pd.read_csv(DATA / "definedness_summary.csv"),
        "fixtures": pd.read_csv(DATA / "receiver_fixture_summary.csv"),
    }


def write_checks(d):
    checks=[]
    def add(name, ok): checks.append((name, bool(ok)))

    add("anchor_valid", ANCHOR.valid())
    add("anchor_fixed_denominator", ANCHOR.N_pos + ANCHOR.N_neg + ANCHOR.N_undef == 49)
    add("anchor_breadth_sum", abs(ANCHOR.B_A_plus + ANCHOR.B_A_minus + ANCHOR.B_A_undef - 1) < 1e-12)
    add("anchor_expression_defined", expression_support(ANCHOR) is not None)
    add("anchor_expression_value", abs(expression_support(ANCHOR) - 0.6775510204081633) < 1e-12)

    fx=d["fixtures"]
    for ctx in FIXTURES:
        r=evaluate(ANCHOR,ctx)
        row=fx.loc[fx.context_id==ctx.label].iloc[0]
        add(f"fixture_{ctx.label}_score", abs(r.C_pre_AB-row.C_pre_AB)<1e-12)
        add(f"fixture_{ctx.label}_preread", int(r.PreRead)==int(row.PreRead))

    # Undefined breadth must remain undefined rather than becoming PreRead=0.
    u=SourceRecord("U",0,"U0",0,0.2,28,20,1,28/49,20/49,1/49)
    ur=evaluate(u,ReceiverContext("valid",0.5,0.5,0.4,0.5))
    add("undefined_breadth_blocks_expression", not ur.expression_defined)
    add("undefined_breadth_not_preread_zero", not ur.preread_defined and ur.PreRead is None)

    # A valid extreme receiver context can produce defined no-readout.
    hi=SourceRecord("H",0,"H0",20,1.0,0,49,0,0.0,1.0,0.0)
    hr=evaluate(hi,ReceiverContext("extreme",0,0,1,1))
    add("defined_no_readout_reachable", hr.preread_defined and hr.PreRead==0 and hr.C_pre_AB>=PRE_READ_THRESHOLD)

    # Deterministic summaries and distributions.
    sf=d["sfinal"]; sd=d["sdist"]
    add("deterministic_families_complete", set(sf.family)=={"S1","S2","S3","S4"})
    for _,r in sf.iterrows():
        z=sd.loc[sd.family==r.family,"C_pre_AB"].to_numpy(float)
        add(f"{r.family}_row_count", len(z)==int(r.D_source_total))
        add(f"{r.family}_mean", abs(z.mean()-r.mean_C_pre)<1e-12)
        add(f"{r.family}_median", abs(np.median(z)-r.median_C_pre)<1e-12)
        add(f"{r.family}_min", abs(z.min()-r.min_C_pre)<1e-12)
        add(f"{r.family}_max", abs(z.max()-r.max_C_pre)<1e-12)
        add(f"{r.family}_threshold", np.all(z<PRE_READ_THRESHOLD))
        add(f"{r.family}_denominator_partition", int(r.D_PreRead_positive+r.D_PreRead_zero+r.D_PreRead_undefined)==int(r.D_source_total))

    # Step summaries have exactly 21 evaluation positions per deterministic family.
    st=d["step"]
    add("step_index_range", set(st.t)==set(range(21)))
    add("step_rows_per_family", all(len(st.loc[st.family==f])==21 for f in ["S1","S2","S3","S4"]))

    # Monte Carlo summaries and distributions stay stratum-specific.
    mf=d["mcfinal"]; md=d["mcdist"]
    add("monte_carlo_strata_complete", set(mf.family)=={"MC-M1","MC-M2","MC-M3"})
    add("monte_carlo_seeds", list(mf.sort_values('family').seed)==[2029,2030,2031])
    for _,r in mf.iterrows():
        z=md.loc[md.family==r.family,"C_pre_AB"].to_numpy(float)
        add(f"{r.family}_row_count", len(z)==int(r.D_source_total))
        add(f"{r.family}_mean", abs(z.mean()-r.mean_C_pre)<1e-12)
        add(f"{r.family}_median", abs(np.median(z)-r.median_C_pre)<1e-12)
        add(f"{r.family}_min", abs(z.min()-r.min_C_pre)<1e-12)
        add(f"{r.family}_max", abs(z.max()-r.max_C_pre)<1e-12)
        add(f"{r.family}_defined_partition", int(r.D_PreRead_positive+r.D_PreRead_zero+r.D_PreRead_undefined)==int(r.D_source_total))
        add(f"{r.family}_threshold_count", int(np.sum(z>=PRE_READ_THRESHOLD))==int(r.D_PreRead_zero))

    # Published denominator ledger agrees with the two summary tables.
    den=d["denom"].set_index("family")
    for _,r in pd.concat([sf,mf],ignore_index=True).iterrows():
        q=den.loc[r.family]
        add(f"{r.family}_denominator_ledger", int(q.D_source_total)==int(r.D_source_total) and int(q.D_PreRead_zero)==int(r.D_PreRead_zero))

    out=pd.DataFrame(checks,columns=["check","pass"])
    out.to_csv(DATA/"structural_consistency_checks.csv",index=False)
    if not out["pass"].all():
        raise RuntimeError(out.loc[~out['pass']].to_dict('records'))
    return out


def make_architecture_figure():
    fig, ax = plt.subplots(figsize=(10,3.2)); ax.axis('off')
    labels=["Source identity-\ncontinuation record","Qualitative-\nexpression application","Receiver\ncontext","Local $C^{pre}_{AB}$","ReadDisc","PreRead"]
    xs=np.linspace(.08,.92,len(labels))
    for i,(x,lbl) in enumerate(zip(xs,labels)):
        ax.text(x,.62,lbl,ha='center',va='center',bbox=dict(boxstyle='round,pad=.35',fc='white',ec='black'),fontsize=9)
        if i<len(labels)-1:
            ax.annotate('',xy=(xs[i+1]-.07,.62),xytext=(x+.07,.62),arrowprops=dict(arrowstyle='->'))
    ax.text(.50,.15,'Formal cross-system mapping and mapping-domain machinery are not constructed in this model.',ha='center',va='center',style='italic',fontsize=9)
    fig.tight_layout(); fig.savefig(FIG/'architecture_provenance.png',dpi=180,bbox_inches='tight'); plt.close(fig)


def make_surfaces():
    H=np.linspace(0,1,201); C=np.linspace(0,1,201); HH,CC=np.meshgrid(H,C)
    x=expression_support(ANCHOR)
    z=np.clip(.20+.25*ANCHOR.q_A+.20*ANCHOR.B_A_minus+.20*.40+.20*.50*(1-HH)-.20*x-.25*HH-.25*CC,0,1)
    fig,ax=plt.subplots(figsize=(6.4,5.2)); im=ax.imshow(z,origin='lower',extent=[0,1,0,1],aspect='auto'); fig.colorbar(im,ax=ax,label='$C^{pre}_{AB}$'); ax.set_xlabel('History-alignment context $H$'); ax.set_ylabel('Cue access $C$'); ax.set_title('Receiver-support surface'); ax.contour(HH,CC,z,levels=[.30],linewidths=1); fig.tight_layout(); fig.savefig(FIG/'history_alignment_cue_access_surface.png',dpi=180); plt.close(fig)

    L=np.linspace(0,1,201); P=np.linspace(0,1,201); LL,PP=np.meshgrid(L,P)
    z=np.clip(.20+.25*ANCHOR.q_A+.20*ANCHOR.B_A_minus+.20*LL+.20*PP*(1-.25)-.20*x-.25*.25-.25*.30,0,1)
    fig,ax=plt.subplots(figsize=(6.4,5.2)); im=ax.imshow(z,origin='lower',extent=[0,1,0,1],aspect='auto'); fig.colorbar(im,ax=ax,label='$C^{pre}_{AB}$'); ax.set_xlabel('Receiver load $L$'); ax.set_ylabel('Prior dominance $P$'); ax.set_title('Receiver-pressure surface'); ax.contour(LL,PP,z,levels=[.30],linewidths=1); fig.tight_layout(); fig.savefig(FIG/'receiver_load_prior_dominance_surface.png',dpi=180); plt.close(fig)


def make_result_figures(d):
    st=d['step']
    fig,ax=plt.subplots(figsize=(7.2,4.2))
    for fam,g in st.groupby('family'):
        ax.plot(g.t,g.mean_C_pre,label=fam)
    ax.axhline(.30,linestyle='--',linewidth=.8); ax.axhline(.60,linestyle='--',linewidth=.8)
    ax.set_xlabel('Evaluation index $t$'); ax.set_ylabel('Mean $C^{pre}_{AB}$'); ax.set_title('Mean local constraint score over evaluation index'); ax.legend(); fig.tight_layout(); fig.savefig(FIG/'deterministic_mean_score_trajectory.png',dpi=180); plt.close(fig)

    sd=d['sdist']; bins=np.linspace(0,1,61)
    fig,ax=plt.subplots(figsize=(7.2,4.2))
    for fam,g in sd.groupby('family'):
        ax.hist(g.C_pre_AB,bins=bins,histtype='step',density=True,label=fam)
    ax.axvline(.60,linestyle='--',linewidth=.8); ax.set_xlabel('Final $C^{pre}_{AB}$'); ax.set_ylabel('Density'); ax.set_title('Deterministic-family final score distributions'); ax.legend(); fig.tight_layout(); fig.savefig(FIG/'deterministic_final_score_distributions.png',dpi=180); plt.close(fig)

    md=d['mcdist']
    fig,ax=plt.subplots(figsize=(7.2,4.2))
    for fam,g in md.groupby('family'):
        ax.hist(g.C_pre_AB,bins=bins,histtype='step',density=True,label=fam)
    ax.axvline(.60,linestyle='--',linewidth=.8); ax.set_xlabel('Final $C^{pre}_{AB}$'); ax.set_ylabel('Density'); ax.set_title('Monte Carlo stratum-specific final score distributions'); ax.legend(); fig.tight_layout(); fig.savefig(FIG/'monte_carlo_final_score_distributions.png',dpi=180); plt.close(fig)

    mf=d['mcfinal'].copy(); mf['positive']=mf.D_PreRead_positive/mf.D_source_total; mf['zero']=mf.D_PreRead_zero/mf.D_source_total; mf['undefined']=mf.D_PreRead_undefined/mf.D_source_total
    x=np.arange(len(mf)); w=.25
    fig,ax=plt.subplots(figsize=(7.2,4.2)); ax.bar(x-w,mf.positive,w,label='positive'); ax.bar(x,mf.zero,w,label='defined no-readout'); ax.bar(x+w,mf.undefined,w,label='undefined'); ax.set_xticks(x,mf.family); ax.set_ylabel('Frequency'); ax.set_ylim(0,1.05); ax.set_title('Stratum-specific PreRead frequencies'); ax.legend(); fig.tight_layout(); fig.savefig(FIG/'monte_carlo_preread_frequencies.png',dpi=180); plt.close(fig)


def latex_escape(s): return str(s).replace('_','\\_')


def write_tables(d):
    fx=d['fixtures']
    lines=['\\begin{table}[t]','\\centering','\\caption{Receiver-context fixtures evaluated on the declared source anchor.}','\\label{tab:fixtures}','\\small','\\begin{tabular}{lrrrrrr}','\\toprule','Context & $H$ & $C$ & $L$ & $P$ & $C^{pre}_{AB}$ & PreRead \\\\','\\midrule']
    for _,r in fx.iterrows():
        lines.append(f"{latex_escape(r.context_id)} & {r.HistAlignCtx_AB:.2f} & {r.CueAccess_B:.2f} & {r.RecvLoad_B:.2f} & {r.PriorDom_B:.2f} & {r.C_pre_AB:.3f} & {int(r.PreRead)} \\\\")
    lines += ['\\midrule','\\multicolumn{7}{l}{\\scriptsize Anchor: S1, trajectory 0, case S1\\_00000\\_00000, $t=20$.} \\\\','\\bottomrule','\\end{tabular}','\\end{table}']
    (TAB/'receiver_fixture_summary_table.tex').write_text('\n'.join(lines))

    def summary_table(df,caption,label):
        a=['\\begin{table}[t]','\\centering',f'\\caption{{{caption}}}',f'\\label{{{label}}}','\\scriptsize','\\begin{tabular}{lrrrrrrr}','\\toprule','Family & $D$ & score def. & PreRead $1$ & PreRead $0$ & undef. & mean $C^{pre}$ & median $C^{pre}$ \\\\','\\midrule']
        for _,r in df.iterrows():
            a.append(f"{r.family} & {int(r.D_source_total):,} & {int(r.D_score_defined):,} & {int(r.D_PreRead_positive):,} & {int(r.D_PreRead_zero):,} & {int(r.D_PreRead_undefined):,} & {r.mean_C_pre:.4f} & {r.median_C_pre:.4f} \\\\")
        a += ['\\bottomrule','\\end{tabular}','\\end{table}']; return '\n'.join(a)
    (TAB/'deterministic_summary_table.tex').write_text(summary_table(d['sfinal'],'Final deterministic-family denominator, score, and PreRead summary.','tab:s-summary'))
    (TAB/'monte_carlo_summary_table.tex').write_text(summary_table(d['mcfinal'],'Final Monte Carlo stratum-specific denominator, score, and PreRead summary.','tab:mc-summary'))

    sf=d['sfinal'].set_index('family'); mf=d['mcfinal'].set_index('family')
    def pct(r): return 100*r.D_PreRead_positive/r.D_source_total
    macros=[
        f"\\newcommand{{\\SOneMeanC}}{{{sf.loc['S1'].mean_C_pre:.6f}}}",
        f"\\newcommand{{\\STwoMeanC}}{{{sf.loc['S2'].mean_C_pre:.6f}}}",
        f"\\newcommand{{\\SThreeMeanC}}{{{sf.loc['S3'].mean_C_pre:.6f}}}",
        f"\\newcommand{{\\SFourMeanC}}{{{sf.loc['S4'].mean_C_pre:.6f}}}",
        f"\\newcommand{{\\MCOneMeanC}}{{{mf.loc['MC-M1'].mean_C_pre:.6f}}}",
        f"\\newcommand{{\\MCTwoMeanC}}{{{mf.loc['MC-M2'].mean_C_pre:.6f}}}",
        f"\\newcommand{{\\MCThreeMeanC}}{{{mf.loc['MC-M3'].mean_C_pre:.6f}}}",
        f"\\newcommand{{\\MCOnePreReadPosPct}}{{{pct(mf.loc['MC-M1']):.2f}\\%}}",
        f"\\newcommand{{\\MCTwoPreReadPosPct}}{{{pct(mf.loc['MC-M2']):.2f}\\%}}",
        f"\\newcommand{{\\MCThreePreReadPosPct}}{{{pct(mf.loc['MC-M3']):.2f}\\%}}",
    ]
    (TAB/'results_macros.tex').write_text('\n'.join(macros)+'\n')


def main():
    d=load_data(); checks=write_checks(d); make_architecture_figure(); make_surfaces(); make_result_figures(d); write_tables(d)
    print(f"Structural consistency checks: {int(checks['pass'].sum())}/{len(checks)} passed")

if __name__=='__main__': main()
