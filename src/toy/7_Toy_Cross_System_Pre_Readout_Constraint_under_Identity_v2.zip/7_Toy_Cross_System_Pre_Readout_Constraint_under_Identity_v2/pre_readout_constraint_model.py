"""Core equations for a toy model of cross-system pre-readout constraint.

The module implements only the scientific objects used in the article:
source-side identity-continuation breadth, a local expression-support descriptor,
receiver context, the pre-readout constraint score, receiver discrimination, and
partial PreRead status. It intentionally does not construct a formal cross-system
mapping or mapping-quality object.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import isfinite
from typing import Optional

TOL = 1e-12
PRE_READ_THRESHOLD = 0.60
LOW_THRESHOLD = 0.30
HIGH_THRESHOLD = 0.60
DENOMINATOR = 49


def clip01(x: float) -> float:
    return min(1.0, max(0.0, float(x)))


def finite01(x: float) -> bool:
    try:
        y = float(x)
    except Exception:
        return False
    return isfinite(y) and 0.0 <= y <= 1.0


@dataclass
class SourceRecord:
    family: str
    trajectory_index: int
    case_id: str
    t: int
    q_A: float
    N_pos: int
    N_neg: int
    N_undef: int
    B_A_plus: float
    B_A_minus: float
    B_A_undef: float

    def valid(self) -> bool:
        if not self.family or not self.case_id or self.trajectory_index < 0 or not (0 <= self.t <= 20):
            return False
        if not finite01(self.q_A):
            return False
        if min(self.N_pos, self.N_neg, self.N_undef) < 0:
            return False
        if self.N_pos + self.N_neg + self.N_undef != DENOMINATOR:
            return False
        if not all(finite01(x) for x in (self.B_A_plus, self.B_A_minus, self.B_A_undef)):
            return False
        if abs(self.B_A_plus + self.B_A_minus + self.B_A_undef - 1.0) > TOL:
            return False
        return (
            abs(self.B_A_plus - self.N_pos / DENOMINATOR) <= TOL
            and abs(self.B_A_minus - self.N_neg / DENOMINATOR) <= TOL
            and abs(self.B_A_undef - self.N_undef / DENOMINATOR) <= TOL
        )

    @property
    def record_id(self) -> str:
        return f"{self.family}:traj={self.trajectory_index}:case={self.case_id}:t={self.t}"


@dataclass
class ReceiverContext:
    label: str
    H: float
    C: float
    L: float
    P: float

    def valid(self) -> bool:
        return bool(self.label) and all(finite01(x) for x in (self.H, self.C, self.L, self.P))


@dataclass
class ReadoutResult:
    source_id: str
    context_label: str
    expression_defined: bool
    X_A_expr: Optional[float]
    score_defined: bool
    C_pre_AB: Optional[float]
    score_class: Optional[str]
    read_disc_defined: bool
    read_disc_nonempty: Optional[bool]
    preread_defined: bool
    PreRead: Optional[int]


def expression_support(source: SourceRecord) -> Optional[float]:
    if not source.valid() or abs(source.B_A_undef) > TOL:
        return None
    return clip01(0.50 - 0.30 * source.q_A + 0.30 * source.B_A_plus)


def constraint_score(source: SourceRecord, context: ReceiverContext) -> Optional[float]:
    x = expression_support(source)
    if x is None or not context.valid():
        return None
    return clip01(
        0.20
        + 0.25 * source.q_A
        + 0.20 * source.B_A_minus
        + 0.20 * context.L
        + 0.20 * context.P * (1.0 - context.H)
        - 0.20 * x
        - 0.25 * context.H
        - 0.25 * context.C
    )


def score_class(c: float) -> str:
    if c <= LOW_THRESHOLD:
        return "low_constraint"
    if c < HIGH_THRESHOLD:
        return "intermediate_constraint"
    return "high_constraint"


def evaluate(source: SourceRecord, context: ReceiverContext) -> ReadoutResult:
    x = expression_support(source)
    if x is None or not context.valid():
        return ReadoutResult(
            source.record_id, context.label, x is not None, x, False, None, None,
            False, None, False, None
        )
    c = constraint_score(source, context)
    assert c is not None
    nonempty = c < PRE_READ_THRESHOLD
    return ReadoutResult(
        source.record_id,
        context.label,
        True,
        x,
        True,
        c,
        score_class(c),
        True,
        nonempty,
        True,
        1 if nonempty else 0,
    )
