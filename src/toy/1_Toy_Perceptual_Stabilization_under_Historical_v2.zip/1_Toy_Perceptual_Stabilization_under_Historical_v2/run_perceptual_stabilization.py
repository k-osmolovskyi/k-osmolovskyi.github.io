"""Run the toy perceptual-stabilization model, structural tests, and figures."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from perceptual_stabilization_model import (
    MODEL_VERSION, PARAMS, SCENARIOS, STRUCTURAL_TESTS, EXPECTED_TESTS,
    evaluate_episode, run_structural_tests, effective_match_threshold,
    signal_support_threshold, update_dominance,
)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)


def compact_row(r):
    return {
        "episode": r["episode"],
        "route_status": r["route_status"],
        "recruited_indices": ";".join(str(i) for i in r["recruited_indices"]),
        "selected_index": r["selected_index"],
        "dominant_index": r["dominant_index"],
        "J_stab_toy": r["J_stab_toy"],
        "stab_lvl": r["stab_lvl"],
        "perc_stab": r["perc_stab"],
        "tau_sup_eff": r["tau_sup_eff"],
        "sig_sup": r["sig_sup"],
        "support_discordant": r["support_discordant"],
        "false_completion": r["false_completion"],
    }


def write_tables(scenario_results, test_results):
    sdf = pd.DataFrame([compact_row(x) for x in scenario_results])
    sdf.to_csv(OUT / "scenario_status.csv", index=False)
    rows = []
    for x in test_results:
        row = compact_row(x["result"])
        row.update({"test": x["test"], "pass": x["pass"], "mismatches": " | ".join(x["mismatches"])})
        rows.append(row)
    tdf = pd.DataFrame(rows)
    tdf.to_csv(OUT / "structural_tests.csv", index=False)
    with open(OUT / "run_record.json", "w", encoding="utf-8") as f:
        json.dump({"model_version": MODEL_VERSION, "parameters": PARAMS,
                   "scenarios": scenario_results, "structural_tests": test_results}, f, indent=2, default=str)
    return sdf, tdf


def plot_recruitment_map():
    n = 220
    M_vals = np.linspace(0, 1, n)
    ell_vals = np.linspace(0, 1, n)
    P = 0.90
    arr = np.zeros((n, n))
    for i, ell in enumerate(ell_vals):
        th = effective_match_threshold(ell, [P])[0]
        for j, m in enumerate(M_vals):
            arr[i, j] = int(m >= th)
    plt.figure(figsize=(7.2, 5.1))
    plt.imshow(arr, origin="lower", extent=[0,1,0,1], aspect="auto")
    plt.colorbar(label="Recruit status: 0 negative, 1 positive")
    plt.xlabel(r"Toy partial-match score $M^{toy}$")
    plt.ylabel(r"Normalized retained-overload coordinate $\ell^{toy}$")
    plt.title(r"Toy recruitment realization at $P^{toy}=0.90$")
    plt.tight_layout(); plt.savefig(OUT / "recruitment_map.png", dpi=200); plt.close()


def plot_stabilization_level_map():
    n = 220
    M_vals = np.linspace(0,1,n)
    P_vals = np.linspace(0,1,n)
    ell, r = 0.50, 0.50
    arr = np.full((n,n), -1.0)
    for i,p in enumerate(P_vals):
        for j,m in enumerate(M_vals):
            res = evaluate_episode("stab_grid", {"ell":ell,"r":r,"M":[float(m)],"P":[float(p)],"Sup":None})
            if res["formed"] and res["stab_lvl"] is not None:
                arr[i,j] = float(res["stab_lvl"])
    plt.figure(figsize=(7.2,5.1))
    plt.imshow(arr, origin="lower", extent=[0,1,0,1], aspect="auto", vmin=-1, vmax=2)
    plt.colorbar(label="Display code: -1 no route; formed StabLvl 0, 1, 2")
    plt.xlabel(r"Toy partial-match score $M^{toy}$")
    plt.ylabel(r"Historical-dominance parameter $P^{toy}$")
    plt.title(r"Toy stabilization level after valid route formation ($\ell^{toy}=r^{toy}=0.50$)")
    plt.tight_layout(); plt.savefig(OUT / "stabilization_level_map.png", dpi=200); plt.close()


def plot_signal_support_map():
    n = 220
    sup_vals = np.linspace(0,1,n)
    ell_vals = np.linspace(0,1,n)
    r = 0.40
    M_fixed, P_fixed = 0.85, 0.60
    arr = np.full((n,n), np.nan)
    for i,ell in enumerate(ell_vals):
        for j,sup in enumerate(sup_vals):
            res = evaluate_episode("support_grid", {"ell":float(ell),"r":r,"M":[M_fixed],"P":[P_fixed],"Sup":[float(sup)]})
            if res["formed"] and res["sig_sup"] is not None:
                arr[i,j] = float(res["sig_sup"])
    plt.figure(figsize=(7.2,5.1))
    plt.imshow(arr, origin="lower", extent=[0,1,0,1], aspect="auto", vmin=0, vmax=1)
    plt.colorbar(label="SigSup status: 0 negative, 1 positive")
    plt.xlabel(r"Toy current-signal support $S^{sup,toy}$")
    plt.ylabel(r"Normalized retained-overload coordinate $\ell^{toy}$")
    plt.title(r"SigSup on a fixed valid formed route ($M^{toy}=0.85$, $P^{toy}=0.60$, $r^{toy}=0.40$)")
    plt.tight_layout(); plt.savefig(OUT / "signal_support_map.png", dpi=200); plt.close()


def plot_discordance_overlay():
    n = 240
    M_vals = np.linspace(0,1,n)
    Sup_vals = np.linspace(0,1,n)
    ell, r, P = 0.70, 0.40, 0.90
    grid = np.full((n,n), -1.0)
    for i,sup in enumerate(Sup_vals):
        for j,m in enumerate(M_vals):
            res = evaluate_episode("grid", {"ell":ell,"r":r,"M":[float(m)],"P":[P],"Sup":[float(sup)]})
            if not res["formed"]:
                code=-1
            elif res["support_discordant"] == 1:
                code=2 if res["false_completion"] == 1 else 1
            else:
                code=0
            grid[i,j]=code
    plt.figure(figsize=(7.2,5.1))
    plt.imshow(grid, origin="lower", extent=[0,1,0,1], aspect="auto", vmin=-1, vmax=2)
    plt.colorbar(label="Display code: -1 no route, 0 other formed, 1 discordant, 2 false-completion flag")
    plt.xlabel(r"Toy partial-match score $M^{toy}$")
    plt.ylabel(r"Toy current-signal support $S^{sup,toy}$")
    plt.title(r"Support discordance and derived false-completion flag ($P^{toy}=0.90$)")
    plt.tight_layout(); plt.savefig(OUT / "support_discordance_overlay.png", dpi=200); plt.close()


def plot_threshold_modulation():
    ell_grid = np.linspace(0,1,200)
    r_fixed = 0.40
    plt.figure(figsize=(7.2,5.1))
    for p in [0.2,0.5,0.9]:
        vals=[effective_match_threshold(e,[p])[0] for e in ell_grid]
        plt.plot(ell_grid, vals, label=fr"recruitment threshold, $P^{{toy}}={p}$")
    sup=[signal_support_threshold(e,r_fixed) for e in ell_grid]
    plt.plot(ell_grid, sup, label=fr"support threshold, $r^{{toy}}={r_fixed}$")
    plt.xlabel(r"Normalized retained-overload coordinate $\ell^{toy}$")
    plt.ylabel("Toy effective threshold")
    plt.title("Overload modulation of recruitment and current-signal-support thresholds")
    plt.legend(); plt.tight_layout(); plt.savefig(OUT / "threshold_modulation.png", dpi=200); plt.close()


def plot_scenario_status(sdf):
    x=np.arange(len(sdf)); width=.18
    def val(col): return [np.nan if pd.isna(v) else float(v) for v in sdf[col]]
    plt.figure(figsize=(9.0,5.2))
    plt.bar(x-1.5*width, val("stab_lvl"), width, label="StabLvl (0-2)")
    plt.bar(x-.5*width, val("perc_stab"), width, label="PercStab")
    plt.bar(x+.5*width, val("sig_sup"), width, label="SigSup")
    plt.bar(x+1.5*width, val("false_completion"), width, label="FalseComp")
    plt.xticks(x, [s.split("_")[0] for s in sdf["episode"]])
    plt.ylabel("Display value")
    plt.title("Illustrative scenarios A-E: separate model coordinates")
    plt.legend(); plt.tight_layout(); plt.savefig(OUT / "scenario_status.png", dpi=200); plt.close()


def plot_historical_dominance():
    T=40; p0=.45
    seqs={"full":[p0],"none":[p0],"false":[p0]}
    for _ in range(T-1):
        for event in seqs:
            seqs[event].append(update_dominance(seqs[event][-1], event))
    plt.figure(figsize=(7.2,5.1))
    for event, vals in seqs.items():
        plt.plot(range(T), vals, label=event)
    plt.xlabel("Toy episode")
    plt.ylabel(r"Simulation-only historical dominance $P^{toy}$")
    plt.title("Optional toy historical-dominance update trajectories")
    plt.legend(); plt.tight_layout(); plt.savefig(OUT / "historical_dominance.png", dpi=200); plt.close()


def run_implementation_checks():
    rows=[]
    x=evaluate_episode("selected_not_dominant", {"ell":0.10,"r":0.60,"M":[0.70,0.60],"P":[0.50,0.60],"Sup":[0.20,0.20]})
    rows.append({"test":"false_completion_requires_selected_equals_dominant",
                 "pass": x["selected_index"]==0 and x["dominant_index"]==1 and x["perc_stab"]==1 and x["sig_sup"]==0 and x["false_completion"]==0})
    x=evaluate_episode("support_missing", {"ell":0.20,"r":0.80,"M":[0.75],"P":[0.60],"Sup":None})
    rows.append({"test":"missing_support_remains_undefined",
                 "pass": x["formed"] and x["perc_stab"]==1 and x["sig_sup"] is None and x["false_completion"] is None})
    vals=[]
    for ell in (0.0,1.0):
        vals += [effective_match_threshold(ell,[p])[0] for p in (0.0,1.0)]
        for r in (0.0,1.0): vals.append(signal_support_threshold(ell,r))
    rows.append({"test":"effective_thresholds_respect_unit_interval", "pass": all(0.0 <= float(v) <= 1.0 for v in vals)})
    x=evaluate_episode("recruited_provenance", {"ell":0.20,"r":0.50,"M":[0.85,0.20],"P":[0.50,0.40],"Sup":[0.80,0.20]})
    fa=x["formed_application"]
    prov=[] if fa is None else [r["block_index"] for r in fa["recruited_synthetic_compression_provenance"]]
    rows.append({"test":"formed_provenance_is_restricted_to_recruited_field", "pass": x["recruited_indices"]==[0] and prov==[0]})
    rejected=0
    for bad in (-0.01,1.01):
        try:
            evaluate_episode("bad_coordinate", {"ell":bad,"r":0.5,"M":[0.8],"P":[0.5],"Sup":[0.8]})
        except ValueError:
            rejected += 1
    rows.append({"test":"out_of_domain_normalized_coordinates_are_rejected", "pass": rejected==2})
    pd.DataFrame(rows).to_csv(OUT/"implementation_checks.csv",index=False)
    return rows


def main():
    scenario_results=[evaluate_episode(name,spec) for name,spec in SCENARIOS.items()]
    test_results=run_structural_tests()
    sdf,tdf=write_tables(scenario_results,test_results)
    plot_recruitment_map(); plot_stabilization_level_map(); plot_signal_support_map()
    plot_discordance_overlay(); plot_threshold_modulation(); plot_scenario_status(sdf); plot_historical_dominance()
    checks=run_implementation_checks()
    failed=[x for x in test_results if not x["pass"]]
    if failed:
        raise SystemExit("Structural-test failure: " + repr([(x["test"],x["mismatches"]) for x in failed]))
    check_failed=[x for x in checks if not x["pass"]]
    if check_failed:
        raise SystemExit("Implementation-check failure: " + repr(check_failed))
    print("Model version", MODEL_VERSION)
    print("\nScenarios:\n", sdf.to_string(index=False))
    print("\nStructural tests:\n", tdf[["test","pass","route_status","stab_lvl","perc_stab","sig_sup","selected_index","dominant_index"]].to_string(index=False))

if __name__ == "__main__":
    main()
