"""Toy model of symbolic reuse and source-relative fidelity change.

The module implements the temporal trace/reuse layer and imports the symbolic-fidelity
model for each initial state. It does not create a fresh symbolic-capture application at
later reuse endpoints.
"""
from __future__ import annotations

from typing import Any, Dict, Optional, Sequence, List
import json, math

import symbolic_fidelity_model as symfid

MODEL_VERSION = "2.0"

GROUND_CONTEXT_ID = "GROUND-REF-v1"
TRACE_CONTEXT_ID = "TRACE-ROOT-PROVENANCE-v1"
REUSE_CONTEXT_ID = "REUSE-STEP-v1"
REF_POLICY_ID = "REF-REL3-v1"
GENERATOR_ID = "Q-TO-FORM-v1"

BASE_PARAMS = {"kappa": 0.25, "delta": 0.20, "S": 20, "eta_q_form": 1.0}
CLAIM_CEILING = [
    "toy_realization_only",
    "not_empirical_validation",
    "not_memory_retrieval",
    "not_belief_update",
    "not_semantic_truth",
    "not_fresh_later_symcap",
    "not_prevalence",
]


def clip01(x: float) -> float:
    return float(min(1.0, max(0.0, float(x))))




def canonical_json_equal(a: Any, b: Any) -> bool:
    """Compare nested records by canonical JSON serialization."""
    try:
        sa=json.dumps(a, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        sb=json.dumps(b, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        return sa == sb
    except (TypeError, ValueError):
        return False


def _finite01(x: Any) -> bool:
    try:
        y=float(x)
    except Exception:
        return False
    return math.isfinite(y) and 0.0 <= y <= 1.0


def _positive_form_from_symbolic_model(candidate: Dict[str,Any], symform: Optional[int], case_id: str, step: int) -> Optional[Dict[str,Any]]:
    """Construct a positive later-form application only from the exact imported symbolic-fidelity form criterion."""
    if not isinstance(candidate, dict) or symform != 1:
        return None
    # Do not allow callers to launder a supplied positive flag around the imported criterion/context.
    if candidate.get("form_context_id") != symfid.FORM_CONTEXT_ID:
        return None
    if symfid.symform_status(candidate, form_context_present=True) != 1:
        return None
    expected_candidate = f"symcand_reuse::{case_id}::s{step}"
    if candidate.get("candidate_form_id") != expected_candidate:
        return None
    return {
        "form_application_id": f"e_symform_reuse::{case_id}::s{step}",
        "candidate_form_id": candidate["candidate_form_id"],
        "form_context_id": symfid.FORM_CONTEXT_ID,
        "symform": 1,
        "candidate_form": candidate,
        "construction_role": "later_positive_symbolic_form_application",
    }


def initial_export(case_id: str, perceptual_spec: Dict[str,Any], *, source: Sequence[Any]=(0.2,0.8,0.5),
                   symbolic_overrides: Optional[Dict[str,Any]]=None) -> Dict[str,Any]:
    """Execute exact symbolic-fidelity and construct the model root export if eligible."""
    kw = dict(symbolic_overrides or {})
    r = symfid.evaluate_case(case_id, dict(perceptual_spec), source=source, **kw)

    prereq = [
        r.get("symform") == 1,
        isinstance(r.get("positive_form_application"), dict),
        r.get("symcap") == 1,
        isinstance(r.get("positive_capture_application"), dict),
        isinstance(r.get("fidelity_application"), dict),
        r.get("fidelity_profile_id") == symfid.FIDELITY_PROFILE_ID,
        _finite01(r.get("D_sym_toy_p")),
        isinstance(r.get("source_record"), dict),
        isinstance(r.get("fidelity_source_descriptors"), (list,tuple)),
        isinstance(r.get("fidelity_symbolic_descriptors"), (list,tuple)),
        isinstance(r.get("candidate_form"), dict),
    ]
    pair_ok = False
    decode_ok = False
    try:
        fs = r.get("fidelity_symbolic_descriptors")
        pair_ok = len(fs) >= 2 and _finite01(fs[0]) and _finite01(fs[1])
        dec = symfid.decode_candidate(r["candidate_form"])
        decode_ok = _finite01(dec[0]) and _finite01(dec[1])
    except Exception:
        pass
    prereq.extend([pair_ok, decode_ok])

    if all(prereq):
        cap = r["positive_capture_application"]
        pform = r["positive_form_application"]
        man = r["manifestation_application"]
        src = r["source_record"]
        fid = r["fidelity_application"]
        return {
            "init_status": "eligible",
            "InitElig": 1,
            "symbolic_case_id": case_id,
            "symbolic_result": r,
            "symbolic_input_perceptual_spec": dict(perceptual_spec),
            "symbolic_input_source": list(source),
            "symbolic_input_overrides": dict(kw),
            "manifestation_application_id": man["application_id"],
            "source_descriptor_record_id": src["record_id"],
            "source_descriptors": [src["a"], src["b"], src["c"]],
            "root_positive_form_application_id": pform["form_application_id"],
            "root_candidate_form": r["candidate_form"],
            "root_capture_application_id": cap["capture_application_id"],
            "root_capture_context_id": cap["capture_context_id"],
            "root_fidelity_application_id": fid["fidelity_application_id"],
            "root_fidelity_profile_id": r["fidelity_profile_id"],
            "initial_sym_pres": r["sym_pres"],
            "initial_sym_red": r["sym_red"],
            "initial_sym_dist": r["sym_dist"],
            "initial_D_sym_toy_p": float(r["D_sym_toy_p"]),
            "perceptual_route_status": r["perceptual_route_status"],
            "perceptual_formed": r["perceptual_formed"],
        }

    # Distinguish an explicitly positive capture lacking later model prerequisites
    # from a route whose formal statuses are unresolved/not instantiated.
    if r.get("symcap") == 1:
        status = "initial_route_not_instantiated"
    elif r.get("symcap") in (0,):
        status = "initial_route_not_instantiated"
    else:
        status = "initial_route_unresolved" if r.get("perceptual_route_status") == "route_unresolved" else "initial_route_not_instantiated"
    return {
        "init_status": status,
        "InitElig": 0,
        "symbolic_case_id": case_id,
        "symbolic_result": r,
        "symbolic_input_perceptual_spec": dict(perceptual_spec),
        "symbolic_input_source": list(source),
        "symbolic_input_overrides": dict(kw),
        "initial_D_sym_toy_p": None,
    }


def ground_reference(root: Dict[str,Any], trajectory_id: str, step: int, status: Optional[int]=1,
                     G: Optional[float]=0.0, *, context_present: bool=True,
                     provenance_mode: str="standard") -> Dict[str,Any]:
    """Realize the model source-reference basis; returns undefined/0/1 separately."""
    if root.get("InitElig") != 1:
        return {"ground_status": None, "G": None, "G_eff": None, "record": None}
    if status is None or not context_present:
        return {"ground_status": None, "G": G, "G_eff": None, "record": None}
    if status not in (0,1):
        raise ValueError("GroundRef status must be None/0/1")
    if status == 1 and not _finite01(G):
        raise ValueError("G must be in [0,1] when GroundRef=1")
    rec = {
        "ground_record_id": f"ground::{trajectory_id}::s{step}",
        "context_id": GROUND_CONTEXT_ID if context_present else None,
        "manifestation_application_id": root.get("manifestation_application_id"),
        "source_descriptor_record_id": root.get("source_descriptor_record_id"),
        "trajectory_id": trajectory_id,
        "step": step,
        "root_capture_application_id": root.get("root_capture_application_id"),
        "status": status,
        "provenance_mode": provenance_mode,
    }
    if provenance_mode != "standard":
        rec["root_capture_application_id"] = "mismatch::capture"
        status = 0
        rec["status"] = 0
    return {"ground_status": status, "G": G if status == 1 else None, "G_eff": float(G) if status == 1 else 0.0, "record": rec}


def q_proposal(q_s: Optional[float], U: Optional[float], ground: Dict[str,Any], *, kappa: float, delta: float) -> Optional[float]:
    if q_s is None or U is None or ground.get("ground_status") is None:
        return None
    if not (_finite01(q_s) and _finite01(U)):
        raise ValueError("q_s and U must be in [0,1]")
    if not (math.isfinite(kappa) and kappa >= 0 and math.isfinite(delta) and delta >= 0):
        raise ValueError("kappa/delta must be finite nonnegative")
    return clip01(float(q_s) + float(kappa)*float(U)*float(q_s) - float(delta)*float(ground["G_eff"]))


def propose_later_candidate(case_id: str, trajectory_id: str, step: int, prev_candidate: Optional[Dict[str,Any]],
                           q_s: Optional[float], q_prop: Optional[float], *, eta_q_form: float=1.0,
                           candidate_mode: str="standard") -> Dict[str,Any]:
    if prev_candidate is None or q_s is None or q_prop is None:
        return {"proposal_status": "undefined", "proposal_record": None, "candidate": None, "delta_q": None}
    if candidate_mode == "absent":
        return {"proposal_status": "candidate_absent", "proposal_record": None, "candidate": None, "delta_q": float(q_prop-q_s)}
    a,b,c = symfid.decode_candidate(prev_candidate)
    dq=float(q_prop-q_s)
    astar=clip01(a + float(eta_q_form)*dq)
    bstar=clip01(b - float(eta_q_form)*dq)
    cand=symfid.candidate_from_symbolic_values(f"{case_id}::reuse_s{step}", (astar,bstar,symfid.OMISSION if c is None else c))
    # Make the endpoint id trajectory-specific even when the case id is shared.
    cand["candidate_form_id"] = f"symcand_reuse::{trajectory_id}::s{step}"
    if candidate_mode == "malformed":
        cand["header"] = "BAD1"
    elif candidate_mode == "wrong_context":
        cand["form_context_id"] = "WRONG-CONTEXT"
    elif candidate_mode != "standard":
        raise ValueError(f"unknown candidate_mode {candidate_mode}")
    proposal={
        "proposal_record_id": f"proposal::{trajectory_id}::s{step}",
        "trajectory_id": trajectory_id,
        "step": step,
        "previous_candidate_form_id": prev_candidate.get("candidate_form_id"),
        "proposed_candidate_form_id": cand["candidate_form_id"],
        "q_s": float(q_s), "q_prop": float(q_prop), "delta_q": dq,
        "generator_id": GENERATOR_ID,
        "eta_q_form": float(eta_q_form),
        "prequantized_a": astar, "prequantized_b": bstar,
    }
    return {"proposal_status":"defined","proposal_record":proposal,"candidate":cand,"delta_q":dq}


def trace_status(root: Dict[str,Any], trajectory_id: str, step: int, previous_positive_form_id: str,
                 positive_later_form: Optional[Dict[str,Any]], proposal: Optional[Dict[str,Any]]=None, *,
                 context_present: bool=True, provenance_mode: str="standard") -> Dict[str,Any]:
    """Evaluate the model root trace on an exact proposal-linked later positive form."""
    if root.get("InitElig") != 1 or positive_later_form is None:
        return {"trace": None, "trace_record": None, "positive_trace_application": None}
    if not context_present or proposal is None:
        return {"trace": None, "trace_record": None, "positive_trace_application": None}
    expected_prev_form = root["root_positive_form_application_id"] if step == 1 else f"e_symform_reuse::{trajectory_id}::s{step-1}"
    expected_prev_candidate = root["root_candidate_form"].get("candidate_form_id") if step == 1 else f"symcand_reuse::{trajectory_id}::s{step-1}"
    expected_later = f"e_symform_reuse::{trajectory_id}::s{step}"
    expected_candidate = f"symcand_reuse::{trajectory_id}::s{step}"
    expected_proposal = f"proposal::{trajectory_id}::s{step}"
    prop_rec = proposal.get("proposal_record") if isinstance(proposal, dict) else None
    prop_cand = proposal.get("candidate") if isinstance(proposal, dict) else None
    structural_ok = (
        positive_later_form.get("symform") == 1
        and positive_later_form.get("form_context_id") == symfid.FORM_CONTEXT_ID
        and positive_later_form.get("form_application_id") == expected_later
        and positive_later_form.get("candidate_form_id") == expected_candidate
        and isinstance(positive_later_form.get("candidate_form"), dict)
        and positive_later_form.get("candidate_form",{}).get("candidate_form_id") == expected_candidate
        and previous_positive_form_id == expected_prev_form
        and proposal.get("proposal_status") == "defined"
        and isinstance(prop_rec, dict)
        and prop_rec.get("proposal_record_id") == expected_proposal
        and prop_rec.get("trajectory_id") == trajectory_id
        and prop_rec.get("step") == step
        and prop_rec.get("previous_candidate_form_id") == expected_prev_candidate
        and prop_rec.get("proposed_candidate_form_id") == expected_candidate
        and prop_rec.get("generator_id") == GENERATOR_ID
        and isinstance(prop_cand, dict)
        and prop_cand.get("candidate_form_id") == expected_candidate
        and canonical_json_equal(prop_cand, positive_later_form.get("candidate_form"))
        and _finite01(prop_rec.get("q_s"))
        and _finite01(prop_rec.get("q_prop"))
    )
    tr={
        "trace_record_id": f"trace_record::{trajectory_id}::s{step}",
        "context_id": TRACE_CONTEXT_ID,
        "trajectory_id": trajectory_id,
        "step": step,
        "root_capture_application_id": root["root_capture_application_id"],
        "root_positive_form_application_id": root["root_positive_form_application_id"],
        "previous_committed_positive_form_application_id": previous_positive_form_id,
        "proposal_record_id": prop_rec.get("proposal_record_id") if isinstance(prop_rec,dict) else None,
        "later_positive_form_application_id": positive_later_form.get("form_application_id"),
        "parent_chain_unbroken": bool(structural_ok),
        "provenance_mode": provenance_mode,
    }
    if provenance_mode == "mismatch":
        tr["root_capture_application_id"] = "mismatch::root_capture"
        return {"trace":0,"trace_record":tr,"positive_trace_application":None}
    if provenance_mode == "missing":
        return {"trace":None,"trace_record":None,"positive_trace_application":None}
    if provenance_mode != "standard":
        raise ValueError(provenance_mode)
    if not structural_ok:
        return {"trace":0,"trace_record":tr,"positive_trace_application":None}
    app={
        "trace_application_id": f"e_trace::{trajectory_id}::s{step}",
        "trace_record_id": tr["trace_record_id"],
        "proposal_record_id": prop_rec["proposal_record_id"],
        "root_capture_application_id": root["root_capture_application_id"],
        "previous_committed_positive_form_application_id": previous_positive_form_id,
        "later_positive_form_application_id": positive_later_form["form_application_id"],
        "trace_context_id": TRACE_CONTEXT_ID,
        "trajectory_id": trajectory_id,
        "step": step,
        "symtrace": 1,
    }
    return {"trace":1,"trace_record":tr,"positive_trace_application":app}

def reuse_status(root: Dict[str,Any], trajectory_id: str, step: int, trace: Dict[str,Any], proposal: Dict[str,Any],
                 U: Optional[float], ground: Dict[str,Any], *, context_present: bool=True,
                 provenance_mode: str="standard", reuse_gate: Optional[int]=1) -> Dict[str,Any]:
    t_app=trace.get("positive_trace_application")
    if t_app is None:
        return {"reuse":None,"reuse_record":None,"positive_reuse_application":None}
    if not context_present or reuse_gate is None:
        return {"reuse":None,"reuse_record":None,"positive_reuse_application":None}
    prop_rec=proposal.get("proposal_record") if isinstance(proposal,dict) else None
    ground_rec=ground.get("record") if isinstance(ground,dict) else None
    expected_prev_form = root["root_positive_form_application_id"] if step == 1 else f"e_symform_reuse::{trajectory_id}::s{step-1}"
    expected_prev_candidate = root["root_candidate_form"].get("candidate_form_id") if step == 1 else f"symcand_reuse::{trajectory_id}::s{step-1}"
    expected_later = f"e_symform_reuse::{trajectory_id}::s{step}"
    expected_candidate = f"symcand_reuse::{trajectory_id}::s{step}"
    expected_trace = f"e_trace::{trajectory_id}::s{step}"
    expected_proposal = f"proposal::{trajectory_id}::s{step}"
    expected_ground = f"ground::{trajectory_id}::s{step}"
    ground_ok = (
        ground.get("ground_status") in (0,1)
        and isinstance(ground_rec,dict)
        and ground_rec.get("ground_record_id") == expected_ground
        and ground_rec.get("context_id") == GROUND_CONTEXT_ID
        and ground_rec.get("trajectory_id") == trajectory_id
        and ground_rec.get("step") == step
        and ground_rec.get("root_capture_application_id") == root.get("root_capture_application_id")
        and ground_rec.get("manifestation_application_id") == root.get("manifestation_application_id")
        and ground_rec.get("source_descriptor_record_id") == root.get("source_descriptor_record_id")
        and ground_rec.get("status") == ground.get("ground_status")
    )
    if ground.get("ground_status") == 1:
        ground_ok = ground_ok and _finite01(ground.get("G")) and _finite01(ground.get("G_eff")) and abs(float(ground["G"])-float(ground["G_eff"])) < 1e-12
    else:
        ground_ok = ground_ok and ground.get("G") is None and float(ground.get("G_eff",math.nan)) == 0.0
    structural_ok = (
        t_app.get("symtrace") == 1
        and t_app.get("trace_context_id") == TRACE_CONTEXT_ID
        and t_app.get("trace_application_id") == expected_trace
        and t_app.get("proposal_record_id") == expected_proposal
        and t_app.get("root_capture_application_id") == root.get("root_capture_application_id")
        and t_app.get("trajectory_id") == trajectory_id
        and t_app.get("step") == step
        and t_app.get("previous_committed_positive_form_application_id") == expected_prev_form
        and t_app.get("later_positive_form_application_id") == expected_later
        and isinstance(prop_rec, dict)
        and prop_rec.get("proposal_record_id") == expected_proposal
        and prop_rec.get("trajectory_id") == trajectory_id
        and prop_rec.get("step") == step
        and prop_rec.get("previous_candidate_form_id") == expected_prev_candidate
        and prop_rec.get("proposed_candidate_form_id") == expected_candidate
        and prop_rec.get("generator_id") == GENERATOR_ID
        and proposal.get("candidate",{}).get("candidate_form_id") == expected_candidate
        and _finite01(prop_rec.get("q_s"))
        and _finite01(prop_rec.get("q_prop"))
        and _finite01(U)
        and ground_ok
    )
    rr={
        "reuse_record_id": f"reuse_record::{trajectory_id}::s{step}",
        "context_id": REUSE_CONTEXT_ID,
        "trajectory_id": trajectory_id,
        "step": step,
        "positive_trace_application_id": t_app.get("trace_application_id"),
        "proposal_record_id": prop_rec.get("proposal_record_id") if isinstance(prop_rec,dict) else None,
        "previous_committed_positive_form_application_id": t_app.get("previous_committed_positive_form_application_id"),
        "later_positive_form_application_id": t_app.get("later_positive_form_application_id"),
        "U": U,
        "ground_record_id": ground_rec.get("ground_record_id") if isinstance(ground_rec,dict) else None,
        "q_prop": prop_rec.get("q_prop") if isinstance(prop_rec,dict) else None,
        "reuse_gate": reuse_gate,
        "provenance_mode": provenance_mode,
    }
    if provenance_mode == "mismatch":
        rr["positive_trace_application_id"] = "mismatch::trace"
        return {"reuse":0,"reuse_record":rr,"positive_reuse_application":None}
    if provenance_mode == "missing":
        return {"reuse":None,"reuse_record":None,"positive_reuse_application":None}
    if provenance_mode != "standard": raise ValueError(provenance_mode)
    if not structural_ok:
        return {"reuse":0,"reuse_record":rr,"positive_reuse_application":None}
    if reuse_gate == 0:
        return {"reuse":0,"reuse_record":rr,"positive_reuse_application":None}
    if reuse_gate != 1:
        raise ValueError("reuse_gate must be None/0/1")
    app={
        "reuse_application_id": f"e_reuse::{trajectory_id}::s{step}",
        "positive_trace_application_id": t_app["trace_application_id"],
        "proposal_record_id": prop_rec["proposal_record_id"],
        "ground_record_id": ground_rec["ground_record_id"],
        "reuse_context_id": REUSE_CONTEXT_ID,
        "trajectory_id": trajectory_id,
        "step": step,
        "committed_positive_form_application_id": t_app["later_positive_form_application_id"],
        "symreuse": 1,
    }
    return {"reuse":1,"reuse_record":rr,"positive_reuse_application":app}

def reference_assessment(root: Dict[str,Any], positive_reuse_application: Optional[Dict[str,Any]],
                         positive_later_form: Optional[Dict[str,Any]]) -> Dict[str,Any]:
    """Assess only a reuse-qualified committed later form against the original source reference."""
    undef={"ref_application_id":None,"ref_policy_id":None,"ref_pres":None,"ref_red":None,"ref_dist":None,"D_ref":None,"source":None,"later":None}
    if root.get("InitElig") != 1 or not isinstance(positive_reuse_application,dict) or not isinstance(positive_later_form,dict):
        return undef
    form_id=positive_later_form.get("form_application_id")
    if (positive_reuse_application.get("symreuse") != 1
        or positive_reuse_application.get("reuse_context_id") != REUSE_CONTEXT_ID
        or positive_reuse_application.get("committed_positive_form_application_id") != form_id
        or positive_later_form.get("symform") != 1
        or positive_later_form.get("form_context_id") != symfid.FORM_CONTEXT_ID
        or not isinstance(positive_later_form.get("candidate_form"),dict)):
        return undef
    committed_candidate=positive_later_form["candidate_form"]
    if committed_candidate.get("candidate_form_id") != positive_later_form.get("candidate_form_id"):
        return undef
    a,b,c=root["source_descriptors"]
    ap,bp,cp=symfid.decode_candidate(committed_candidate)
    base={"ref_application_id":f"e_ref::{positive_reuse_application.get('trajectory_id')}::s{positive_reuse_application.get('step')}","ref_policy_id":REF_POLICY_ID,"source":[a,b,c],"later":[ap,bp,cp]}
    if not all(_finite01(x) for x in (a,b,ap,bp)):
        return {**base,"ref_pres":None,"ref_red":None,"ref_dist":None,"D_ref":None}
    ref_pres=int((bp > ap) and abs((bp-ap)-(b-a)) <= 0.20 + 1e-12)
    ref_red=int(cp is None)
    ref_dist=int(bp <= ap)
    D=.5*(abs(ap-a)+abs(bp-b))
    return {**base,"ref_pres":ref_pres,"ref_red":ref_red,"ref_dist":ref_dist,"D_ref":float(D)}


def run_trajectory(root: Dict[str,Any], trajectory_id: str, *, U: Any, G: Any,
                   kappa: float=0.25, delta: float=0.20, S: int=20, eta_q_form: float=1.0,
                   GroundRef: Optional[int]=1, candidate_mode: str="standard",
                   trace_context_present: bool=True, trace_provenance: str="standard",
                   reuse_context_present: bool=True, reuse_provenance: str="standard",
                   reuse_gate: Optional[int]=1) -> Dict[str,Any]:
    """Run one model trajectory. U/G may be scalars or sequences of length S."""
    if root.get("InitElig") != 1:
        return {
            "trajectory_id":trajectory_id,"InitElig":0,"initial_status":root.get("init_status"),
            "symbolic_input_perceptual_spec_json":json.dumps(root.get("symbolic_input_perceptual_spec"),sort_keys=True,separators=(",",":")) if root.get("symbolic_input_perceptual_spec") is not None else None,
            "symbolic_input_source_json":json.dumps(root.get("symbolic_input_source"),separators=(",",":")) if root.get("symbolic_input_source") is not None else None,
            "symbolic_input_overrides_json":json.dumps(root.get("symbolic_input_overrides",{}),sort_keys=True,separators=(",",":")),
            "complete":False,"completion_status":"initial_route_not_available",
            "q0":None,"final_q":None,"final_D_ref":None,"final_ref_pres":None,"final_ref_red":None,"final_ref_dist":None,
            "committed_steps":0,"steps":[],"claim_ceiling":CLAIM_CEILING,
        }
    if not (isinstance(S,int) and S>=1): raise ValueError("S must be positive integer")
    if not (math.isfinite(float(eta_q_form)) and float(eta_q_form)>=0): raise ValueError("eta must be nonnegative")
    U_seq=[U]*S if not isinstance(U,(list,tuple)) else list(U)
    G_seq=[G]*S if not isinstance(G,(list,tuple)) else list(G)
    if len(U_seq)!=S or len(G_seq)!=S: raise ValueError("U/G sequence length")

    q=float(root["initial_D_sym_toy_p"])
    current_candidate=dict(root["root_candidate_form"])
    current_positive_form_id=root["root_positive_form_application_id"]
    q0=q
    step_rows=[]
    complete=True
    status="complete"

    for s in range(1,S+1):
        Us=U_seq[s-1]; Gs=G_seq[s-1]
        gr=ground_reference(root,trajectory_id,s,GroundRef,Gs)
        qp=q_proposal(q,Us,gr,kappa=kappa,delta=delta)
        prop=propose_later_candidate(root["symbolic_case_id"],trajectory_id,s,current_candidate,q,qp,eta_q_form=eta_q_form,candidate_mode=candidate_mode)
        cand=prop.get("candidate")
        sf=symfid.symform_status(cand, form_context_present=True) if cand is not None else None
        pos_form=_positive_form_from_symbolic_model(cand,sf,trajectory_id,s) if cand is not None else None
        tr=trace_status(root,trajectory_id,s,current_positive_form_id,pos_form,prop,context_present=trace_context_present,provenance_mode=trace_provenance)
        ru=reuse_status(root,trajectory_id,s,tr,prop,Us,gr,context_present=reuse_context_present,provenance_mode=reuse_provenance,reuse_gate=reuse_gate)
        committed = ru.get("reuse") == 1
        if committed:
            q=float(qp)
            current_candidate=cand
            current_positive_form_id=pos_form["form_application_id"]
            ref=reference_assessment(root,ru.get("positive_reuse_application"),pos_form)
        else:
            ref={"ref_application_id":None,"ref_policy_id":None,"ref_pres":None,"ref_red":None,"ref_dist":None,"D_ref":None,"source":None,"later":None}
        row={
            "trajectory_id":trajectory_id,"step":s,
            "root_capture_application_id":root["root_capture_application_id"],
            "previous_committed_positive_form_application_id": tr.get("trace_record",{}).get("previous_committed_positive_form_application_id") if tr.get("trace_record") else current_positive_form_id if not committed else None,
            "ground_record_id":gr.get("record",{}).get("ground_record_id") if gr.get("record") else None,
            "ground_context_id":gr.get("record",{}).get("context_id") if gr.get("record") else None,
            "ground_status":gr.get("ground_status"),"G":gr.get("G"),"G_eff":gr.get("G_eff"),
            "U":Us,"q_s":prop.get("proposal_record",{}).get("q_s") if prop.get("proposal_record") else q if qp is None else None,
            "q_prop":qp,"delta_q":prop.get("delta_q"),
            "proposal_record_id":prop.get("proposal_record",{}).get("proposal_record_id") if prop.get("proposal_record") else None,
            "proposal_previous_candidate_form_id":prop.get("proposal_record",{}).get("previous_candidate_form_id") if prop.get("proposal_record") else None,
            "proposal_generator_id":prop.get("proposal_record",{}).get("generator_id") if prop.get("proposal_record") else None,
            "candidate_form_id":cand.get("candidate_form_id") if cand else None,
            "candidate_payload":json.dumps(cand.get("payload"),ensure_ascii=False,separators=(",",":")) if cand else None,
            "later_symform":sf,
            "later_positive_form_application_id":pos_form.get("form_application_id") if pos_form else None,
            "trace_context_id":tr.get("trace_record",{}).get("context_id") if tr.get("trace_record") else None,
            "symtrace":tr.get("trace"),
            "trace_application_id":tr.get("positive_trace_application",{}).get("trace_application_id") if tr.get("positive_trace_application") else None,
            "reuse_context_id":ru.get("reuse_record",{}).get("context_id") if ru.get("reuse_record") else None,
            "symreuse":ru.get("reuse"),
            "reuse_application_id":ru.get("positive_reuse_application",{}).get("reuse_application_id") if ru.get("positive_reuse_application") else None,
            "commit":int(committed),
            "committed_positive_form_application_id":current_positive_form_id if committed else None,
            "committed_q":q if committed else None,
            "ref_application_id":ref.get("ref_application_id"),"ref_policy_id":ref["ref_policy_id"],"ref_pres":ref["ref_pres"],"ref_red":ref["ref_red"],"ref_dist":ref["ref_dist"],"D_ref":ref["D_ref"],
            "later_a":ref["later"][0] if ref.get("later") else None,"later_b":ref["later"][1] if ref.get("later") else None,"later_c":ref["later"][2] if ref.get("later") else None,
            "fresh_later_symcap":None,
        }
        step_rows.append(row)
        if not committed:
            complete=False
            if gr.get("ground_status") is None: status="grounding_unresolved"
            elif sf is None: status="later_form_unresolved"
            elif sf == 0: status="later_form_negative"
            elif tr.get("trace") is None: status="trace_unresolved"
            elif tr.get("trace") == 0: status="trace_negative"
            elif ru.get("reuse") is None: status="reuse_unresolved"
            elif ru.get("reuse") == 0: status="reuse_negative"
            else: status="not_committed"
            break

    final_ref = ({"ref_pres":step_rows[-1].get("ref_pres"),"ref_red":step_rows[-1].get("ref_red"),"ref_dist":step_rows[-1].get("ref_dist"),"D_ref":step_rows[-1].get("D_ref")} if complete and step_rows and step_rows[-1].get("commit")==1 else {"ref_pres":None,"ref_red":None,"ref_dist":None,"D_ref":None})
    return {
        "trajectory_id":trajectory_id,"InitElig":1,"initial_status":"eligible",
        "symbolic_input_perceptual_spec_json":json.dumps(root["symbolic_input_perceptual_spec"],sort_keys=True,separators=(",",":")),
        "symbolic_input_source_json":json.dumps(root["symbolic_input_source"],separators=(",",":")),
        "symbolic_input_overrides_json":json.dumps(root["symbolic_input_overrides"],sort_keys=True,separators=(",",":")),
        "manifestation_application_id":root["manifestation_application_id"],
        "root_capture_application_id":root["root_capture_application_id"],
        "root_positive_form_application_id":root["root_positive_form_application_id"],
        "root_candidate_form_id":root["root_candidate_form"].get("candidate_form_id"),
        "root_fidelity_application_id":root["root_fidelity_application_id"],
        "source_descriptor_record_id":root["source_descriptor_record_id"],
        "source_a":root["source_descriptors"][0],"source_b":root["source_descriptors"][1],"source_c":root["source_descriptors"][2],
        "initial_sym_pres":root["initial_sym_pres"],"initial_sym_red":root["initial_sym_red"],"initial_sym_dist":root["initial_sym_dist"],
        "q0":q0,"initial_D_sym_toy_p":root["initial_D_sym_toy_p"],
        "complete":complete,"completion_status":status,"committed_steps":sum(r["commit"] for r in step_rows),
        "final_q":q if complete else None,
        "final_D_ref":final_ref.get("D_ref") if complete else None,
        "final_ref_pres":final_ref.get("ref_pres") if complete else None,
        "final_ref_red":final_ref.get("ref_red") if complete else None,
        "final_ref_dist":final_ref.get("ref_dist") if complete else None,
        "final_candidate_form_id":current_candidate.get("candidate_form_id") if complete else None,
        "kappa":float(kappa),"delta":float(delta),"S":S,"eta_q_form":float(eta_q_form),
        "steps":step_rows,"claim_ceiling":CLAIM_CEILING,
    }
