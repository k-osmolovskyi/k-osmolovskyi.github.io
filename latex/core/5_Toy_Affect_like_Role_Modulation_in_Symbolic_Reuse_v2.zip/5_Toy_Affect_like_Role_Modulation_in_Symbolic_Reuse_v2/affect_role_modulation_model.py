"""Toy model of affect-like role modulation in symbolic reuse.

The module constructs role-qualified burden-like, threat-like, and relief-like
applications and converts their local contributions into two numeric modulation
requests supplied to the companion symbolic-reuse model. The role layer does not
define trace, reuse, commit, grounding, or later source-relative fidelity.
"""
from __future__ import annotations
from typing import Any, Dict, Optional, Sequence, List
import math
import symbolic_reuse_model as reuse

MODEL_VERSION="2.0"

COHERENCE_REPRESENTATION_CONTEXT_ID="COHERENCE-REPRESENTATION-APP-v1"
EV_ALIGN_CONTEXT={"bur":"EVIDENCE-ALIGN-BURDEN-v1","thr":"EVIDENCE-ALIGN-THREAT-v1","rel":"EVIDENCE-ALIGN-RELIEF-v1"}
ROLE_CONTEXT={"bur":"AFFECT-ROLE-BURDEN-v1","thr":"AFFECT-ROLE-THREAT-v1","rel":"AFFECT-ROLE-RELIEF-v1"}
WEIGHT_CONTEXT={"bur":"ROLE-WEIGHT-BURDEN-v1","thr":"ROLE-WEIGHT-THREAT-v1","rel":"ROLE-WEIGHT-RELIEF-v1"}
ROLE_STEP_ALIGN_CONTEXT="ROLE-REUSE-STEP-ALIGN-v1"
ROLE_THRESHOLD=.50
COEFF_U={"bur":.25,"thr":.30,"rel":-.20}
COEFF_G={"bur":-.20,"thr":-.25,"rel":.30}
CLAIM_LIMITS=["toy_realization_only","not_empirical_validation","not_emotion_measurement","role_positive_not_reuse_authorization","role_weight_not_grounding","not_truth_or_correction","not_prevalence"]


def clip01(x:float)->float: return float(min(1.,max(0.,float(x))))
def finite01(x:Any)->bool:
    try:y=float(x)
    except Exception:return False
    return math.isfinite(y) and 0<=y<=1

def _id(prefix:str, case_id:str, trajectory_id:str, step:int, role:Optional[str]=None)->str:
    return f"{prefix}::{case_id}::{trajectory_id}::s{step}" + (f"::{role}" if role else "")

def make_step_frame(root:Dict[str,Any], case_id:str, trajectory_id:str, step:int, U_base:Any,G_base:Any,GroundRef:Optional[int])->Optional[Dict[str,Any]]:
    if root.get('InitElig')!=1: return None
    if not finite01(U_base) or (G_base is not None and not finite01(G_base)): return None
    return {"joint_case_id":case_id,"trajectory_id":trajectory_id,"step":int(step),
            "root_capture_application_id":root.get("root_capture_application_id"),
            "source_descriptor_record_id":root.get("source_descriptor_record_id"),
            "U_base":float(U_base),"G_base":None if G_base is None else float(G_base),"GroundRef":GroundRef,
            "frame_id":_id('frame',case_id,trajectory_id,step)}

def make_ecr_application(frame:Optional[Dict[str,Any]], *, present:bool=True)->Optional[Dict[str,Any]]:
    if not present or not isinstance(frame,dict): return None
    return {"ecr_application_id":_id('ecr',frame['joint_case_id'],frame['trajectory_id'],frame['step']),
            "joint_case_id":frame['joint_case_id'],"trajectory_id":frame['trajectory_id'],"step":frame['step'],
            "context_id":COHERENCE_REPRESENTATION_CONTEXT_ID,"construction_target":"synthetic_regulatory_representation",
            "admitted_discrepancy_token":_id('disc',frame['joint_case_id'],frame['trajectory_id'],frame['step']),
            "representation_output":_id('ecrout',frame['joint_case_id'],frame['trajectory_id'],frame['step'])}

def make_evidence(frame:Dict[str,Any], role:str, *, gate:Optional[int]=1, DirClass:Optional[int]=-1, mismatch:bool=False)->Optional[Dict[str,Any]]:
    if role not in ('bur','thr','rel'): raise ValueError(role)
    cid=frame['joint_case_id'] if not mismatch else frame['joint_case_id']+'__MISMATCH'
    rec={"evidence_id":_id('ev',cid,frame['trajectory_id'],frame['step'],role),"role":role,"joint_case_id":cid,
         "trajectory_id":frame['trajectory_id'],"step":frame['step'],"declared_ecr_application_id":_id('ecr',cid,frame['trajectory_id'],frame['step'])}
    if role=='bur': rec['BurdenEv']=gate
    elif role=='rel': rec['Ease']=gate
    else: rec['DirClass']=DirClass
    return rec

def ev_align(frame:Dict[str,Any], ecr:Optional[Dict[str,Any]], evidence:Optional[Dict[str,Any]], role:str, *, context_present:bool=True)->Dict[str,Any]:
    if not context_present or ecr is None or evidence is None:
        return {"status":None,"record":None}
    same=(ecr.get('joint_case_id')==frame['joint_case_id']==evidence.get('joint_case_id') and ecr.get('trajectory_id')==frame['trajectory_id']==evidence.get('trajectory_id') and ecr.get('step')==frame['step']==evidence.get('step') and evidence.get('role')==role and evidence.get('declared_ecr_application_id')==ecr.get('ecr_application_id'))
    rec={"alignment_id":_id('evalign',frame['joint_case_id'],frame['trajectory_id'],frame['step'],role),"context_id":EV_ALIGN_CONTEXT[role],"ecr_application_id":ecr['ecr_application_id'],"evidence_id":evidence['evidence_id'],"status":int(same)}
    return {"status":int(same),"record":rec}

def role_ev_ok(evidence:Optional[Dict[str,Any]], role:str)->Optional[int]:
    if evidence is None:return None
    if role=='bur': return evidence.get('BurdenEv') if evidence.get('BurdenEv') in (0,1) else None
    if role=='rel': return evidence.get('Ease') if evidence.get('Ease') in (0,1) else None
    dc=evidence.get('DirClass'); return None if dc is None else int(dc==-1)

def eval_role(frame:Dict[str,Any], ecr:Optional[Dict[str,Any]], evidence:Optional[Dict[str,Any]], role:str, rho:Any, *, ev_align_context_present:bool=True, role_context_present:bool=True)->Dict[str,Any]:
    al=ev_align(frame,ecr,evidence,role,context_present=ev_align_context_present); gate=role_ev_ok(evidence,role)
    status=None
    if al['status']==1 and gate==1 and role_context_present and finite01(rho): status=int(float(rho)>=ROLE_THRESHOLD)
    rec={"role_eval_id":_id('roleeval',frame['joint_case_id'],frame['trajectory_id'],frame['step'],role),"role":role,"context_id":ROLE_CONTEXT[role],"joint_case_id":frame['joint_case_id'],"trajectory_id":frame['trajectory_id'],"step":frame['step'],"root_capture_application_id":frame['root_capture_application_id'],"EvAlign":al['status'],"RoleEvOK":gate,"rho":float(rho) if finite01(rho) else None,"AffRole":status,"alignment_id":al['record']['alignment_id'] if al['record'] else None}
    pos=None
    if status==1:
        pos={"role_application_id":_id('roleapp',frame['joint_case_id'],frame['trajectory_id'],frame['step'],role),"role":role,"AffRole":1,"ecr_application_id":ecr['ecr_application_id'],"evidence_id":evidence['evidence_id'],"alignment_id":al['record']['alignment_id'],"role_eval_id":rec['role_eval_id'],"context_id":ROLE_CONTEXT[role]}
    return {"EvAlign":al['status'],"RoleEvOK":gate,"AffRole":status,"role_eval_record":rec,"positive_role_application":pos}

def positive_role_lineage_ok(role_eval:Dict[str,Any], role:str)->bool:
    """Verify that a positive role application is attached to its exact role-evaluation record."""
    if role_eval.get("AffRole") != 1:
        return False
    rer=role_eval.get("role_eval_record") or {}
    app=role_eval.get("positive_role_application") or {}
    return bool(
        rer.get("role") == role
        and rer.get("context_id") == ROLE_CONTEXT.get(role)
        and app.get("role") == role
        and app.get("AffRole") == 1
        and app.get("role_eval_id") == rer.get("role_eval_id")
        and app.get("context_id") == ROLE_CONTEXT.get(role)
        and app.get("alignment_id") == rer.get("alignment_id")
    )

def role_weight_lineage_ok(role_eval:Dict[str,Any], weight_result:Dict[str,Any], role:str)->bool:
    """Verify role-local weight provenance against the exact positive role application."""
    if not positive_role_lineage_ok(role_eval,role):
        return False
    app=(weight_result or {}).get("application") or {}
    pos=role_eval.get("positive_role_application") or {}
    return bool(
        app.get("role") == role
        and app.get("role_application_id") == pos.get("role_application_id")
        and app.get("context_id") == WEIGHT_CONTEXT.get(role)
        and app.get("weight") == (weight_result or {}).get("weight")
    )

def role_weight(frame:Dict[str,Any], role_eval:Dict[str,Any], role:str, candidate:Any, *, weight_context_present:bool=True)->Dict[str,Any]:
    st=role_eval.get('AffRole')
    if st!=1: return {"weight":None,"application":None}
    if not positive_role_lineage_ok(role_eval,role): return {"weight":None,"application":None}
    if not weight_context_present or not finite01(candidate): return {"weight":None,"application":None}
    w=float(candidate)
    app={"weight_application_id":_id('weight',frame['joint_case_id'],frame['trajectory_id'],frame['step'],role),"role":role,"role_application_id":role_eval['positive_role_application']['role_application_id'],"context_id":WEIGHT_CONTEXT[role],"weight":w}
    return {"weight":w,"application":app}

def role_step_align(frame:Dict[str,Any], role_eval:Dict[str,Any], role:str, *, mode:str='standard')->Dict[str,Any]:
    if role_eval.get('AffRole') is None: return {"status":None,"record":None}
    rid=role_eval['role_eval_record']['role_eval_id']
    rer=role_eval.get('role_eval_record') or {}; ok=(mode=='standard' and rer.get('role')==role and rer.get('context_id')==ROLE_CONTEXT.get(role) and rer.get('joint_case_id')==frame.get('joint_case_id') and rer.get('trajectory_id')==frame.get('trajectory_id') and rer.get('step')==frame.get('step') and rer.get('root_capture_application_id')==frame.get('root_capture_application_id'))
    if ok and role_eval.get('AffRole')==1:
        ok=positive_role_lineage_ok(role_eval,role)
    rec={"role_step_alignment_id":_id('rolestep',frame['joint_case_id'],frame['trajectory_id'],frame['step'],role),"context_id":ROLE_STEP_ALIGN_CONTEXT,"role_eval_id":rid,"frame_id":frame['frame_id'],"root_capture_application_id":frame['root_capture_application_id'],"status":int(ok)}
    return {"status":int(ok),"record":rec}

def role_slot(frame:Dict[str,Any], ecr:Optional[Dict[str,Any]], role:str, rho:Any, weight_candidate:Any, *, evidence_gate:Optional[int]=1,DirClass:Optional[int]=-1,evidence_mismatch:bool=False,ev_align_context_present:bool=True,role_context_present:bool=True,weight_context_present:bool=True,role_step_align_mode:str='standard')->Dict[str,Any]:
    ev=make_evidence(frame,role,gate=evidence_gate,DirClass=DirClass,mismatch=evidence_mismatch)
    rr=eval_role(frame,ecr,ev,role,rho,ev_align_context_present=ev_align_context_present,role_context_present=role_context_present)
    wt=role_weight(frame,rr,role,weight_candidate,weight_context_present=weight_context_present)
    rsa=role_step_align(frame,rr,role,mode=role_step_align_mode)
    contrib=None
    if rr['AffRole']==0 and rsa['status']==1: contrib=0.0
    elif rr['AffRole']==1 and rsa['status']==1 and wt['weight'] is not None and role_weight_lineage_ok(rr,wt,role): contrib=float(wt['weight'])
    return {"role":role,"evidence":ev,"EvAlign":rr['EvAlign'],"RoleEvOK":rr['RoleEvOK'],"AffRole":rr['AffRole'],"role_eval_record":rr['role_eval_record'],"positive_role_application":rr['positive_role_application'],"weight":wt['weight'],"weight_application":wt['application'],"RoleStepAlign":rsa['status'],"role_step_alignment_record":rsa['record'],"contribution":contrib}

def build_modulation_step(root:Dict[str,Any], case_id:str, trajectory_id:str, step:int, *, U_base:Any,G_base:Any,GroundRef:Optional[int]=1,
                          rho_bur:Any=.2,rho_thr:Any=.2,rho_rel:Any=.2,w_bur:Any=0.,w_thr:Any=0.,w_rel:Any=0.,
                          ecr_present:bool=True,BurdenEv:Optional[int]=1,Ease:Optional[int]=1,DirClass:Optional[int]=-1,
                          evidence_mismatch_role:Optional[str]=None,ev_align_context_present:bool=True,role_context_present:bool=True,
                          missing_weight_role:Optional[str]=None,role_step_mismatch_role:Optional[str]=None)->Dict[str,Any]:
    frame=make_step_frame(root,case_id,trajectory_id,step,U_base,G_base,GroundRef)
    if frame is None:return {"frame":None,"modulation_defined":False,"U_mod":None,"G_mod_requested":None,"roles":{}}
    ecr=make_ecr_application(frame,present=ecr_present)
    roles={}
    for role,rho,w in [('bur',rho_bur,w_bur),('thr',rho_thr,w_thr),('rel',rho_rel,w_rel)]:
        gate=BurdenEv if role=='bur' else Ease if role=='rel' else 1
        roles[role]=role_slot(frame,ecr,role,rho,w,evidence_gate=gate,DirClass=DirClass,
            evidence_mismatch=(evidence_mismatch_role==role),ev_align_context_present=ev_align_context_present,
            role_context_present=role_context_present,weight_context_present=(missing_weight_role!=role),
            role_step_align_mode='mismatch' if role_step_mismatch_role==role else 'standard')
    cs={r:roles[r]['contribution'] for r in roles}
    defined=all(cs[r] is not None for r in ('bur','thr','rel'))
    Umod=Gmod=None
    if defined:
        Umod=clip01(float(U_base)+sum(COEFF_U[r]*cs[r] for r in cs))
        Gmod=clip01(float(G_base)+sum(COEFF_G[r]*cs[r] for r in cs))
    return {"frame":frame,"ecr_application":ecr,"roles":roles,"modulation_defined":defined,"U_mod":Umod,"G_mod_requested":Gmod,
            "bridge_terms_U":{r:(None if cs[r] is None else COEFF_U[r]*cs[r]) for r in cs},"bridge_terms_G":{r:(None if cs[r] is None else COEFF_G[r]*cs[r]) for r in cs}}

def _seq(v:Any,S:int)->List[Any]:
    if isinstance(v,(list,tuple)): 
        if len(v)!=S: raise ValueError('sequence length')
        return list(v)
    return [v]*S

def run_role_modulated_trajectory(root:Dict[str,Any], case_id:str, trajectory_id:str, *, U_base:Any,G_base:Any,S:int=20,
                                  rho_bur:Any=.2,rho_thr:Any=.2,rho_rel:Any=.2,w_bur:Any=0.,w_thr:Any=0.,w_rel:Any=0.,
                                  GroundRef:Optional[int]=1,reuse_gate:Optional[int]=1,kappa:float=.25,delta:float=.20,eta_q_form:float=1.0,
                                  **role_controls)->Dict[str,Any]:
    if root.get('InitElig')!=1:
        return {"trajectory_id":trajectory_id,"joint_case_id":case_id,"InitElig":0,"joint_frame":False,"modulation_defined":False,"symbolic_reuse_run":False,"complete":False,"completion_status":"initial_route_not_available","role_steps":[],"symbolic_reuse":None,"claim_ceiling":CLAIM_LIMITS}
    seqs={k:_seq(v,S) for k,v in {'U_base':U_base,'G_base':G_base,'rho_bur':rho_bur,'rho_thr':rho_thr,'rho_rel':rho_rel,'w_bur':w_bur,'w_thr':w_thr,'w_rel':w_rel}.items()}
    mods=[]
    for i in range(S):
        m=build_modulation_step(root,case_id,trajectory_id,i+1,U_base=seqs['U_base'][i],G_base=seqs['G_base'][i],GroundRef=GroundRef,
            rho_bur=seqs['rho_bur'][i],rho_thr=seqs['rho_thr'][i],rho_rel=seqs['rho_rel'][i],w_bur=seqs['w_bur'][i],w_thr=seqs['w_thr'][i],w_rel=seqs['w_rel'][i],**role_controls)
        mods.append(m)
        if not m['modulation_defined']:
            return {"trajectory_id":trajectory_id,"joint_case_id":case_id,"InitElig":1,"joint_frame":True,"modulation_defined":False,"symbolic_reuse_run":False,"complete":False,"completion_status":"modulation_unresolved","role_steps":mods,"symbolic_reuse":None,"claim_ceiling":CLAIM_LIMITS}
    Umods=[m['U_mod'] for m in mods]; Gmods=[m['G_mod_requested'] for m in mods]
    tr=reuse.run_trajectory(root,trajectory_id,U=Umods,G=Gmods,kappa=kappa,delta=delta,S=S,eta_q_form=eta_q_form,GroundRef=GroundRef,reuse_gate=reuse_gate)
    # Associate step-level readouts without altering the symbolic-reuse values.
    for m,ps in zip(mods,tr.get('steps',[])):
        m['symbolic_reuse_step']={k:ps.get(k) for k in ('step','ground_status','G_eff','U','q_s','q_prop','later_symform','symtrace','symreuse','commit','committed_q','ref_pres','ref_red','ref_dist','D_ref','fresh_later_symcap')}
    return {"trajectory_id":trajectory_id,"joint_case_id":case_id,"InitElig":1,"joint_frame":True,"modulation_defined":True,"symbolic_reuse_run":True,"complete":tr.get('complete'),"completion_status":tr.get('completion_status'),"role_steps":mods,"symbolic_reuse":tr,"claim_ceiling":CLAIM_LIMITS}
