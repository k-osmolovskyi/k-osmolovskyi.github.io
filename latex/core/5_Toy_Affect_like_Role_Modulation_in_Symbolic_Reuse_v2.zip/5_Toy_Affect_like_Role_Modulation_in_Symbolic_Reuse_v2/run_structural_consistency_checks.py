"""Run structural consistency checks for the affect-like role modulation toy model."""
from pathlib import Path
import json
import pandas as pd
import perceptual_stabilization_model as perceptual
import symbolic_reuse_model as reuse
import affect_role_modulation_model as affect

ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'; RESULTS.mkdir(exist_ok=True)

def fixture_root(name='reuse_growth',case='ROOT',source=(.2,.8,.5)):
    mp={'reuse_growth':'B_ambiguous_signal','initial_route_absent':'D_novel_signal'}
    return reuse.initial_export(case,dict(perceptual.SCENARIOS[mp[name]]),source=source)

def first_step(r):
    sr=r.get('symbolic_reuse') or {}
    return sr.get('steps',[{}])[0] if sr.get('steps') else {}

def run_structural_consistency_tests():
    out=[]
    def add(i,p,n=''): out.append({'test':i,'pass':bool(p),'note':n})
    B=fixture_root(); E=fixture_root('initial_route_absent','ROOT_E')
    x=affect.run_role_modulated_trajectory(E,'T1','T1',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.8,rho_rel=.8,w_bur=.8,w_thr=.6,w_rel=.4)
    add('T-1',x['InitElig']==0 and not x['symbolic_reuse_run'],'ineligible initial route is not rescued by role modulation')
    x=affect.run_role_modulated_trajectory(B,'T2','T2',U_base=.5,G_base=.3,S=1,ecr_present=False)
    add('T-2',not x['modulation_defined'] and not x['symbolic_reuse_run'] and x['role_steps'][0]['roles']['bur']['AffRole'] is None,'missing ECR application leaves roles undefined')
    x=affect.run_role_modulated_trajectory(B,'T3','T3',U_base=.5,G_base=.3,S=1,evidence_mismatch_role='bur'); rb=x['role_steps'][0]['roles']['bur']
    add('T-3',rb['EvAlign']==0 and rb['AffRole'] is None and not x['modulation_defined'],'evidence mismatch blocks role application')
    x=affect.run_role_modulated_trajectory(B,'T4','T4',U_base=.5,G_base=.3,S=1,BurdenEv=0); rb=x['role_steps'][0]['roles']['bur']
    add('T-4',rb['RoleEvOK']==0 and rb['AffRole'] is None and not x['modulation_defined'],'failed evidence gate is not a negative role')
    x=affect.run_role_modulated_trajectory(B,'T5','T5',U_base=.5,G_base=.3,S=1,rho_bur=.2,rho_thr=.2,rho_rel=.2); m=x['role_steps'][0]
    add('T-5',m['roles']['bur']['AffRole']==0 and m['roles']['bur']['weight'] is None and m['roles']['bur']['contribution']==0 and x['modulation_defined'],'defined-negative role contributes zero')
    x=affect.run_role_modulated_trajectory(B,'T6','T6',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.2,rho_rel=.2,w_bur=.7,missing_weight_role='bur'); rb=x['role_steps'][0]['roles']['bur']
    add('T-6',rb['AffRole']==1 and rb['weight'] is None and not x['modulation_defined'],'positive role with missing weight remains unresolved')
    x=affect.run_role_modulated_trajectory(B,'T7','T7',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.2,rho_rel=.2,w_bur=0); m=x['role_steps'][0]
    add('T-7',m['roles']['bur']['AffRole']==1 and m['roles']['bur']['weight']==0 and abs(m['U_mod']-.5)<1e-12 and abs(m['G_mod_requested']-.3)<1e-12,'positive zero-weight role is distinct but numerically neutral')
    x=affect.run_role_modulated_trajectory(B,'T8','T8',U_base=.5,G_base=.3,S=1,DirClass=0); rt=x['role_steps'][0]['roles']['thr']
    add('T-8',rt['RoleEvOK']==0 and rt['AffRole'] is None and not x['modulation_defined'],'directional evidence gate preserves undefinedness')
    x=affect.run_role_modulated_trajectory(B,'T9','T9',U_base=.5,G_base=.3,S=1,DirClass=-1,rho_thr=.2,rho_bur=.2,rho_rel=.2); rt=x['role_steps'][0]['roles']['thr']
    add('T-9',rt['RoleEvOK']==1 and rt['AffRole']==0 and rt['contribution']==0,'qualified threat evidence can yield a defined-negative role')
    x10=affect.run_role_modulated_trajectory(B,'T10','T10',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.8,rho_rel=.8,w_bur=.8,w_thr=.6,w_rel=.4); m=x10['role_steps'][0]; s=first_step(x10); sr=x10['symbolic_reuse']
    add('T-10',all(m['roles'][r]['AffRole']==1 for r in ('bur','thr','rel')) and abs(m['U_mod']-.8)<1e-12 and abs(m['G_mod_requested']-.11)<1e-12 and abs(sr['final_q']-.158)<1e-12 and abs(sr['final_D_ref']-.15)<1e-12 and s['symtrace']==1 and s['symreuse']==1,'simultaneous positive roles preserve downstream typing')
    x=affect.run_role_modulated_trajectory(B,'T11','T11',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.2,rho_rel=.2,w_bur=.5,role_step_mismatch_role='bur'); rb=x['role_steps'][0]['roles']['bur']
    add('T-11',rb['RoleStepAlign']==0 and not x['modulation_defined'],'role-step mismatch blocks modulation')
    x=affect.run_role_modulated_trajectory(B,'T12','T12',U_base=.5,G_base=.3,S=1,rho_bur=.2,rho_thr=.2,rho_rel=.8,w_rel=1,GroundRef=0); m=x['role_steps'][0]; s=first_step(x)
    add('T-12',abs(m['G_mod_requested']-.6)<1e-12 and s['ground_status']==0 and abs(s['G_eff'])<1e-12,'role modulation cannot create a grounding basis')
    x=affect.run_role_modulated_trajectory(B,'T13','T13',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.8,rho_rel=.8,w_bur=.8,w_thr=.6,w_rel=.4,GroundRef=None); s=first_step(x)
    add('T-13',s.get('q_prop') is None and s.get('commit')==0,'undefined grounding is not resolved by modulation')
    x=affect.run_role_modulated_trajectory(B,'T14','T14',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.8,rho_rel=.8,w_bur=.8,w_thr=.6,w_rel=.4,reuse_gate=0); s=first_step(x)
    add('T-14',s['symtrace']==1 and s['symreuse']==0 and s['commit']==0,'role positivity cannot authorize reuse')
    s=first_step(x10); add('T-15',s['fresh_later_symcap'] is None and x10['symbolic_reuse']['final_ref_dist'] in (0,1),'modulation does not create fresh symbolic capture')
    xb=affect.run_role_modulated_trajectory(B,'T16','T16',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.2,rho_rel=.2,w_bur=1); mb=xb['role_steps'][0]
    add('T-16',abs(mb['U_mod']-.75)<1e-12 and abs(mb['G_mod_requested']-.1)<1e-12,'burden-only bridge coefficients')
    xt=affect.run_role_modulated_trajectory(B,'T17','T17',U_base=.5,G_base=.3,S=1,rho_bur=.2,rho_thr=.8,rho_rel=.2,w_thr=1); mt=xt['role_steps'][0]
    add('T-17',abs(mt['U_mod']-.8)<1e-12 and abs(mt['G_mod_requested']-.05)<1e-12,'threat-only bridge coefficients')
    xr=affect.run_role_modulated_trajectory(B,'T18','T18',U_base=.5,G_base=.3,S=1,rho_bur=.2,rho_thr=.2,rho_rel=.8,w_rel=1); mr=xr['role_steps'][0]
    add('T-18',abs(mr['U_mod']-.3)<1e-12 and abs(mr['G_mod_requested']-.6)<1e-12,'relief-only bridge coefficients')
    add('T-19',abs(x10['symbolic_reuse']['final_q']-.158)<1e-12 and abs(x10['symbolic_reuse']['final_D_ref']-.15)<1e-12 and abs(x10['symbolic_reuse']['final_q']-x10['symbolic_reuse']['final_D_ref'])>1e-12,'final load and reference distance remain non-identical')
    xbt=affect.run_role_modulated_trajectory(B,'T20B','T20B',U_base=.5,G_base=.3,S=1,rho_bur=.8,rho_thr=.2,rho_rel=.2,w_bur=.5); xth=affect.run_role_modulated_trajectory(B,'T20T','T20T',U_base=.5,G_base=.3,S=1,rho_bur=.2,rho_thr=.8,rho_rel=.2,w_thr=.5); mb=xbt['role_steps'][0]; mt=xth['role_steps'][0]
    add('T-20',abs(mb['U_mod']-.625)<1e-12 and abs(mb['G_mod_requested']-.2)<1e-12 and abs(mt['U_mod']-.65)<1e-12 and abs(mt['G_mod_requested']-.175)<1e-12,'equal numeric role weights need not have equal bridge effects')
    xn=affect.run_role_modulated_trajectory(B,'T21','T21',U_base=.5,G_base=.3,S=1,rho_bur=.2,rho_thr=.2,rho_rel=.2); direct=reuse.run_trajectory(B,'T21',U=.5,G=.3,S=1); pn=xn['symbolic_reuse']; keys=['complete','completion_status','final_q','final_D_ref','final_ref_pres','final_ref_red','final_ref_dist']; eq=all(pn.get(k)==direct.get(k) for k in keys); sk=['ground_status','G_eff','U','q_s','q_prop','later_symform','symtrace','symreuse','commit','committed_q','ref_pres','ref_red','ref_dist','D_ref']; eq=eq and all(pn['steps'][0].get(k)==direct['steps'][0].get(k) for k in sk)
    add('T-21',eq and all(xn['role_steps'][0]['roles'][r]['AffRole']==0 for r in ('bur','thr','rel')),'defined-negative bundle is numerically equivalent to direct base controls')
    df=pd.DataFrame(out); df.to_csv(RESULTS/'structural_consistency_tests.csv',index=False)
    (RESULTS/'structural_consistency_tests.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    return df

if __name__=='__main__':
    df=run_structural_consistency_tests()
    print(df[['test','pass']].to_string(index=False))
    if not (len(df)==21 and bool(df['pass'].all())): raise SystemExit(1)
