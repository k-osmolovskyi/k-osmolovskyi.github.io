"""Run the symbolic-reuse toy model, structural consistency tests, and optional full analyses.

The default action runs the 18 structural consistency tests. Use --full to re-evaluate
all four 201 x 201 deterministic surfaces and the three 20,000-episode Monte Carlo strata.
The full run is computationally heavier and writes trajectory-level summaries.
"""
from __future__ import annotations

from pathlib import Path
import argparse
import json
import math
from typing import Any, Dict, Iterable, List

import numpy as np
import pandas as pd

import perceptual_stabilization_model as perceptual
import symbolic_reuse_model as reuse

ROOT = Path(__file__).resolve().parent
DESIGN = json.loads((ROOT / "simulation_design.json").read_text(encoding="utf-8"))
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

FAMILIES = ["S1", "S2", "S3", "S4", "MC-R1", "MC-R2", "MC-R3"]


def fixture_root(name: str, *, source=(0.20, 0.80, 0.50), symbolic_overrides=None):
    mapping = {
        "low_change": "A_clear_stabilization",
        "reuse_growth": "B_ambiguous_signal",
        "high_initial_change": "C_high_overload_dominant_block",
        "source_realignment": "C_high_overload_dominant_block",
        "initial_route_absent": "D_novel_signal",
    }
    return reuse.initial_export(
        f"fixture::{name}",
        dict(perceptual.SCENARIOS[mapping[name]]),
        source=source,
        symbolic_overrides=symbolic_overrides,
    )


def _first_step(t):
    return t["steps"][0] if t.get("steps") else {}


def run_structural_consistency_tests() -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []

    def add(test_id, passed, note=""):
        rows.append({"test": test_id, "pass": bool(passed), "note": note})

    root = fixture_root("initial_route_absent")
    t = reuse.run_trajectory(root, "CT1", U=0.5, G=0.5, S=1)
    add("CT-1", root["InitElig"] != 1 and t["q0"] is None and not t["steps"] and t["committed_steps"] == 0,
        "ineligible initial route remains undefined downstream")

    root = fixture_root("low_change", symbolic_overrides={"profile_applicable": False})
    t = reuse.run_trajectory(root, "CT2", U=0.2, G=0.7, S=1)
    add("CT-2", root["symbolic_result"].get("symcap") == 1 and root["InitElig"] == 0 and t["q0"] is None,
        "positive capture without applicable initial fidelity does not instantiate reuse")

    root = fixture_root("reuse_growth")
    t = reuse.run_trajectory(root, "CT3", U=0.9, G=0.05, S=1, candidate_mode="absent"); s = _first_step(t)
    add("CT-3", s.get("later_symform") is None and s.get("symtrace") is None and s.get("symreuse") is None and s.get("commit") == 0,
        "absent later candidate remains undefined")

    t = reuse.run_trajectory(root, "CT4", U=0.9, G=0.05, S=1, candidate_mode="malformed"); s = _first_step(t)
    add("CT-4", s.get("later_symform") == 0 and s.get("symtrace") is None and s.get("symreuse") is None and s.get("commit") == 0,
        "malformed later form does not progress to trace or reuse")

    t = reuse.run_trajectory(root, "CT5", U=0.9, G=0.05, S=1, trace_provenance="mismatch"); s = _first_step(t)
    add("CT-5", s.get("symtrace") == 0 and s.get("symreuse") is None and s.get("commit") == 0,
        "trace provenance mismatch is negative")

    t = reuse.run_trajectory(root, "CT6", U=0.9, G=0.05, S=1, trace_context_present=False); s = _first_step(t)
    add("CT-6", s.get("symtrace") is None and s.get("symreuse") is None and s.get("commit") == 0,
        "missing trace context preserves undefinedness")

    t = reuse.run_trajectory(root, "CT7", U=0.9, G=0.05, S=1, reuse_provenance="mismatch"); s = _first_step(t)
    add("CT-7", s.get("symtrace") == 1 and s.get("symreuse") == 0 and s.get("commit") == 0,
        "positive trace does not entail positive reuse")

    t = reuse.run_trajectory(root, "CT8", U=0.9, G=0.05, S=1, reuse_context_present=False); s = _first_step(t)
    add("CT-8", s.get("symtrace") == 1 and s.get("symreuse") is None and s.get("commit") == 0,
        "missing reuse context remains undefined")

    t9 = reuse.run_trajectory(root, "CT9", U=0.9, G=0.05, S=1); s9 = _first_step(t9)
    add("CT-9", abs(t9["q0"] - 0.15) < 1e-12 and abs(t9["final_q"] - 0.17375) < 1e-12 and s9.get("symreuse") == 1,
        "reuse-load growth witness")

    t10 = reuse.run_trajectory(root, "CT10", U=0.4, G=0.9, S=1); s10 = _first_step(t10)
    add("CT-10", abs(t10["final_q"]) < 1e-12 and abs(s10["later_a"] - 0.2) < 1e-12 and abs(s10["later_b"] - 0.8) < 1e-12
        and abs(t10["final_D_ref"]) < 1e-12 and (t10["final_ref_pres"], t10["final_ref_red"], t10["final_ref_dist"]) == (1, 1, 0),
        "source realignment can restore protected pair while reduction remains")

    root_c = fixture_root("high_initial_change")
    t11 = reuse.run_trajectory(root_c, "CT11", U=0.4, G=0.9, S=1); s11 = _first_step(t11)
    add("CT-11", root_c["initial_sym_dist"] == 1 and abs(t11["final_q"] - 0.15) < 1e-12 and abs(s11["later_a"] - 0.35) < 1e-12
        and abs(s11["later_b"] - 0.65) < 1e-12 and abs(t11["final_D_ref"] - 0.15) < 1e-12 and t11["final_ref_dist"] == 0,
        "initial symbolic distortion does not force later local reference distortion")

    t12 = reuse.run_trajectory(root, "CT12", U=0.9, G=0.05, S=4); sl = t12["steps"][-1]
    add("CT-12", root["initial_sym_dist"] == 0 and abs(sl["later_a"] - 0.5) < 1e-12 and abs(sl["later_b"] - 0.5) < 1e-12
        and t12["final_ref_dist"] == 1 and all(x["fresh_later_symcap"] is None for x in t12["steps"]),
        "later local reference distortion can emerge without fresh symbolic capture")

    add("CT-13", abs(t9["final_q"] - 0.17375) < 1e-12 and abs(t9["final_D_ref"] - 0.15) < 1e-12
        and abs(t9["final_q"] - t9["final_D_ref"]) > 1e-12,
        "reuse-load proxy and source-reference distance are non-identical")

    ta = reuse.run_trajectory(root, "CT14A", U=0.5, G=0.0, S=1, GroundRef=1)
    tb = reuse.run_trajectory(root, "CT14B", U=0.5, G=None, S=1, GroundRef=0)
    sa, sb = _first_step(ta), _first_step(tb)
    add("CT-14", sa["G_eff"] == 0 and sb["G_eff"] == 0 and sa["ground_status"] == 1 and sb["ground_status"] == 0,
        "zero-strength positive reference basis differs from absent basis")

    t15 = reuse.run_trajectory(root, "CT15", U=0.5, G=0.2, S=1, GroundRef=None); s15 = _first_step(t15)
    add("CT-15", s15["q_prop"] is None and s15["candidate_form_id"] is None and s15["symtrace"] is None and s15["symreuse"] is None and s15["commit"] == 0,
        "unresolved reference basis blocks proposal and commitment")

    t16 = reuse.run_trajectory(root, "CT16", U=0.9, G=0.05, S=1, reuse_provenance="mismatch"); s16 = _first_step(t16)
    add("CT-16", s16["symtrace"] == 1 and s16["symreuse"] == 0,
        "trace/reuse separation duplicate witness")

    t17 = reuse.run_trajectory(root, "CT17", U=0.9, G=0.05, S=1); s17 = _first_step(t17)
    add("CT-17", s17["symreuse"] == 1 and s17["later_positive_form_application_id"] is not None and s17["fresh_later_symcap"] is None,
        "reuse does not create fresh capture")

    add("CT-18", t10["final_ref_pres"] == 1 and t10["final_ref_red"] == 1 and t10["final_ref_dist"] == 0 and abs(t10["final_D_ref"]) < 1e-12,
        "reduction is independent of protected-pair realignment")

    df = pd.DataFrame(rows)
    df.to_csv(RESULTS / "structural_consistency_tests.csv", index=False)
    if not (len(df) == 18 and bool(df["pass"].all())):
        raise RuntimeError(df.loc[~df["pass"]].to_dict("records"))
    return df


def family_rows(family: str) -> Iterable[Dict[str, Any]]:
    n = int(DESIGN["deterministic_surfaces"]["resolution_2d"])
    if family in ("S1", "S2"):
        for i, U in enumerate(np.linspace(0.0, 1.0, n)):
            for j, G in enumerate(np.linspace(0.0, 1.0, n)):
                yield {"case_id": f"{family}_{i:05d}_{j:05d}", "U": float(U), "G": float(G)}
        return
    if family == "S3":
        for i, kappa in enumerate(np.linspace(0.0, 0.5, n)):
            for j, delta in enumerate(np.linspace(0.0, 0.4, n)):
                yield {"case_id": f"S3_{i:05d}_{j:05d}", "kappa": float(kappa), "delta": float(delta)}
        return
    if family == "S4":
        for i, gap in enumerate(np.linspace(0.25, 0.80, n)):
            for j, U in enumerate(np.linspace(0.0, 1.0, n)):
                a, c = 0.10, 0.50
                yield {"case_id": f"S4_{i:05d}_{j:05d}", "source_gap": float(gap), "U": float(U), "a": a, "b": a + float(gap), "c": c, "G": 0.05}
        return
    st = next(x for x in DESIGN["monte_carlo"]["strata"] if x["id"] == family)
    rng = np.random.Generator(np.random.PCG64(int(st["seed"])))
    blocks = int(st["blocks"])
    for i in range(int(st["N"])):
        ell = float(rng.uniform()); r = float(rng.uniform())
        M = [float(rng.uniform()) for _ in range(blocks)]
        P = [float(rng.uniform()) for _ in range(blocks)]
        Sup = [float(rng.uniform()) for _ in range(blocks)]
        a = float(rng.uniform(0.10, 0.25)); gap = float(rng.uniform(0.35, 0.65)); b = a + gap
        c = float(rng.uniform(0.10, 0.90)); U = float(rng.uniform()); G = float(rng.uniform())
        yield {"case_id": f"{family}_{i:06d}", "blocks": blocks, "ell": ell, "r": r, "M": M, "P": P, "Sup": Sup,
               "a": a, "gap": gap, "b": b, "c": c, "U": U, "G": G}


def root_for_row(family: str, row: Dict[str, Any], fixed_root=None):
    if fixed_root is not None:
        return fixed_root
    if family == "S4":
        return reuse.initial_export(row["case_id"], dict(perceptual.SCENARIOS["B_ambiguous_signal"]), source=(row["a"], row["b"], row["c"]))
    if family.startswith("MC-R"):
        spec = {"ell": row["ell"], "r": row["r"], "M": row["M"], "P": row["P"], "Sup": row["Sup"]}
        return reuse.initial_export(row["case_id"], spec, source=(row["a"], row["b"], row["c"]))
    raise KeyError(family)


def evaluate_row(family: str, row: Dict[str, Any], fixed_root=None) -> Dict[str, Any]:
    root = root_for_row(family, row, fixed_root=fixed_root)
    if family in ("S1", "S2"):
        U, G, kappa, delta = row["U"], row["G"], 0.25, 0.20
    elif family == "S3":
        U, G, kappa, delta = 0.65, 0.35, row["kappa"], row["delta"]
    elif family == "S4":
        U, G, kappa, delta = row["U"], 0.05, 0.25, 0.20
    else:
        U, G, kappa, delta = row["U"], row["G"], 0.25, 0.20
    t = reuse.run_trajectory(root, row["case_id"], U=U, G=G, kappa=kappa, delta=delta, S=20, eta_q_form=1.0, GroundRef=1)
    rec = {k: v for k, v in t.items() if k not in ("steps", "claim_ceiling")}
    rec.update({"family": family, "U": U, "G": G})
    if family == "S3": rec.update({"axis_kappa": kappa, "axis_delta": delta})
    if family == "S4": rec["source_gap"] = row["source_gap"]
    if family.startswith("MC-R"): rec.update({"blocks": row["blocks"], "ell": row["ell"], "r": row["r"], "source_gap": row["gap"]})
    return rec


def summarize_family(df: pd.DataFrame, family: str) -> Dict[str, Any]:
    init = df.InitElig.eq(1); complete = df.complete.eq(True)
    final_ref = df.final_D_ref.notna() & df.final_ref_pres.notna() & df.final_ref_red.notna() & df.final_ref_dist.notna()
    out = {"family": family, "D_traj_all": len(df), "D_init_elig": int(init.sum()), "D_complete": int(complete.sum()), "D_final_ref": int(final_ref.sum())}
    out["InitElig_prop"] = float(init.mean()) if len(df) else math.nan
    out["complete_prop_on_init"] = float(complete.sum() / init.sum()) if init.sum() else math.nan
    for col in ("initial_sym_pres", "initial_sym_red", "initial_sym_dist"):
        x = df.loc[init, col].dropna(); out[col + "_prop"] = float((x == 1).mean()) if len(x) else math.nan
    for col in ("final_ref_pres", "final_ref_red", "final_ref_dist"):
        x = df.loc[final_ref, col].dropna(); out[col + "_prop"] = float((x == 1).mean()) if len(x) else math.nan
    for col in ("initial_D_sym_toy_p", "q0", "final_q", "final_D_ref"):
        x = pd.to_numeric(df[col], errors="coerce").dropna(); out[col + "_mean"] = float(x.mean()) if len(x) else math.nan
    delta = df.loc[final_ref & df.initial_D_sym_toy_p.notna(), "final_D_ref"].astype(float) - df.loc[final_ref & df.initial_D_sym_toy_p.notna(), "initial_D_sym_toy_p"].astype(float)
    out.update({"delta_D_ref_neg": int((delta < -1e-12).sum()), "delta_D_ref_zero": int((delta.abs() <= 1e-12).sum()), "delta_D_ref_pos": int((delta > 1e-12).sum()), "delta_D_ref_den": int(len(delta))})
    return out


def run_full_analysis():
    summaries = []
    fixed = {
        "S1": fixture_root("reuse_growth"),
        "S2": fixture_root("high_initial_change"),
        "S3": fixture_root("reuse_growth"),
    }
    for family in FAMILIES:
        records = [evaluate_row(family, row, fixed_root=fixed.get(family)) for row in family_rows(family)]
        df = pd.DataFrame(records)
        df.to_csv(RESULTS / f"{family}_trajectory_results.csv", index=False)
        summaries.append(summarize_family(df, family))
        print(f"{family}: {len(df):,} trajectories")
    pd.DataFrame(summaries).to_csv(RESULTS / "family_summary_recomputed.csv", index=False)
    return summaries


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--full", action="store_true", help="re-evaluate all deterministic and Monte Carlo families")
    args = ap.parse_args()
    tests = run_structural_consistency_tests()
    print(f"Structural consistency tests: {int(tests['pass'].sum())}/{len(tests)} PASS")
    if args.full:
        run_full_analysis()


if __name__ == "__main__":
    main()
