from pathlib import Path
import csv, math, sys
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import identity_continuation_breadth_model as m

checks=[]
def add(name,cond): checks.append((name,bool(cond)))
C=m.candidate_carrier(); norms=np.array([math.hypot(c['xi_a'],c['xi_b']) for c in C])
a0=m.make_anchor('case','trajectory',0,0.15,'form0'); A0=m.current_architecture(a0,(0.2,0.8),source_symbolic_form_id='form0')
a1=m.make_anchor('case','trajectory',1,0.4,'form1'); A1=m.current_architecture(a1,(0.3,0.7),source_symbolic_form_id='form1')
add('01_q_below_domain_rejected',m.make_anchor('c','t',0,-0.01,'f') is None)
add('02_q_above_domain_rejected',m.make_anchor('c','t',0,1.01,'f') is None)
add('03_uncommitted_step_rejected',m.make_anchor('c','t',1,0.2,'f',committed=False) is None)
add('04_detached_form_rejected',m.current_architecture(a0,(0.2,0.8),source_symbolic_form_id='other') is None)
add('05_missing_pair_rejected',m.current_architecture(a0,None,source_symbolic_form_id='form0') is None)
bad=dict(C[0]);bad['candidate_id']='bad';add('06_noncanonical_candidate_rejected',not m.candidate_valid(bad))
add('07_missing_basis_context_undefined',not m.evaluate_candidate(a0,A0,C[24],basis_context_present=False)['IdBound']['defined'])
add('08_readiness_zero_undefined',not m.evaluate_candidate(a0,A0,C[24],identity_ready=0)['IdBound']['defined'])
add('09_identity_continuity_undefined_preserved',not m.evaluate_candidate(a0,A0,C[24],idcont_defined=False)['IdBound']['defined'])
at=m.make_anchor('case','trajectory',0,1.0,'form0'); At=m.current_architecture(at,(0.2,0.8),source_symbolic_form_id='form0')
add('10_corner_negative_at_q1',m.evaluate_candidate(at,At,C[0])['IdBound']['value']==0)
add('11_zero_offset_positive',m.evaluate_candidate(at,At,C[24])['IdBound']['value']==1)
j=next(i for i,c in enumerate(C) if abs(c['xi_a']-1)<1e-15 and abs(c['xi_b'])<1e-15)
az=m.make_anchor('case','trajectory',0,0.0,'form0'); Az=m.current_architecture(az,(0.2,0.8),source_symbolic_form_id='form0')
e=m.evaluate_candidate(az,Az,C[j]);add('12_closed_threshold_boundary_positive',abs(e['IdCont']['application']['d_id']-.2)<1e-12 and e['IdBound']['value']==1)
e=m.evaluate_candidate(at,At,C[j]);add('13_same_candidate_negative_at_q1',abs(e['IdCont']['application']['d_id']-.4)<1e-12 and e['IdBound']['value']==0)
br=m.evaluate_frame(a0,A0,undefined_candidate_indices=[0])['breadth'];add('14_undefined_retained_fixed_denominator',br['N_total']==49 and br['N_undef']==1 and br['N_pos']+br['N_neg']==48)
add('15_carrier_has_49_candidates',len(C)==49)
add('16_carrier_ids_unique',len({c['candidate_id'] for c in C})==49)
add('17_carrier_weights_equal',all(abs(c['counting_weight']-1/49)<1e-15 for c in C))
add('18_carrier_weights_sum_one',abs(sum(c['counting_weight'] for c in C)-1)<1e-12)
br=m.evaluate_frame(a0,A0)['breadth'];add('19_breadth_matches_counts',abs(br['B_id_pos']-br['N_pos']/49)<1e-15 and abs(br['B_id_pos']+br['B_id_neg']+br['B_id_undef']-1)<1e-15)
br2=m.evaluate_frame(a0,A0,undefined_candidate_indices=[0])['breadth'];add('20_evaluable_rate_separate_from_fixed_breadth',abs(br2['R_id_pos_eval']-br2['N_pos']/48)<1e-15 and abs(br2['B_id_pos']-br2['N_pos']/49)<1e-15)
v0=m.fast_candidate_values(0,norms);v1=m.fast_candidate_values(1,norms);add('21_q_conditions_candidate_status',not np.array_equal(v0,v1))
qs=np.linspace(0,1,101);bs=[m.fast_breadth(q,norms)['B_id_pos'] for q in qs];add('22_positive_breadth_nonincreasing_in_q',all(bs[i+1]<=bs[i]+1e-15 for i in range(len(bs)-1)))
add('23_identity_threshold_fixed',m.THETA_ID==0.20 and m.IDENTITY_CONTEXT=='pair_norm_identity_continuity')
comp=m.evaluate_candidate(a0,A0,C[24])['IdBasis']['comparison_architecture'];add('24_comparison_pair_not_actual_successor',comp['record_type']=='candidate_comparison_pair' and comp['actual_successor'] is False)
base=m.fast_candidate_values(.5,norms); fake_q=.5; add('25_role_fields_not_identity_inputs',np.array_equal(base,m.fast_candidate_values(fake_q,norms)))
add('26_reference_fields_not_identity_inputs',np.array_equal(base,m.fast_candidate_values(fake_q,norms)))
Aalt=m.current_architecture(a0,(-10.0,8.0),source_symbolic_form_id='form0');vals1=[r['IdBound']['value'] for r in m.evaluate_frame(a0,A0)['candidate_records']];vals2=[r['IdBound']['value'] for r in m.evaluate_frame(a0,Aalt)['candidate_records']];add('27_pair_translation_does_not_change_relative_status',vals1==vals2)
add('28_invalid_fast_q_returns_undefined',np.all(m.fast_candidate_values(float('nan'),norms)==-1))
add('29_baseline_q015_matches_21_of_49',m.fast_breadth(.15,norms)['N_pos']==21 and abs(m.fast_breadth(.15,norms)['B_id_pos']-21/49)<1e-15)

out=Path(__file__).resolve().parents[1]/'summaries'/'structural_consistency_results.csv'
with out.open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['check','pass']);w.writerows(checks)
print(f"{sum(p for _,p in checks)}/{len(checks)} structural consistency checks passed")
if not all(p for _,p in checks):
    raise SystemExit(1)
