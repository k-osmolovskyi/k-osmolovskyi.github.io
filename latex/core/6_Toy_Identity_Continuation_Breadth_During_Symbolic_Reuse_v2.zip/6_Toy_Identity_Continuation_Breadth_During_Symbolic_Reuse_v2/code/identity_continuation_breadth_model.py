from __future__ import annotations
from typing import Any, Dict, Optional, Sequence
import math
import numpy as np

R0 = 0.20
THETA_ID = 0.20
TOL = 1e-12
AXIS = (-1.0, -2.0/3.0, -1.0/3.0, 0.0, 1.0/3.0, 2.0/3.0, 1.0)
N_CANDIDATES = 49
BASIS_CONTEXT = "q_gain_pair_projection"
IDENTITY_CONTEXT = "pair_norm_identity_continuity"


def finite01(x: Any) -> bool:
    try:
        y = float(x)
    except Exception:
        return False
    return math.isfinite(y) and 0.0 <= y <= 1.0


def candidate_carrier():
    out = []
    for i, xa in enumerate(AXIS):
        for j, xb in enumerate(AXIS):
            idx = 7*i + j
            out.append({
                "candidate_index": idx,
                "candidate_id": f"g_{i}_{j}",
                "xi_a": xa,
                "xi_b": xb,
                "counting_weight": 1.0/N_CANDIDATES,
            })
    return out


def candidate_valid(candidate: Dict[str, Any]) -> bool:
    try:
        idx = int(candidate["candidate_index"])
        if float(candidate["candidate_index"]) != float(idx):
            return False
        exp = candidate_carrier()[idx]
        return (
            0 <= idx < N_CANDIDATES
            and str(candidate["candidate_id"]) == exp["candidate_id"]
            and abs(float(candidate["xi_a"]) - exp["xi_a"]) < 1e-15
            and abs(float(candidate["xi_b"]) - exp["xi_b"]) < 1e-15
            and abs(float(candidate["counting_weight"]) - exp["counting_weight"]) < 1e-15
        )
    except Exception:
        return False


def make_anchor(case_id: str, trajectory_id: str, t: int, q: float,
                symbolic_form_id: str, *, committed: bool = True) -> Optional[Dict[str, Any]]:
    if not case_id or not trajectory_id or not symbolic_form_id or not finite01(q):
        return None
    try:
        ti = int(t)
    except Exception:
        return None
    if ti < 0 or (ti > 0 and not committed):
        return None
    return {
        "case_id": str(case_id), "trajectory_id": str(trajectory_id), "t": ti,
        "q": float(q), "symbolic_form_id": str(symbolic_form_id),
        "anchor_kind": "root" if ti == 0 else "committed_step",
    }


def current_architecture(anchor: Optional[Dict[str, Any]], pair: Optional[Sequence[Any]],
                         *, source_symbolic_form_id: Optional[str]) -> Optional[Dict[str, Any]]:
    if anchor is None or pair is None or len(pair) < 2:
        return None
    if source_symbolic_form_id != anchor.get("symbolic_form_id"):
        return None
    try:
        a, b = float(pair[0]), float(pair[1])
    except Exception:
        return None
    if not (math.isfinite(a) and math.isfinite(b)):
        return None
    return {"record_type":"current_pair_projection", "a":a, "b":b,
            "case_id":anchor["case_id"], "trajectory_id":anchor["trajectory_id"],
            "t":anchor["t"], "symbolic_form_id":source_symbolic_form_id}


def idbasis(anchor: Optional[Dict[str, Any]], current_arch: Optional[Dict[str, Any]],
            candidate: Dict[str, Any], *, basis_context_present: bool = True) -> Dict[str, Any]:
    if anchor is None or current_arch is None or not basis_context_present or not candidate_valid(candidate):
        return {"defined":False,"application":None,"comparison_architecture":None,"d_id":None}
    if current_arch.get("case_id") != anchor.get("case_id") or current_arch.get("trajectory_id") != anchor.get("trajectory_id") or current_arch.get("t") != anchor.get("t"):
        return {"defined":False,"application":None,"comparison_architecture":None,"d_id":None}
    q=float(anchor["q"]); gamma=1.0+q
    ap=float(current_arch["a"])+R0*gamma*float(candidate["xi_a"])
    bp=float(current_arch["b"])+R0*gamma*float(candidate["xi_b"])
    d=math.hypot(ap-float(current_arch["a"]),bp-float(current_arch["b"]))
    comp={"record_type":"candidate_comparison_pair","a":ap,"b":bp,
          "candidate_id":candidate["candidate_id"],"actual_successor":False}
    app={"context":BASIS_CONTEXT,"candidate_id":candidate["candidate_id"],"q":q,
         "gamma":gamma,"r0":R0,"defined":1}
    return {"defined":True,"application":app,"comparison_architecture":comp,"d_id":d}


def readiness(candidate_id: str, *, ready: Optional[int] = 1, context_present: bool = True) -> Dict[str, Any]:
    if not context_present or ready not in (0,1):
        return {"ready":None,"record":None}
    return {"ready":int(ready),"record":{"candidate_id":candidate_id,"context":IDENTITY_CONTEXT}}


def idcont(basis: Dict[str, Any], candidate_id: str, *, defined: bool = True,
           identity_context_present: bool = True) -> Dict[str, Any]:
    if not defined or not identity_context_present or not basis.get("defined"):
        return {"defined":False,"value":None,"application":None}
    d=float(basis["d_id"]); val=int(d <= THETA_ID + TOL)
    return {"defined":True,"value":val,"application":{"candidate_id":candidate_id,
            "context":IDENTITY_CONTEXT,"metric":"pair_euclidean_norm",
            "theta_id":THETA_ID,"d_id":d,"IdCont":val}}


def idbound(basis: Dict[str, Any], ready_result: Dict[str, Any],
            idcont_result: Dict[str, Any], candidate_id: str) -> Dict[str, Any]:
    if (not basis.get("defined") or ready_result.get("ready") != 1
        or not idcont_result.get("defined")):
        return {"defined":False,"value":None,"application":None}
    val=int(idcont_result["value"])
    return {"defined":True,"value":val,"application":{"candidate_id":candidate_id,
            "context":IDENTITY_CONTEXT,"IdBound":val}}


def evaluate_candidate(anchor, current_arch, candidate, *, basis_context_present=True,
                       identity_ready=1, idcont_defined=True, identity_context_present=True):
    cid=str(candidate.get("candidate_id"))
    basis=idbasis(anchor,current_arch,candidate,basis_context_present=basis_context_present)
    ready=readiness(cid,ready=identity_ready,context_present=identity_context_present)
    cont=idcont(basis,cid,defined=idcont_defined,identity_context_present=identity_context_present)
    bound=idbound(basis,ready,cont,cid)
    return {"IdBasis":basis,"readiness":ready,"IdCont":cont,"IdBound":bound}


def breadth_from_values(values):
    vals=list(values)
    if len(vals)!=N_CANDIDATES or any(v not in (0,1,None) for v in vals):
        raise ValueError("fixed carrier requires 49 statuses in {1,0,None}")
    npos=sum(v==1 for v in vals); nneg=sum(v==0 for v in vals); nundef=sum(v is None for v in vals)
    de=npos+nneg
    return {"N_total":N_CANDIDATES,"N_pos":npos,"N_neg":nneg,"N_undef":nundef,
            "B_id_pos":npos/N_CANDIDATES,"B_id_neg":nneg/N_CANDIDATES,
            "B_id_undef":nundef/N_CANDIDATES,"R_id_pos_eval":npos/de if de else None}


def evaluate_frame(anchor, current_arch, carrier=None, *, basis_context_present=True,
                   identity_ready=1, idcont_defined=True, undefined_candidate_indices=()):
    carrier = candidate_carrier() if carrier is None else list(carrier)
    if len(carrier)!=N_CANDIDATES or any(not candidate_valid(c) or c["candidate_index"]!=j for j,c in enumerate(carrier)):
        raise ValueError("candidate carrier identity/order mismatch")
    missing=set(int(x) for x in undefined_candidate_indices)
    if any(x<0 or x>=N_CANDIDATES for x in missing):
        raise ValueError("undefined candidate index outside carrier")
    records=[]; values=[]
    for j,c in enumerate(carrier):
        r=evaluate_candidate(anchor,current_arch,c,basis_context_present=basis_context_present,
                             identity_ready=identity_ready,idcont_defined=(idcont_defined and j not in missing))
        records.append(r); values.append(r["IdBound"]["value"] if r["IdBound"]["defined"] else None)
    return {"candidate_records":records,"breadth":breadth_from_values(values)}


def fast_candidate_values(q: float, xi_norms: np.ndarray) -> np.ndarray:
    if not finite01(q):
        return np.full(len(xi_norms),-1,dtype=np.int8)
    d=R0*(1.0+float(q))*np.asarray(xi_norms,dtype=np.float64)
    return (d<=THETA_ID+TOL).astype(np.int8)


def fast_breadth(q: float, xi_norms: np.ndarray) -> Dict[str, Any]:
    v=fast_candidate_values(q,xi_norms)
    return breadth_from_values([None if int(x)<0 else int(x) for x in v])
